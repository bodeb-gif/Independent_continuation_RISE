"""Pair fixed-setting HGB refits with full reselection at identical weights."""
import time
from refit_multiplier_corrected import *

def run():
    started=time.monotonic();frame,valid=feature_frame();targets=HistoricalTargets()
    algorithm='hist_gradient_boosting';folder=OUT/'models_boundary_corrected'/algorithm
    probe=folder/'reselection_probe';out=folder/'reselection_counterfactual';out.mkdir(exist_ok=True)
    if not (probe/'uniform_reproduction.json').exists():raise ValueError('Fully nested uniform check not complete')
    if json.loads((probe/'uniform_reproduction.json').read_text())['status']!='passed':raise ValueError('Probe uniform check failed')
    receipt=dict(code_sha256=digest(__file__),canonical_sampler_sha256=digest(OUT/'refit_multiplier_corrected.py'),
        probe_implementation_sha256=digest(probe/'implementation.json'),
        model_predictions_sha256=digest(folder/'predictions_without_truth.csv'),
        role='Fixed-setting forecasts at exactly the same weights as fully nested probe draws. No new significance test or independent discovery.')
    if (out/'implementation.json').exists() and json.loads((out/'implementation.json').read_text())!=receipt:
        raise ValueError('Changed paired probe implementation')
    save_json(out/'implementation.json',receipt)
    audits={}
    for path in (folder/'annual').glob('*.json'):
        d=json.loads(path.read_text());audits[(d['task'],d['arm'],d['refit_year'])]=d
    originals=pd.read_csv(folder/'predictions_without_truth.csv');originals.origin=pd.PeriodIndex(originals.origin,freq='M')
    original={(t,a):g.set_index('origin').prediction for (t,a),g in originals.groupby(['task','arm'])}
    rows=[];counts=[]
    for path in sorted(probe.glob('draw_*.json')):
        d=json.loads(path.read_text());draw=d['draw'];checkpoint=out/path.name
        if checkpoint.exists():
            if draw>=0:rows+=json.loads(checkpoint.read_text())['results']
            continue
        groups=(valid.year-1977)//5;codes=np.array(d['block_codes'],int)
        if not np.array_equal(np.unique(groups),codes):raise ValueError('Probe calendar mismatch')
        weights=pd.Series(np.array(d['block_weights'])[np.searchsorted(codes,groups)],index=valid)
        reference={(r['task'],r['comparison']):r['gain'] for r in d['results']};local=[];errors=[]
        for task in TASKS:
            predictions={arm:[] for arm in ARMS}
            for year in range(1977,2011):
                cutoff=pd.Period(f'{year}-01','M');test=valid[valid.year==year]
                for arm in ARMS:
                    config=audits[(task,arm,year)]['configuration']
                    train,y,_=eligible(frame,valid,targets,cutoff,task,config['window'])
                    values=predict_weighted(algorithm,task,config,frame,train,y,test,ARMS[arm],weights,113+year)
                    predictions[arm].append(pd.Series(values,index=test))
            truth=evaluation_truth(pd.period_range('1977-01','2010-12',freq='M'),task);loss={}
            for arm,parts in predictions.items():
                p=pd.concat(parts).sort_index();loss[arm]=(p.to_numpy()-truth)**2
                if draw<0:
                    error=float(abs(p-original[(task,arm)]).max());errors.append(dict(task=task,arm=arm,max_error=error))
                    if error>1e-8:raise ValueError('Paired uniform forecasts do not match canonical')
            w=weights.reindex(pd.period_range('1977-01','2010-12',freq='M')).to_numpy(float)
            for newer,older,label in [('macro_coverage_net','macro_coverage','net_minus_macro_coverage'),
                ('macro_coverage_net_structure','macro_coverage_net','structure_minus_net')]:
                fixed=float(np.average(loss[older]-loss[newer],weights=w));selected=reference[task,label]
                local.append(dict(draw=draw,task=task,comparison=label,fixed_setting_gain=fixed,
                    full_reselection_gain=selected,reselection_minus_fixed=selected-fixed))
        selections=d['selections']
        count=dict(draw=draw,configurations_changed=sum(s['changed'] for s in selections),
            configurations_total=len(selections))
        save_json(checkpoint,dict(draw=draw,results=local,selection_count=count,
            probe_checkpoint_sha256=digest(path),elapsed_seconds=time.monotonic()-started))
        if draw<0:save_json(out/'uniform_reproduction.json',dict(status='passed',errors=errors))
        else:rows+=local
        print('Paired HGB draw',draw,'complete',round(time.monotonic()-started,1),'seconds',flush=True)
    # Selection counts are read independently from all completed paired files.
    for path in out.glob('draw_*.json'):
        d=json.loads(path.read_text())
        if d['draw']>=0:counts.append(d['selection_count'])
    pd.DataFrame(rows).to_csv(out/'paired_gains.csv',index=False)
    pd.DataFrame(counts).to_csv(out/'selection_changes.csv',index=False)
    save_json(out/'status.json',dict(status='available_draws_complete',completed_draws=len(counts),
        elapsed_seconds=time.monotonic()-started,updated_utc=dt.datetime.now(dt.timezone.utc),source_check=check_sources(),
        limitation='Small paired procedural probe; no reliable tail interval or selection-adjusted significance claim.'))
    journal('hgb_probe_counterfactual','Completed fixed-versus-reselected comparisons at identical block weights',draws=len(counts))

if __name__=='__main__':
    with threadpool_limits(limits=1):run()
