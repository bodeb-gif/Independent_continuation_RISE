"""Streaming fixed-design null calibration, emphasizing the family-level tail."""
import time
from scipy.signal import lfilter
from null_calibration import binomial_interval
from associations import *
from collect_results import planned

def run():
    started=time.monotonic();folder=OUT/'null_calibration_precision';folder.mkdir(exist_ok=True)
    family=68+len(planned());level=.05/family;draws=1000000;batch_size=2000
    spec=dict(created_utc=dt.datetime.now(dt.timezone.utc),draws_per_case=draws,cases=[0.,.5,.9,.98],
        random_seed_namespace=405,batch_size=batch_size,burn_in=1000,moving_sum_months=6,
        family_size=family,family_threshold=level,primary_nominal_draws=10000,
        design='Same fixed observed gap design and restricted-null mean as the pilot. Stationary Gaussian AR innovations and overlapping6-month sums. Independent seeds405.',
        role='Higher-precision tail calibration after pilot results. Fixed1million per case; no empirical p-value is replaced or recalibrated.',
        storage='Streaming sufficient counts, first100 diagnostics and all cluster-t family-tail cases. No growing full-draw table.',
        code_sha256=digest(__file__))
    receipt=folder/'design.json'
    if receipt.exists():
        prior=json.loads(receipt.read_text());spec['created_utc']=prior['created_utc']
        if spec!=prior:raise ValueError('Changed precision implementation')
    else:save_json(receipt,spec)
    d=pd.read_csv(OUT/'audits/structural_analysis_rows.csv.gz')
    d=d[d.test.eq('structure_employment_cross_topic_gap')].copy();d.origin=pd.PeriodIndex(d.origin,freq='M')
    design=select_design(d,['net_direction','net_squared','flat_share','log_articles','n_papers'])
    x=design.to_numpy(float);j=list(design).index('tested_predictor');y=d.employment_growth.to_numpy(float)
    groups=(d.year.to_numpy(int)-1900)//5;codes=np.unique(groups);g=len(codes);n,k=x.shape
    factor=g/(g-1)*(n-1)/(n-k);bread=np.linalg.inv(x.T@x);a=bread@x.T
    z=np.delete(x,j,axis=1);mu=z@np.linalg.lstsq(z,y,rcond=None)[0]
    parts=[np.flatnonzero(groups==code) for code in codes]
    influence=[x[ix]@bread[j] for ix in parts]
    delete=[]
    for code in codes:
        keep=groups!=code;v=np.zeros(n);v[keep]=np.linalg.pinv(x[keep])[j];delete.append(v)
    delete=np.array(delete)
    calendar=pd.period_range(d.origin.min(),d.origin.max(),freq='M');positions=calendar.get_indexer(d.origin)
    summaries=[]
    for rho in spec['cases']:
        path=folder/f'case_{int(rho*100):02}_summary.json'
        if path.exists():
            case=json.loads(path.read_text())
            if case['status']=='complete':summaries.extend(case['summary']);continue
        rng=np.random.default_rng(np.random.SeedSequence([SEED,405,int(rho*1000)]))
        counts={(method,label):0 for method in ['cluster','primary','cv3'] for label in ['nominal','family']}
        rare=[];sample=[];processed=0
        for first in range(0,draws,batch_size):
            count=min(batch_size,draws-first)
            innovations=rng.normal(size=(count,1000+len(calendar)+5))
            state=lfilter([np.sqrt(1-rho*rho)],[1.,-rho],innovations,axis=1)[:,1000:]
            cumulative=np.column_stack([np.zeros(count),np.cumsum(state,axis=1)])
            error=(cumulative[:,6:]-cumulative[:,:-6])/np.sqrt(6)
            if error.shape!=(count,len(calendar)):raise ValueError('Wrong calendar shape')
            star=mu[None,:]+error[:,positions];beta=star@a.T;u=star-beta@x.T
            scores=np.column_stack([u[:,ix]@v for ix,v in zip(parts,influence)])
            se=np.sqrt(factor*np.square(scores).sum(axis=1))
            p=2*st.t.sf(abs(beta[:,j]/se),g-1)
            leaveout=star@delete.T;se3=np.sqrt((g-1)/g*np.square(leaveout-beta[:,j,None]).sum(axis=1))
            p3=2*st.t.sf(abs(beta[:,j]/se3),g-1)
            if first==0:
                for i in range(3):
                    independent=sm.OLS(star[i],x).fit(cov_type='cluster',
                        cov_kwds={'groups':groups,'use_correction':True,'df_correction':True},use_t=True)
                    np.testing.assert_allclose([beta[i,j],se[i],p[i]],
                        [independent.params[j],independent.bse[j],independent.pvalues[j]],rtol=1e-8,atol=1e-10)
            for label,threshold in [('nominal',.05),('family',level)]:
                counts['cluster',label]+=int((p<=threshold).sum())
                counts['cv3',label]+=int((p3<=threshold).sum())
            ids=np.arange(first,first+count)
            needed=(p<=level)|((ids<10000)&(p<=.05))
            for i in np.flatnonzero(needed):
                info=restricted_wild(x,star[i],groups,j)
                np.testing.assert_allclose(info['wild_se'],se[i],rtol=1e-7,atol=1e-9)
                primary=max(float(p[i]),info['p_wild_conservative'])
                counts['primary','family']+=int(primary<=level)
                if ids[i]<10000:counts['primary','nominal']+=int(primary<=.05)
                if p[i]<=level:
                    rare.append(dict(rho=rho,draw=int(ids[i]),p_cluster_t=p[i],p_wild=info['p_wild_conservative'],
                        primary_p=primary,p_cv3=p3[i]))
            for i in range(min(count,max(0,100-first))):
                sample.append(dict(rho=rho,draw=int(ids[i]),coefficient=beta[i,j],se=se[i],p_cluster_t=p[i],p_cv3=p3[i]))
            processed+=count
            if processed%20000==0:
                save_json(folder/'status.json',dict(status='running',rho=rho,draws_completed_in_case=processed,
                    maximum_per_case=draws,elapsed_seconds=time.monotonic()-started,
                    updated_utc=dt.datetime.now(dt.timezone.utc)))
                print('rho',rho,'processed',processed,'elapsed',round(time.monotonic()-started,1),flush=True)
        summary=[]
        for method in ['cluster','primary','cv3']:
            for label,target in [('nominal',.05),('family',level)]:
                total=min(processed,10000) if method=='primary' and label=='nominal' else processed
                hits=counts[method,label];low,high=binomial_interval(hits,total)
                summary.append(dict(rho=rho,method=method,level=target,draws=total,rejections=hits,
                    rejection_rate=hits/total,monte_carlo_low=low,monte_carlo_high=high))
        pd.DataFrame(rare).to_csv(folder/f'case_{int(rho*100):02}_family_tail_cases.csv',index=False)
        pd.DataFrame(sample).to_csv(folder/f'case_{int(rho*100):02}_sample.csv',index=False)
        save_json(path,dict(status='complete',rho=rho,n_draws=processed,summary=summary))
        summaries.extend(summary)
        pd.DataFrame(summaries).to_csv(folder/'rejection_rates_partial.csv',index=False)
        journal('null_calibration_precision','Completed independent high-precision case',rho=rho,draws=processed)
    pd.DataFrame(summaries).to_csv(folder/'rejection_rates.csv',index=False)
    save_json(folder/'status.json',dict(status='complete',n_draws=draws*len(spec['cases']),
        elapsed_seconds=time.monotonic()-started,source_check=check_sources(),
        limitation='Fixed-design Gaussian assumptions are illustrative. Accurate Monte Carlo probabilities do not establish that the archive follows these DGPs or validate causal/source claims.'))
    print(pd.DataFrame(summaries).to_string(index=False),flush=True)

if __name__=='__main__':run()
