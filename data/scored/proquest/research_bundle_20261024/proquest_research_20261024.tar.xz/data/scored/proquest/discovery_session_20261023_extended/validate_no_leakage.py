"""Perturb future records and future covariates: earlier results must not move."""
import features as feature_builder
from monthly_ml_corrected import fit_predict
from boundary_rules import *

def run():
    checks=[];calendar=pd.period_range('1900-01','1902-12',freq='M');rows=[]
    for month in calendar:
        for paper in ['Synthetic A','Synthetic B']:
            for ti,topic in enumerate(TOPICS):
                for article in range(6):
                    positives=[4,3,2,5][ti]-(paper=='Synthetic B')
                    sign='positive' if article<positives else 'flat' if article==5 else 'negative'
                    rows.append(dict(record_id=f'{month}:{paper}:{topic}:{article}',
                        page_id=f'{month}:{paper}:{article}',date=str(month.start_time.date()),month=month,
                        paper=paper,topic=topic,sign=sign,confidence='assertive' if article%2 else 'hedged',
                        voice='expert' if article%3 else 'journalist',horizon_used=6 if article%2 else 12,
                        horizon_basis='stated'))
    claims=pd.DataFrame(rows);feature_builder.CALENDAR=calendar
    _,paper,monthly=feature_builder.monthly_structures(claims)
    original=feature_builder.origin_features(paper,monthly)
    changed=claims.copy();cutoff=pd.Period('1901-07','M');future=changed.month>=cutoff
    changed.loc[future,'sign']=changed.loc[future,'sign'].map({'positive':'negative','negative':'positive','flat':'positive'})
    changed.loc[future,'confidence']=changed.loc[future,'confidence'].map({'assertive':'hedged','hedged':'assertive'})
    changed.loc[future,'voice']=changed.loc[future,'voice'].map({'expert':'journalist','journalist':'expert'})
    changed.loc[future,'horizon_used']=18-changed.loc[future,'horizon_used']
    _,paper2,monthly2=feature_builder.monthly_structures(changed)
    altered=feature_builder.origin_features(paper2,monthly2)
    columns=['origin','topic','net_direction']+__import__('design').STRUCTURES
    old=original[original.origin<=cutoff][columns].reset_index(drop=True)
    new=altered[altered.origin<=cutoff][columns].reset_index(drop=True)
    pd.testing.assert_frame_equal(old,new,check_exact=True)
    late=original.origin>cutoff
    if np.allclose(original.loc[late,'net_direction'],altered.loc[late,'net_direction'],equal_nan=True):
        raise ValueError('Non-vacuity check failed: altered future records did not affect future features')
    checks.append('Changing every future synthetic direction/confidence/voice/horizon leaves all earlier eight structures and net directions exactly unchanged.')
    frame,valid=feature_frame();target=CorrectedHistoricalTargets();outer=pd.Period('1980-01','M')
    train,y,_=eligible(frame,valid,target,outer,'unemployment_downturn')
    test=valid[valid.year==1980];arm=__import__('model_data').ARMS['macro_coverage_net_structure']
    altered=frame.copy();altered.loc[altered.index>=pd.Period('1980-04','M'),arm]=1000000.
    configs={'linear':dict(value=.1,window=None),
        'hist_gradient_boosting':dict(iterations=50,leaves=3,window=None),
        'extra_trees':dict(depth=2,leaf=30,window=None),
        'gru':dict(hidden=8,epochs=5,window=None)}
    errors=[]
    for algorithm,config in configs.items():
        a,_=fit_predict(algorithm,'unemployment_downturn',config,frame,train,y,test,arm,seed=911)
        b,_=fit_predict(algorithm,'unemployment_downturn',config,altered,train,y,test,arm,seed=911)
        error=float(abs(a[:3]-b[:3]).max())
        np.testing.assert_allclose(a[:3],b[:3],rtol=0,atol=1e-7)
        errors.append(dict(algorithm=algorithm,max_earlier_prediction_error=error))
        checks.append(algorithm+': changing all later evaluation covariates leaves earlier probabilities unchanged; preprocessing is training-only.')
    save_json(OUT/'audits/no_leakage_validation.json',dict(status='passed',checks=checks,
        errors=errors,source_count=check_sources(),code_sha256=digest(__file__)))
    for check in checks:print('PASS',check)

if __name__=='__main__':run()
