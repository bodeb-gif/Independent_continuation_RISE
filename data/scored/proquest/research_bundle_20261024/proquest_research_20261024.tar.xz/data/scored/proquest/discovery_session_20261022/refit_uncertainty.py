"""Re-estimate chronological ridge models under joint calendar-block weights."""
from common import *
from backtest import frame_for_fitting, archives, labels_for_refit, MODELS
import time


def cached_refits():
    frame=frame_for_fitting();archive=archives();cache={}
    truth=pd.read_csv(OUT/'continuous_targets.csv');truth['origin']=pd.PeriodIndex(truth.origin,freq='M')
    truth=truth.set_index('origin')
    audit=[]
    for task,series,outcome in [('unemployment','RUC','employment_growth'),('production','IPT','general_business_growth')]:
        folds=[]
        for year in range(1977,2011):
            refit=pd.Period(f'{year}-01','M');labels=labels_for_refit(frame,refit,archive[series],task)
            train=frame.merge(labels[['origin','training_target']],on='origin',validate='one_to_one').dropna(subset=['training_target']).sort_values('origin')
            test=frame[frame.origin.dt.year.eq(year)].copy()
            assert (train.origin+8<refit).all()
            fold=dict(train_year=train.origin.dt.year.to_numpy(),test_year=test.origin.dt.year.to_numpy(),
                      y=train.training_target.to_numpy(),truth=truth.loc[test.origin,outcome].to_numpy(),
                      origins=test.origin.astype(str).to_numpy(),models={})
            for model in ['macro','macro_jobs','macro_business','macro_both']:
                features=MODELS[model];a=train[features].to_numpy(float);b=test[features].to_numpy(float)
                median=np.nanmedian(a,axis=0);median=np.nan_to_num(median)
                fold['models'][model]=dict(a=np.column_stack([np.where(np.isnan(a),median,a),np.isnan(a)]),
                                           b=np.column_stack([np.where(np.isnan(b),median,b),np.isnan(b)]),n_features=len(features))
            folds.append(fold)
            audit.append(dict(task=task,year=year,n_training=len(train),n_evaluation=len(test),last_training_origin=train.origin.max(),vintage=labels.label_vintage.iloc[0]))
        cache[task]=folds
    pd.DataFrame(audit).to_csv(OUT/'refit_uncertainty_audit.csv',index=False)
    return cache


def weighted_prediction(bundle,y,w):
    a,b,n=bundle['a'],bundle['b'],bundle['n_features']
    w=w/w.mean()
    mean=np.average(a,axis=0,weights=w)
    variance=np.average((a[:,:n]-mean[:n])**2,axis=0,weights=w)
    scale=np.r_[np.where(variance>1e-24,np.sqrt(variance),1.),np.ones(n)]
    x=(a-mean)/scale;z=(b-mean)/scale
    ym=np.average(y,weights=w)
    coef=np.linalg.solve(x.T@(w[:,None]*x)+10*np.eye(x.shape[1]),x.T@(w*(y-ym)))
    return ym+z@coef


def evaluate(cache,span,weights,return_predictions=False):
    rows=[];predictions=[]
    for task,folds in cache.items():
        total={model:0. for model in ['macro','macro_jobs','macro_business','macro_both']};den=0
        for fold in folds:
            train_w=weights[(fold['train_year']-1965)//span]
            test_w=weights[(fold['test_year']-1965)//span]
            den+=test_w.sum()
            for model,bundle in fold['models'].items():
                pred=weighted_prediction(bundle,fold['y'],train_w)
                total[model]+=np.sum(test_w*(pred-fold['truth'])**2)
                if return_predictions:
                    predictions.extend([dict(task=task,origin=o,model=model,prediction=p) for o,p in zip(fold['origins'],pred)])
        for model in ['macro_jobs','macro_business','macro_both']:
            rows.append(dict(task=task,model=model,gain=(total['macro']-total[model])/den,
                             model_mse=total[model]/den,macro_mse=total['macro']/den))
    return rows,predictions


def main():
    cache=cached_refits();models=['macro','macro_jobs','macro_business','macro_both']
    _,reproduced=evaluate(cache,5,np.ones(10),True)
    check=pd.DataFrame(reproduced)
    original=pd.read_csv(OUT/'backtest_predictions_alpha10.csv')
    wide=check.pivot(index=['task','origin'],columns='model',values='prediction').reset_index()
    merged=wide.merge(original,on=['task','origin'],validate='one_to_one',suffixes=('_reproduced','_saved'))
    maximum=max(np.max(np.abs(merged[m+'_reproduced']-merged[m+'_saved'])) for m in models)
    assert maximum<1e-9,maximum
    print('All-one weights reproduce saved predictions; maximum error:',maximum,flush=True)
    start=time.time();records=[]
    for span,draws in [(5,2000),(2,500),(10,500)]:
        n_blocks=(2010-1965)//span+1;rng=np.random.default_rng(SEED+span)
        for draw in range(draws):
            weights=rng.exponential(size=n_blocks)
            rows,_=evaluate(cache,span,weights)
            records.extend([dict(block_years=span,draw=draw,**r) for r in rows])
            if (draw+1)%100==0:
                print(f'{span}-year blocks: {draw+1}/{draws}; elapsed {time.time()-start:.1f}s',flush=True)
                pd.DataFrame(records).to_csv(OUT/'refit_uncertainty_draws_partial.csv',index=False)
    result=pd.DataFrame(records);result.to_csv(OUT/'refit_uncertainty_draws.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    rows=[]
    for (span,task,model),g in result.groupby(['block_years','task','model']):
        low,high=np.quantile(g.gain,[.025,.975])
        rows.append(dict(block_years=span,task=task,model=model,n_draws=len(g),mean_gain=g.gain.mean(),median_gain=g.gain.median(),low=low,high=high,positive_share=(g.gain>0).mean()))
    pd.DataFrame(rows).to_csv(OUT/'refit_uncertainty_intervals.csv',index=False)
    (OUT/'refit_uncertainty_draws_partial.csv').unlink(missing_ok=True)
    write_json('refit_uncertainty_manifest.json',dict(all_one_reproduction_max_error=maximum,elapsed_seconds=time.time()-start,
               draw_count=3000,input_code_sha256={str(p.relative_to(ROOT)):digest(p) for p in [Path(__file__),OUT/'backtest.py',OUT/'refit_uncertainty_specification.json']}))
    print(pd.DataFrame(rows).to_string(index=False),flush=True)


if __name__=='__main__':main()
