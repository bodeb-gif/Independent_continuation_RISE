"""Independent decimal-boundary checks and audit of reused annual fits."""
from decimal import Decimal
from boundary_rules import *

def run():
    checks=[]
    v=np.array([-.5,np.nextafter(-.5,-np.inf),np.nextafter(-.5,np.inf),-.50000001,-.49999999])
    np.testing.assert_array_equal(below_boundary(v,-.5),[False,False,False,True,False])
    checks.append('Exact and adjacent-float half-point boundaries remain flat; material changes beyond the band become downturns.')
    frame,valid=feature_frame();old=HistoricalTargets();new=CorrectedHistoricalTargets();differences=[]
    for year in range(1971,2011):
        cutoff=pd.Period(f'{year}-01','M')
        for task in TASKS:
            a=old.labels(valid,cutoff,task);b=new.labels(valid,cutoff,task)
            delta=~np.isclose(a.training_target,b.training_target,equal_nan=True,rtol=0,atol=0)
            if delta.any():differences.append(dict(year=year,task=task,origins=a.loc[delta,'origin'].astype(str).tolist(),n=int(delta.sum())))
            if task!='unemployment_downturn' or year<2004:assert not delta.any()
            if task.endswith('downturn'):
                name,day,s=new.snapshot(cutoff,task)
                for row in b[b.training_target.notna()].itertuples():
                    first=Decimal(str(s.loc[row.target_start]));last=Decimal(str(s.loc[row.target_end]))
                    if task.startswith('unemployment'):
                        expected=float(last-first>Decimal('0.5'))
                        if row.training_target!=expected:raise ValueError('Decimal arithmetic disagrees with corrected unemployment class')
    checks.append('Every corrected historical unemployment training class matches independent Decimal endpoint arithmetic.')
    checks.append('Only unemployment-downturn vintages2004–2010 differ; all continuous/production and pre2004 classes reproduce exactly.')
    a=original_evaluation_truth(pd.period_range('1977-01','2010-12',freq='M'),'unemployment_downturn')
    b=corrected_evaluation_truth(pd.period_range('1977-01','2010-12',freq='M'),'unemployment_downturn')
    assert np.flatnonzero(a!=b).tolist()==[286]
    assert pd.period_range('1977-01','2010-12',freq='M')[286]==pd.Period('2000-11','M')
    checks.append('Exactly one assessment class changes: November2000; its exact half-point increase is flat.')
    for algorithm in ['linear','hist_gradient_boosting','extra_trees','gru']:
        folder=OUT/'models_boundary_corrected'/algorithm
        if not (folder/'completion.json').exists():continue
        initial=pd.read_csv(OUT/'models'/algorithm/'predictions_without_truth.csv')
        fixed=pd.read_csv(folder/'predictions_without_truth.csv')
        joined=initial.merge(fixed,on=['origin','task','algorithm','arm'],suffixes=('_old','_new'),validate='one_to_one')
        unaffected=joined.task.ne('unemployment_downturn')|joined.origin.lt('2004-01')
        np.testing.assert_array_equal(joined.loc[unaffected,'prediction_old'],joined.loc[unaffected,'prediction_new'])
        checks.append(algorithm+': all unaffected saved probabilities/point predictions reproduce bit-for-bit.')
    save_json(OUT/'audits/boundary_validation.json',dict(status='passed',checks=checks,
        vintage_differences=differences,source_count=check_sources()))
    for check in checks:print('PASS',check)

if __name__=='__main__':run()
