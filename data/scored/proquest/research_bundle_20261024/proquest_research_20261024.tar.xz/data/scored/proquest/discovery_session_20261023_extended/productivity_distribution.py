"""Activity-versus-labor outlooks and three independent BLS outcome series."""
from associations import *

SPEC=json.loads((OUT/'specs/productivity_distribution.json').read_text())

def panel(source):
    f=pd.read_csv(OUT/'cache'/f'features_{source}.csv.gz');f['origin']=pd.PeriodIndex(f.origin,freq='M')
    fields=['net_direction','flat_share','log_articles','n_papers']
    wide=f.pivot(index='origin',columns='topic',values=fields)
    wide.columns=[f'{t}__{c}' for c,t in wide.columns];wide=wide.reset_index()
    d=wide[wide.origin.dt.month.isin([1,4,7,10])&wide.origin.dt.year.between(1947,2010)].copy()
    d['activity_labor_gap']=d.general_business__net_direction-d.employment__net_direction
    d['average_activity_labor']=(d.general_business__net_direction+d.employment__net_direction)/2
    d['average_squared']=d.average_activity_labor**2;d['year']=d.origin.dt.year
    return d

def load_outcome(sid,origins):
    path=OUT/'reference'/f'{sid}.csv'
    f=pd.read_csv(path)
    if list(f)!=['observation_date',sid]:raise ValueError('Wrong benchmark header')
    s=pd.Series(pd.to_numeric(f[sid],errors='coerce').to_numpy(),index=pd.PeriodIndex(f.observation_date,freq='Q')).dropna()
    if not s.index.is_unique or not (s>0).all():raise ValueError('Invalid quarterly benchmark')
    values=[]
    for origin in origins:
        quarter=origin.asfreq('Q');start=quarter-1;end=quarter+1
        a=s.get(start,np.nan);b=s.get(end,np.nan)
        values.append(100*np.log(b/a) if np.isfinite(a) and np.isfinite(b) else np.nan)
    return values

def run():
    controls=['average_activity_labor','average_squared','markets__net_direction','prices__net_direction']
    controls += [f'{t}__{c}' for t in ['general_business','employment'] for c in ['flat_share','log_articles','n_papers']]
    rows=[];sensitivity=[];samples=[];manifest=[]
    for sid in SPEC['outcomes']:
        test='productivity_distribution_'+sid;path=OUT/'reference'/f'{sid}.csv'
        if not path.exists():
            rows.append(dict(test=test,batch='productivity_distribution',series=sid,effect=np.nan,p_value=1.,n=0,n_blocks=0,status='source_unavailable'))
            continue
        manifest.append(dict(series=sid,sha256=digest(path),source='https://fred.stlouisfed.org/series/'+sid))
        for source in ['verified','raw']:
            d=panel(source);d['outcome']=load_outcome(sid,d.origin)
            r,fit,used=estimate(d,'activity_labor_gap','outcome',controls,wild=True)
            row=dict(test=test,batch='productivity_distribution',series=sid,outcome=SPEC['outcomes'][sid],block_years=5,**r)
            if source=='verified':rows.append(row);samples.append(used.assign(test=test))
            else:sensitivity.append(dict(variant='raw',**row))
            if source=='verified' and fit is not None:
                for span in [2,10]:
                    rr,_,_=estimate(d,'activity_labor_gap','outcome',controls,span=span,wild=True)
                    sensitivity.append(dict(test=test,variant=f'blocks_{span}',**rr))
                for label,mask in [('exclude_2007_2009',~d.year.between(2007,2009)),
                    ('pre_1980',d.year<1980),('1980_onward',d.year>=1980)]:
                    rr,_,_=estimate(d[mask],'activity_labor_gap','outcome',controls,wild=False)
                    sensitivity.append(dict(test=test,variant=label,**rr))
                macro=pd.read_csv(PRIOR/'phase2/fresh_core_forecast_features.csv');macro['origin']=pd.PeriodIndex(macro.origin,freq='M')
                from proquest_vintages import CORE_FEATURES
                augmented=d.merge(macro[['origin']+list(CORE_FEATURES)],on='origin',validate='one_to_one')
                rr,_,_=estimate(augmented,'activity_labor_gap','outcome',controls+list(CORE_FEATURES),wild=True)
                sensitivity.append(dict(test=test,variant='vintage_macro_controls',**rr))
            print(source,sid,r['effect'],r['p_value'],r['n'],flush=True)
    result=adjust(pd.DataFrame(rows),112);assert len(result)==3
    result.to_csv(OUT/'productivity_tests.csv',index=False)
    pd.DataFrame(sensitivity).to_csv(OUT/'productivity_sensitivities.csv',index=False)
    if samples:pd.concat(samples,ignore_index=True).to_csv(OUT/'audits/productivity_analysis_rows.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    save_json(OUT/'audits/productivity_manifest.json',dict(status='complete',n_tests=3,benchmarks=manifest,
        role='Outcome-only external BLS data; no vintage-feature or direct productivity-forecast claim.',
        code_sha256=digest(__file__),source_count=check_sources()))
    journal('productivity_distribution','Completed the three productivity and compensation outcome questions')
    print(result[['test','effect','low','high','p_value','holm_p','n','n_blocks']].to_string(index=False))

if __name__=='__main__':run()
