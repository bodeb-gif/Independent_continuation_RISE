"""Outcome-blind, calendar-stratified source-review packet for the new lead.

No annotations are invented and no new human-validation result is claimed.
"""
from session_utils import *

def run():
    folder=OUT/'source_validation_packet';folder.mkdir(exist_ok=True)
    f=pd.read_csv(OUT/'cache/features_verified.csv.gz')
    f.origin=pd.PeriodIndex(f.origin,freq='M')
    d=f[f.topic.eq('employment')&f.origin.between(pd.Period('1948-02','M'),pd.Period('2010-12','M'))]
    required=['net_direction','net_squared','flat_share','log_articles','n_papers','cross_topic_gap']
    # No target, retrospective window, verifier prose, outcome value or effect
    # magnitude is read to define or select the review origins.
    universe=pd.PeriodIndex(d.dropna(subset=required).origin,freq='M').sort_values()
    rng=np.random.default_rng(np.random.SeedSequence([20261024,2718]))
    groups=(universe.year-1900)//5;origins=[]
    for block in np.unique(groups):
        candidates=universe[groups==block];origin=candidates[rng.integers(len(candidates))]
        origins.append(dict(block=int(block),origin=origin,n_eligible_in_block=len(candidates),
            origin_inclusion_probability=1/len(candidates),earliest_print_month=origin-3,latest_print_month=origin-1))
    chosen=pd.DataFrame(origins);chosen.to_csv(folder/'sampled_origins.csv',index=False)
    printmonths=set(m for o in chosen.origin for m in pd.period_range(o-3,o-1,freq='M'))
    claims=pd.read_csv(OUT/'cache/print_claims_verified.csv.gz',dtype={'page_id':str})
    claims.month=pd.PeriodIndex(claims.month,freq='M')
    selected=claims[claims.month.isin(printmonths)].copy()
    selected.to_csv(folder/'private_machine_crosswalk.csv',index=False)
    articles=selected[['page_id','date','month','paper']].drop_duplicates().sort_values(['date','paper','page_id'])
    if not articles.page_id.is_unique:raise ValueError('Article metadata inconsistent')
    weights=[]
    for row in articles.itertuples(index=False):
        exclusion=1.
        for block in np.unique(groups):
            candidates=universe[groups==block]
            count=int(((candidates>=row.month+1)&(candidates<=row.month+3)).sum())
            exclusion*=1-count/len(candidates)
        probability=1-exclusion
        if not 0<probability<=1:raise ValueError('Invalid article inclusion probability')
        weights.append(dict(page_id=row.page_id,article_inclusion_probability=probability,
            inverse_probability=1/probability))
    pd.DataFrame(weights).to_csv(folder/'private_sampling_weights.csv',index=False)
    articles[['page_id','date','paper']].to_csv(folder/'blind_articles.csv',index=False)
    with (folder/'blank_annotations.jsonl').open('w') as handle:
        for row in articles.itertuples(index=False):
            handle.write(json.dumps(dict(page_id=row.page_id,date=row.date,paper=row.paper,
                source_text_available=False,reviewer=None,review_complete=False,claims=[],
                missing_or_ambiguous_source_notes=None))+'\n')
    protocol=dict(created_utc=dt.datetime.now(dt.timezone.utc),status='Prepared; source text and independent annotations are not locally available.',
        seed_sequence=[20261024,2718],n_origins=len(chosen),n_print_months=len(printmonths),
        n_articles=len(articles),n_machine_panel_rows=len(selected),
        population='Feature-supported employment origins1948-02 through2010-12, divided into occupied five-year calendar blocks. One origin sampled uniformly and independently in each block; review all panel articles in its previous3 printmonths.',
        blinding='Reviewers receive blind_articles.csv, original source articles and blank_annotations.jsonl only. The machine crosswalk, sampling weights, feature values, outcomes, model forecasts and test results are withheld during annotation.',
        required_claim_fields=['verbatim_source_anchor','future_economic_claim_yes_no','topic','scope','direction_in_source_units','stated_horizon_or_explicitly_unknown','speaker_and_voice_if_clear','assertive_or_hedged_if_clear','ambiguity_notes'],
        matching='After independent annotations are frozen, align to exported machine labels only with article source evidence and anchored claims. Identical stripped labels alone do not establish duplicate claims or lineage.',
        probability='Origin probability1/N_block. Article inclusion accounts for overlapping3month windows across all candidate origins:1-product_b(1-k_article,b/N_b). Weights are for design-based summaries within this frame, not a cure for missing source articles.',
        limitations=['No new human validation has been performed.',
            'Only articles containing at least one readable machine-labeled national topic enter the local frame. This cannot estimate recall or population newspaper attention outside that frame.',
            'Complete within-frame review can test monthly signal construction and semantic precision, but cannot certify absent claims in unexported articles.',
            'The small number of sampled origins limits temporal and correction precision; enlarge by a new probability design before making calibrated population claims.'],
        code_sha256=digest(__file__),source_check=check_sources())
    save_json(folder/'protocol.json',protocol)
    journal('source_validation_packet','Prepared blinded probability sample; no new validation claimed',
        origins=len(chosen),articles=len(articles),machine_rows=len(selected))
    print(json.dumps({k:protocol[k] for k in ['status','n_origins','n_print_months','n_articles','n_machine_panel_rows']},indent=2))

if __name__=='__main__':run()
