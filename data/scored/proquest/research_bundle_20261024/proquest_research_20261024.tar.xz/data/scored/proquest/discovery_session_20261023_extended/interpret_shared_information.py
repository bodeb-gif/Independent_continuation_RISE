"""Economic scale, source loadings and a clearly labeled nonidentification toy."""
from session_utils import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def run():
    main=pd.read_csv(OUT/'structural_tests.csv').set_index('test').loc['structure_employment_cross_topic_gap']
    rows=pd.read_csv(OUT/'audits/structural_analysis_rows.csv.gz')
    rows=rows[rows.test.eq('structure_employment_cross_topic_gap')]
    other=rows.net_direction-rows.cross_topic_gap
    raw=-main.effect/main.feature_sd
    summary=dict(primary_gap_sd=main.feature_sd,other_direction_sd=other.std(),
        unemployment_improvement_per_other_index_point=raw,
        effect_per_0_1_index=raw*.1,effect_per_one_other_sd=raw*other.std(),
        low_per_one_other_sd=-main.high/main.feature_sd*other.std(),
        high_per_one_other_sd=-main.low/main.feature_sd*other.std(),
        meaning='Equivalent re-expression of the original conditional coefficient, no new test. Positive means subsequent unemployment improvement; price direction upward is not called good news.')
    save_json(OUT/'audits/economic_scale.json',summary)
    load=pd.read_csv(OUT/'audits/pca_loadings_verified.csv')
    load['origin']=pd.PeriodIndex(load.origin,freq='M');load['year']=load.origin.dt.year
    assert (pd.PeriodIndex(load.latest_training_origin,freq='M')<load.origin).all()
    g=load.groupby('year')[['general_business','markets','prices','explained_variance']].median()
    fig,axes=plt.subplots(2,1,figsize=(9,6),sharex=True,layout='constrained')
    for topic,label,color in [('general_business','Business','#155e76'),('markets','Markets','#bd7438'),('prices','Prices','#6b7b51')]:
        axes[0].plot(g.index,g[topic],label=label,color=color,lw=2)
    axes[0].axhline(0,color='#999',lw=.7);axes[0].set_ylabel('PCA loading');axes[0].legend(frameon=False,ncol=3)
    axes[0].set_title('The common component is learned from earlier printed outlooks only',loc='left')
    axes[1].plot(g.index,100*g.explained_variance,color='#155e76',lw=2)
    axes[1].set_ylabel('Earlier source variation\nexplained by PCA1 (%)');axes[1].set_xlabel('Forecast origin year')
    for ax in axes:ax.grid(alpha=.15)
    fig.text(.01,-.03,'Annual median historical loadings. Sign is fixed by business direction, not by subsequent unemployment. These are statistical weights, not identified economic shocks or welfare weights.',fontsize=8,color='#555')
    for suffix in ['png','svg']:fig.savefig(OUT/'figures'/f'past_only_factor_loadings.{suffix}',dpi=180,bbox_inches='tight')
    plt.close(fig)
    # Analytic classical-measurement illustration; no parameters are estimated
    # from this archive and no simulated coefficient is an economic discovery.
    v,a,b,lam=1.,1.,.25,.7
    conditional_no_proxy=-lam*v*a/(v*(a+b)+a*b)
    macro_error=np.logspace(-3,2,200)
    residual_state=v*macro_error/(v+macro_error)
    coefficient=-lam*residual_state*a/(residual_state*(a+b)+a*b)
    # Independent normal-equation check for [jobs, gap, extra state proxy].
    # The unconditioned gap has zero covariance with the future outcome.
    solved=[]
    for c in macro_error:
        covariance=np.array([[v+a,a,v],[a,a+b,0.],[v,0.,v+c]])
        solved.append(np.linalg.solve(covariance,np.array([lam*v,0.,lam*v]))[1])
    covariance_error=float(np.max(np.abs(np.asarray(solved)-coefficient)))
    assert covariance_error<1e-12
    fig,ax=plt.subplots(figsize=(8,4.8),layout='constrained')
    ax.semilogx(macro_error,-coefficient,color='#155e76',lw=2.5)
    ax.axhline(-conditional_no_proxy,color='#bd7438',ls='--',label='No additional state control')
    ax.set_xlabel('Noise variance of an additional current-state indicator (illustrative units)')
    ax.set_ylabel('Magnitude of conditional own-minus-other coefficient')
    ax.set_title('The gap coefficient can reflect denoising of a persistent state',loc='left')
    ax.grid(alpha=.15);ax.legend(frameon=False)
    fig.text(.01,-.06,'Hypothetical analytic example, not an estimated economic model. Both printed indicators measure the same current state; neither contains unique foresight.',fontsize=8,color='#555')
    for suffix in ['png','svg']:fig.savefig(OUT/'figures'/f'common_state_illustration.{suffix}',dpi=180,bbox_inches='tight')
    plt.close(fig)
    save_json(OUT/'audits/common_state_illustration.json',dict(status='analytic illustration only',
        equations={'jobs':'s+e_jobs','other':'s+e_other','future_outcome':'lambda*s+independent innovation',
            'gap':'jobs-other','conditional_gap_coefficient':'-lambda*v*a / (v*(a+b)+a*b)'},
        parameters=dict(state_variance=v,employment_noise_variance=a,other_noise_variance=b,persistence_loading=lam),
        conditional_gap_coefficient_without_state_proxy=conditional_no_proxy,
        unconditional_gap_coefficient=0.,independent_covariance_solve_max_error=covariance_error,
        assumptions='State, the two indicator errors and the outcome innovation are mutually independent and mean zero. The extra state-proxy error is also independent.',
        inference='This is not a statistical false positive: the second noisy indicator contains information about a persistent state. It does not identify uniquely forward-looking forecast content.'))
    journal('interpretation','Saved equivalent economic units, past-only factor loadings and a nonidentified common-state illustration')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':run()
