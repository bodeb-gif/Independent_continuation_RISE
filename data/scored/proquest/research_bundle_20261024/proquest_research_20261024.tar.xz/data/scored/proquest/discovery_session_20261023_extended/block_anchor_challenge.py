"""All five placements of the existing five-year inference blocks."""
from associations import *
from collect_results import planned

def run():
    family=68+len(planned());rows=[]
    plans=[('structure_employment_cross_topic_gap','structural_analysis_rows.csv.gz','cross_topic_gap',
        ['net_direction','net_squared','flat_share','log_articles','n_papers']),
        ('common_information_pca_factor','common_information_analysis_rows.csv.gz','pca_factor',
        ['flat_share','log_articles','n_papers','employment_residual']),
        ('common_information_other_after_halves','common_information_analysis_rows.csv.gz','other_topic_mean',
        ['flat_share','log_articles','n_papers','half0_net_direction','half1_net_direction'])]
    for name,filename,feature,controls in plans:
        data=pd.read_csv(OUT/'audits'/filename);data=data[data.test.eq(name)].copy()
        data.origin=pd.PeriodIndex(data.origin,freq='M')
        for offset in range(5):
            r,fit,d=estimate(data,feature,'employment_growth',controls,anchor=1900+offset,wild=True)
            x=fit.model.exog;y=d.employment_growth.to_numpy(float);j=list(fit.model.exog_names).index('tested_predictor')
            groups=(d.year.to_numpy(int)-1900-offset)//5;codes=np.unique(groups);g=len(codes)
            deleted=[]
            for block in codes:
                keep=groups!=block
                deleted.append(np.linalg.lstsq(x[keep],y[keep],rcond=None)[0][j])
            v=np.array(deleted);se=np.sqrt((g-1)/g*np.square(v-r['effect']).sum())
            pj=float(2*st.t.sf(abs(r['effect']/se),g-1))
            rows.append(dict(test=name,anchor_offset=offset,**r,jackknife_se=se,jackknife_p_diagnostic=pj,
                primary_bonferroni_bound=min(1.,r['p_value']*family),
                jackknife_bonferroni_bound=min(1.,pj*family),
                minimum_leaveblock_effect=v.min(),maximum_leaveblock_effect=v.max()))
            print(name,'offset',offset,'primary p',r['p_value'],'jackknife p',pj,flush=True)
    result=pd.DataFrame(rows);result.to_csv(OUT/'block_anchor_challenge.csv',index=False)
    summary=[]
    for name,g in result.groupby('test'):
        summary.append(dict(test=name,minimum_primary_p=g.p_value.min(),maximum_primary_p=g.p_value.max(),
            maximum_primary_bonferroni_bound=g.primary_bonferroni_bound.max(),
            maximum_jackknife_bonferroni_bound=g.jackknife_bonferroni_bound.max(),
            all_anchor_primary_bounds_below_005=bool((g.primary_bonferroni_bound<.05).all()),
            all_anchor_jackknife_bounds_below_005=bool((g.jackknife_bonferroni_bound<.05).all())))
    pd.DataFrame(summary).to_csv(OUT/'block_anchor_summary.csv',index=False)
    save_json(OUT/'audits/block_anchor_challenge.json',dict(status='complete',family_size=family,
        role='All placements of the same declared5-year blocks retained. No anchor is selected to replace the original1900 anchor. Diagnostic Bonferroni bounds refer to the complete204-question family, not to independent new discoveries.',
        limits='Changing a block anchor does not eliminate inter-block dependence or make small-cluster inference exact. Ten-year block sensitivities remain separately reported and do not retain family-wide rejection.',
        code_sha256=digest(__file__),source_check=check_sources()))
    journal('block_anchor_challenge','Completed all five block placements for three related existing coefficients')
    print(pd.DataFrame(summary).to_string(index=False))

if __name__=='__main__':run()
