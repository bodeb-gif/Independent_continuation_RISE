"""Explain calendar covariance sensitivity without changing the fitted effect."""
from associations import *

def run():
    plans=[('structure_employment_cross_topic_gap','structural_analysis_rows.csv.gz',
        ['net_direction','net_squared','flat_share','log_articles','n_papers']),
        ('common_information_pca_factor','common_information_analysis_rows.csv.gz',
        ['flat_share','log_articles','n_papers','employment_residual'])]
    reference=pd.read_csv(OUT/'block_anchor_challenge.csv');summaries=[];blocks=[];years=[]
    for name,filename,controls in plans:
        d=pd.read_csv(OUT/'audits'/filename);d=d[d.test.eq(name)].copy()
        design=select_design(d,controls);x=design.to_numpy(float);y=d.employment_growth.to_numpy(float)
        j=list(design).index('tested_predictor');bread=np.linalg.inv(x.T@x)
        beta=np.linalg.lstsq(x,y,rcond=None)[0];residual=y-x@beta
        score=(x@bread[j])*residual
        for year in sorted(d.year.unique()):
            use=d.year.eq(year).to_numpy();years.append(dict(test=name,year=int(year),n_origins=int(use.sum()),
                uncorrected_score_sum=float(score[use].sum())))
        for offset in range(5):
            groups=(d.year.to_numpy(int)-1900-offset)//5;codes=np.unique(groups);g=len(codes);n,k=x.shape
            correction=g/(g-1)*(n-1)/(n-k)
            contributions=np.array([score[groups==code].sum() for code in codes])*np.sqrt(correction)
            variance=contributions**2;share=variance/variance.sum();se=np.sqrt(variance.sum())
            check=reference[reference.test.eq(name)&reference.anchor_offset.eq(offset)].iloc[0]
            np.testing.assert_allclose(se,check.se,rtol=1e-8,atol=1e-10)
            concentration=1/np.square(share).sum();largest=int(np.argmax(share))
            summaries.append(dict(test=name,anchor_offset=offset,n_blocks=g,se=se,
                inverse_variance_share_concentration=concentration,largest_variance_share=share[largest],
                largest_block_start_year=int(1900+offset+5*codes[largest]),
                largest_block_end_year=int(1904+offset+5*codes[largest]),
                meaning='Concentration is descriptive; it is not a replacement effective sample size or reference degrees of freedom.'))
            for code,value,mass in zip(codes,contributions,share):
                blocks.append(dict(test=name,anchor_offset=offset,block=int(code),
                    start_year=int(1900+offset+5*code),end_year=int(1904+offset+5*code),
                    n_origins=int((groups==code).sum()),signed_score_sum=value,variance_share=mass))
    pd.DataFrame(summaries).to_csv(OUT/'influence_accounting.csv',index=False)
    pd.DataFrame(blocks).to_csv(OUT/'audits/influence_calendar_blocks.csv',index=False)
    yearly=pd.DataFrame(years);yearly.to_csv(OUT/'audits/influence_calendar_years.csv',index=False)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(2,1,figsize=(12,6.5),sharex=True)
    for ax,(name,label) in zip(axes,[('structure_employment_cross_topic_gap','Conditional gap'),('common_information_pca_factor','Shared PCA component')]):
        v=yearly[yearly.test.eq(name)]
        ax.bar(v.year,v.uncorrected_score_sum,color=np.where(v.uncorrected_score_sum>=0,'#126b80','#c97b32'),width=.8)
        ax.axhline(0,color='#8f9ba3',lw=.8);ax.set_title(label,fontsize=11)
        ax.set_ylabel('Annual regression score sum')
        for boundary in range(1950,2011,5):ax.axvline(boundary-.5,color='#c9d1d6',lw=.5,zorder=0)
    axes[-1].set_xlabel('Forecast-origin year');fig.suptitle('Grouping the same annual scores changes the estimated uncertainty',fontsize=14)
    fig.text(.01,.005,'Scores use fitted outcomes and are diagnostics only. Five-year boundary shifts change cancellation within blocks; these values never enter a forecasting feature.',fontsize=9)
    fig.tight_layout(rect=[0,.04,1,.95])
    for suffix in ['png','svg']:fig.savefig(OUT/'figures'/('inference_score_grouping.'+suffix),dpi=170,bbox_inches='tight')
    plt.close(fig)
    save_json(OUT/'audits/influence_accounting.json',dict(status='complete',
        interpretation='The OLS point coefficient is unchanged by the covariance-block anchor. Grouping annual influence scores changes their cancellation and squared block sums, explaining different standard errors. Variance-share concentration is descriptive only; no new p-value or reference distribution is introduced.',
        code_sha256=digest(__file__),source_check=check_sources()))
    journal('influence_accounting','Reconciled anchor-specific standard errors to annual score grouping')
    print(pd.DataFrame(summaries).to_string(index=False))

if __name__=='__main__':run()
