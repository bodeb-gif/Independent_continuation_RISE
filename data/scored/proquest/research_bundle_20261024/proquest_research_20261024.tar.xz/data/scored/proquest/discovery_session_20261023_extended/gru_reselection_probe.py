"""A small paired GRU procedural audit, with all declared seeds retained.

Repeats the existing chronological selection rule; adds no discovery question.
The time budget controls the number of complete draws, never their outcomes.
"""
import time
from refit_multiplier_corrected import *


def run():
    started=time.monotonic();algorithm='gru';maximum=2
    frame,valid=feature_frame();targets=HistoricalTargets()
    model_folder=OUT/'models_boundary_corrected/gru'
    out=model_folder/'reselection_probe';out.mkdir(exist_ok=True)
    stop=dt.datetime.fromisoformat('2026-10-24T11:00:00+00:00')
    hard_stop=dt.datetime.fromisoformat('2026-10-24T12:55:00+00:00')
    spec=dict(created_utc=dt.datetime.now(dt.timezone.utc),code_sha256=digest(__file__),
        canonical_sampler_sha256=digest(OUT/'refit_multiplier_corrected.py'),
        session_utils_sha256=digest(OUT/'session_utils.py'),boundary_rules_sha256=digest(OUT/'boundary_rules.py'),
        recurrent_sha256=digest(OUT/'recurrent_ml.py'),model_data_sha256=digest(OUT/'model_data.py'),
        predictions_sha256=digest(model_folder/'predictions_without_truth.csv'),
        maximum_nonuniform_draws=maximum,seed_sequence=[SEED,823,0],
        stop_new_draws_utc=stop,stop_before_next_annual_fit_utc=hard_stop,
        role='Paired full chronological reselection versus fixed settings at identical weights. All three outer GRU seeds averaged. Small diagnostic only, with no new p-value, selection-adjusted interval or discovery.')
    receipt=out/'implementation.json'
    if receipt.exists():raise FileExistsError('Preserve the existing probe; do not silently restart')
    save_json(receipt,spec)
    journal('gru_reselection_probe','Declared a bounded paired fully nested neural audit; discovery family unchanged',
        maximum_nonuniform_draws=maximum,stop_new_draws_utc=stop,hard_stop_utc=hard_stop)
    original=pd.read_csv(model_folder/'predictions_without_truth.csv')
    original.origin=pd.PeriodIndex(original.origin,freq='M')
    originals={(t,a):g.set_index('origin').prediction for (t,a),g in original.groupby(['task','arm'])}
    audits={}
    for path in (model_folder/'annual').glob('*.json'):
        d=json.loads(path.read_text());audits[d['task'],d['arm'],d['refit_year']]=d
    groups=(valid.year-1977)//5;codes=np.unique(groups)
    rng=np.random.default_rng(np.random.SeedSequence([SEED,823,0]))
    all_rows=[];completed=0;timed_out=False
    try:
        for draw in range(-1,maximum):
            if draw>=0 and dt.datetime.now(dt.timezone.utc)>=stop:break
            mass=np.ones(len(codes)) if draw<0 else rng.exponential(1.,len(codes))
            weights=pd.Series(mass[np.searchsorted(codes,groups)],index=valid)
            forecast_rows=[];selections=[]
            for task in TASKS:
                for year in range(1977,2011):
                    if dt.datetime.now(dt.timezone.utc)>=hard_stop:
                        timed_out=True;break
                    cutoff=pd.Period(f'{year}-01','M');test=valid[valid.year==year]
                    for arm in ARMS:
                        selected=select_weighted(algorithm,task,arm,frame,valid,targets,cutoff,weights)
                        fixed=audits[task,arm,year]['configuration']
                        selections.append(dict(task=task,year=year,arm=arm,changed=selected!=fixed,
                            configuration=selected,original_configuration=fixed))
                        predictions={}
                        for procedure,config in [('reselected',selected),('fixed',fixed)]:
                            if procedure=='fixed' and config==selected:
                                predictions[procedure]=predictions['reselected'];continue
                            train,y,_=eligible(frame,valid,targets,cutoff,task,config['window'])
                            predictions[procedure]=np.mean([
                                predict_weighted(algorithm,task,config,frame,train,y,test,ARMS[arm],weights,seed+year)
                                for seed in GRID['gru']['seeds']],axis=0)
                        for procedure,values in predictions.items():
                            forecast_rows.extend(dict(draw=draw,task=task,year=year,arm=arm,
                                procedure=procedure,origin=str(origin),prediction=float(value))
                                for origin,value in zip(test,values))
                    save_json(out/'current_fit.json',dict(draw=draw,task=task,year=year,
                        selections_so_far=len(selections),elapsed_seconds=time.monotonic()-started,
                        updated_utc=dt.datetime.now(dt.timezone.utc)))
                if timed_out:break
                print('GRU nested draw',draw,task,'fitted',round(time.monotonic()-started,1),flush=True)
            if timed_out:
                # An incomplete reweighting never enters the paired summary.
                pd.DataFrame(forecast_rows).to_csv(out/f'partial_draw_{draw:04}_without_truth.csv',index=False)
                journal('gru_reselection_probe','Stopped incomplete diagnostic draw at fixed closing deadline',draw=draw)
                break
            bare=pd.DataFrame(forecast_rows)
            assert len(bare)==2*4*3*408
            bare.to_csv(out/f'draw_{draw:04}_predictions_without_truth.csv',index=False)
            if draw<0:
                errors=[]
                for (task,arm,procedure),g in bare.groupby(['task','arm','procedure']):
                    values=g.set_index(pd.PeriodIndex(g.origin,freq='M')).prediction
                    error=float(abs(values-originals[task,arm]).max())
                    errors.append(dict(task=task,arm=arm,procedure=procedure,max_error=error))
                    if error>2e-5:raise ValueError('Uniform nested GRU does not reproduce canonical forecasts')
                save_json(out/'uniform_reproduction.json',dict(status='passed',errors=errors,
                    configurations_changed=sum(s['changed'] for s in selections)))
            local=[]
            origins=pd.period_range('1977-01','2010-12',freq='M')
            w=weights.reindex(origins).to_numpy(float)
            for task in TASKS:
                truth=evaluation_truth(origins,task);gain={}
                for procedure in ['fixed','reselected']:
                    losses={}
                    for arm in ARMS:
                        g=bare[bare.task.eq(task)&bare.arm.eq(arm)&bare.procedure.eq(procedure)]
                        g=g.set_index(pd.PeriodIndex(g.origin,freq='M')).reindex(origins)
                        losses[arm]=(g.prediction.to_numpy(float)-truth)**2
                    for newer,older,label in [('macro_coverage_net','macro_coverage','net_minus_macro_coverage'),
                        ('macro_coverage_net_structure','macro_coverage_net','structure_minus_net')]:
                        gain[procedure,label]=float(np.average(losses[older]-losses[newer],weights=w))
                for label in ['net_minus_macro_coverage','structure_minus_net']:
                    fixed=gain['fixed',label];selected=gain['reselected',label]
                    local.append(dict(draw=draw,task=task,comparison=label,fixed_setting_gain=fixed,
                        full_reselection_gain=selected,reselection_minus_fixed=selected-fixed))
            save_json(out/f'draw_{draw:04}.json',dict(draw=draw,block_codes=codes,block_weights=mass,
                results=local,selections=selections,elapsed_seconds=time.monotonic()-started))
            if draw>=0:
                all_rows+=local;completed+=1
                pd.DataFrame(all_rows).to_csv(out/'paired_gains.csv',index=False)
            save_json(out/'status.json',dict(status='running',completed_draws=completed,
                last_completed_draw=draw,maximum_draws=maximum,elapsed_seconds=time.monotonic()-started,
                updated_utc=dt.datetime.now(dt.timezone.utc)))
            journal('gru_reselection_probe','Completed a paired fully nested neural diagnostic draw',
                draw=draw,configurations_changed=sum(s['changed'] for s in selections))
        save_json(out/'status.json',dict(status='complete' if completed==maximum else 'time_limited',
            completed_draws=completed,maximum_draws=maximum,incomplete_last_draw=timed_out,
            elapsed_seconds=time.monotonic()-started,updated_utc=dt.datetime.now(dt.timezone.utc),
            source_check=check_sources(),limitation='Only the complete small probe is reported. No tail confidence interval, p-value or independent forecasting discovery.'))
    except Exception as exc:
        save_json(out/'status.json',dict(status='failed',completed_draws=completed,error=str(exc),
            elapsed_seconds=time.monotonic()-started,updated_utc=dt.datetime.now(dt.timezone.utc)))
        journal('gru_reselection_probe','Neural procedural audit failed; no incomplete result promoted',error=str(exc))
        raise


if __name__=='__main__':
    with threadpool_limits(limits=1):run()
