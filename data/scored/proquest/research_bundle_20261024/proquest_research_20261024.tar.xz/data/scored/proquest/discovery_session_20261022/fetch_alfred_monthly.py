"""Cache historical public as-of UNRATE snapshots, one polite request at a time.

The official bulk form timed out. Each graph CSV explicitly names the requested
vintage; reject responses containing observations from the forecast month or
later. Original provider CSV bytes are preserved without overwrites.
"""
from pathlib import Path
import argparse
from datetime import datetime,timezone
import hashlib
import io
import json
import subprocess
import time
import urllib.parse
import pandas as pd
import numpy as np

OUT=Path(__file__).resolve().parent/'reference/alfred_unrate_monthly'


def check(content,day,origin):
    f=pd.read_csv(io.BytesIO(content))
    expected='UNRATE_'+day.replace('-','')
    if list(f)!=['observation_date',expected]:raise ValueError('Wrong vintage header: '+str(list(f)))
    values=pd.to_numeric(f[expected],errors='coerce')
    dates=pd.to_datetime(f.observation_date)
    if dates.duplicated().any():raise ValueError('Duplicate observation date')
    valid=values.notna()
    if not valid.any():raise ValueError('Empty vintage')
    latest=dates[valid].max()
    if latest>=origin.start_time:raise ValueError('Future/current observation in historical snapshot')
    if not values[valid].between(0,30).all():raise ValueError('Implausible unemployment units')
    return dict(n_observations=int(valid.sum()),first_observation=str(dates[valid].min().date()),
                latest_observation=str(latest.date()),age_months=origin.ordinal-latest.to_period('M').ordinal)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--full',action='store_true');parser.add_argument('--delay',type=float,default=10.);args=parser.parse_args()
    if args.delay<1:raise ValueError('Keep at least one second between new provider requests')
    OUT.mkdir(parents=True,exist_ok=True)
    origins=list(pd.period_range('1960-04','2010-12',freq='M')) if args.full else [pd.Period(m,'M') for m in ['1960-04','1960-05','1966-01','1977-01','1994-02','2010-12']]
    records=[];consecutive_failures=0
    manifest_path=OUT/('manifest_full.json' if args.full else 'manifest_sample.json')
    for number,origin in enumerate(origins,1):
        day=str((origin-1).end_time.date());name='UNRATE_'+day.replace('-','')+'.csv';path=OUT/name
        query=urllib.parse.urlencode(dict(id='UNRATE',vintage_date=day,cosd='1948-01-01',coed=day))
        url='https://alfred.stlouisfed.org/graph/alfredgraph.csv?'+query
        cached=path.exists();error=None
        if cached:
            content=path.read_bytes()
        else:
            # Curl's standard HTTPS path already succeeded for the sample
            # snapshot; do not print provider responses or discard failures.
            result=subprocess.run(['curl','--fail','--location','--silent','--show-error','--max-time','30',url],capture_output=True)
            if result.returncode:
                error=result.stderr.decode(errors='replace')[:250]
            else:content=result.stdout
        if error is None:
            try:
                detail=check(content,day,origin)
                if not cached:path.write_bytes(content)
                record=dict(origin=str(origin),requested_asof=day,url=url,file=str(path),sha256=hashlib.sha256(content).hexdigest(),bytes=len(content),cached=cached,status='ok',**detail)
                consecutive_failures=0
            except Exception as exc:error=str(exc)
        if error is not None:
            consecutive_failures+=1
            record=dict(origin=str(origin),requested_asof=day,url=url,status='failed',error=error)
        records.append(record)
        manifest_path.write_text(json.dumps(dict(provider='ALFRED, Federal Reserve Bank of St. Louis; underlying BLS UNRATE',
            mode='historical as-of snapshots; original provider CSV bytes',updated_utc=datetime.now(timezone.utc).isoformat(),
            requested_count=len(origins),completed_count=len(records),records=records),indent=2)+'\n')
        if number%10==0 or not args.full or error:
            print(f'{number}/{len(origins)} {origin} {record["status"]}'+(' age='+str(record.get('age_months')) if not error else ' '+error),flush=True)
        if consecutive_failures>=3:raise RuntimeError('Three consecutive source failures; stopped without repeated requests')
        if not cached:time.sleep(args.delay)
    failures=sum(r['status']!='ok' for r in records)
    print(f'Finished {len(origins)} origins; failures={failures}',flush=True)
    if failures:raise RuntimeError('Incomplete cache; see manifest')


if __name__=='__main__':main()
