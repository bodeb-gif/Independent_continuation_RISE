"""Explicit future deadline wrapper for the immutable original sampler.

Do not use the original CLI's expired session deadline to resume a run: it can
stop before loading cached draws. This wrapper requires a valid new deadline.
"""
import argparse
from refit_multiplier_corrected import run,threadpool_limits
from session_utils import dt
from validate_saved_inputs import verify_frozen_inputs

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--algorithm',required=True,choices=['linear','hist_gradient_boosting','extra_trees','gru'])
    parser.add_argument('--draws',type=int,required=True)
    parser.add_argument('--reselect',action='store_true')
    parser.add_argument('--stop-utc',required=True,help='Explicit new future ISO8601 cutoff; no implicit extension.')
    args=parser.parse_args();stop=dt.datetime.fromisoformat(args.stop_utc)
    if stop.tzinfo is None or stop<=dt.datetime.now(dt.timezone.utc):
        raise ValueError('Provide an explicit timezone-aware future deadline; no checkpoint status was changed')
    if args.draws<1:raise ValueError('Positive draw count required')
    verify_frozen_inputs()
    with threadpool_limits(limits=1):run(args.algorithm,args.draws,args.reselect,args.stop_utc)
