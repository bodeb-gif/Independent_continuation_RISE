"""Same-sample early-mature versus revised unemployment association diagnostics."""
from model_data import HistoricalTargets
from associations import *

def run():
    targets=HistoricalTargets()
    receipt=json.loads((OUT/'reference/early_truth/manifest.json').read_text())
    for item in receipt['records']:
        if item['status']!='ok':continue
        path=Path(item['file'])
        if digest(path)!=item['sha256']:raise ValueError('Changed supplementary vintage')
        f=pd.read_csv(path,index_col=0);f.index=pd.PeriodIndex(f.index,freq='M');targets.u=targets.u.join(f,how='outer')
    outcome=[];unavailable=[]
    for origin in pd.period_range('1948-02','2010-12',freq='M'):
        cutoff=origin+9;day=(cutoff-1).end_time.normalize();name='UNRATE_'+str(day.date()).replace('-','')
        if name not in targets.u:
            unavailable.append(dict(origin=origin,expected_vintage=name,reason='No exact early-mature snapshot in the frozen archive'));continue
        vintage,available,s=targets.snapshot(cutoff,'unemployment_continuous')
        a,b=s.get(origin-1,np.nan),s.get(origin+5,np.nan)
        if not np.isfinite([a,b]).all():raise ValueError('Missing endpoints in an available exact vintage')
        outcome.append(dict(origin=origin,early_unemployment_improvement=-(b-a),vintage=vintage,
            available_by=available,target_start=origin-1,target_end=origin+5))
    targets_frame=pd.DataFrame(outcome);targets_frame.origin=pd.PeriodIndex(targets_frame.origin,freq='M')
    targets_frame.to_csv(OUT/'audits/association_early_outcomes.csv',index=False)
    pd.DataFrame(unavailable).to_csv(OUT/'audits/association_early_unavailable.csv',index=False)
    plans=[('structure_employment_cross_topic_gap','structural_analysis_rows.csv.gz',
            ['net_direction','net_squared','flat_share','log_articles','n_papers']),
        ('common_information_pca_factor','common_information_analysis_rows.csv.gz',
            ['flat_share','log_articles','n_papers','employment_residual']),
        ('common_information_other_after_halves','common_information_analysis_rows.csv.gz',
            ['flat_share','log_articles','n_papers','half0_net_direction','half1_net_direction'])]
    rows=[]
    for name,filename,controls in plans:
        d=pd.read_csv(OUT/'audits'/filename);d=d[d.test.eq(name)].copy();d.origin=pd.PeriodIndex(d.origin,freq='M')
        d=d.merge(targets_frame,on='origin',how='inner',validate='one_to_one')
        # Keep original full-panel standardized predictor values, rather than
        # changing units when the available vintage era shortens the sample.
        design=select_design(d,controls);x=design.to_numpy(float);j=list(design).index('tested_predictor')
        effects={}
        for label,column in [('revised','employment_growth'),('early_mature','early_unemployment_improvement')]:
            values=d[column].to_numpy(float);effect=np.linalg.lstsq(x,values,rcond=None)[0][j]
            groups=(d.year.to_numpy(int)-1900)//5;deleted=[]
            for block in np.unique(groups):
                keep=groups!=block;deleted.append(np.linalg.lstsq(x[keep],values[keep],rcond=None)[0][j])
            rows.append(dict(test=name,outcome_vintage=label,n=len(d),first_origin=d.origin.min(),last_origin=d.origin.max(),
                effect_per_original_feature_sd=effect,minimum_leaveblock_effect=min(deleted),maximum_leaveblock_effect=max(deleted),
                mean_absolute_outcome_revision=abs(d.employment_growth-d.early_unemployment_improvement).mean(),
                role='Descriptive benchmark-vintage sensitivity; same origins and original feature units; no new p-value.'))
            effects[label]=effect
        print(name,'revised',effects['revised'],'early',effects['early_mature'],'n',len(d),flush=True)
    pd.DataFrame(rows).to_csv(OUT/'association_vintage_challenge.csv',index=False)
    save_json(OUT/'audits/association_vintage_challenge.json',dict(status='complete',
        role='Outcome-vintage robustness of the existing inspected coefficients, not a new primary test or independent discovery.',
        definition='Latest exact month-end unemployment snapshot strictly before origin+9. Endpoint origin+5 plus3months<cutoff. Not a first-release target.',
        n_early_origins=len(targets_frame),n_unavailable_earlier_origins=len(unavailable),
        code_sha256=digest(__file__),source_check=check_sources()))
    journal('association_vintage_challenge','Compared early-mature and revised outcomes on identical source-supported origins')

if __name__=='__main__':run()
