"""A cumulative ledger that retains pending, unsupported and failed questions."""
from session_utils import *
from design import STRUCTURES
from model_data import TASKS

def planned():
    plans=[]
    for t in TOPICS:
        for f in STRUCTURES:plans.append((f'structure_{t}_{f}','structural'))
    for algorithm in ['linear','hist_gradient_boosting','extra_trees','gru']:
        for task in TASKS:
            for comparison in ['net_minus_macro_coverage','structure_minus_net']:
                plans.append((f'ml_{algorithm}_{task}_{comparison}','monthly_ml'))
    for t in ['general_business','markets','prices']:
        plans.append((f'cross_component_{t}','cross_components'))
    for f in [t+'__price_product' for t in ['general_business','employment','markets']]+['joint_covariance']:
        for y in ['general_business_growth','employment_growth','prices_growth']:
            plans.append((f'joint_{f}_{y}','joint_expectations'))
    for t in TOPICS:plans.append((f'timing_{t}_cross_gap_future_minus_recent','cross_timing'))
    for label in ['employment_net','business_net','employment_cross_gap']:
        plans.append(('survey_conditional_'+label,'survey_controls'))
    for a in ['linear','hist_gradient_boosting','extra_trees','gru']:
        for c in ['net_minus_financial_coverage','structure_minus_net']:
            plans.append((f'market_tail_{a}_{c}','market_tail'))
    scope=json.loads((OUT/'specs/scope_indicators.json').read_text())
    for q in scope['questions']:
        plans.append((f'scope_{q["scope"]}_{q["topic"]}_{q["outcome"]}','scope_indicators'))
    assert len(plans)==100 and len(set(p[0] for p in plans))==100
    election=OUT/'specs/election_voice.json'
    if election.exists():
        spec=json.loads(election.read_text())
        for topic in spec['topics']:
            for metric in spec['metrics']:
                plans.append((f'election_{topic}_{metric}','election_voice'))
        assert len(plans)==100+spec['n_new_tests']
    productivity=OUT/'specs/productivity_distribution.json'
    if productivity.exists():
        spec=json.loads(productivity.read_text())
        for sid in spec['outcomes']:
            plans.append(('productivity_distribution_'+sid,'productivity_distribution'))
    common=OUT/'specs/common_information.json'
    if common.exists():
        names=['common_information_peer_employment','common_information_other_after_halves',
               'common_information_pca_factor','common_information_employment_residual']
        plans.extend((name,'common_information') for name in names)
    credibility=OUT/'specs/conditional_credibility.json'
    if credibility.exists():
        spec=json.loads(credibility.read_text())
        for topic in spec['topics']:
            for contrast in spec['contrasts']:
                for condition in spec['conditions']:
                    plans.append((f'credibility_{topic}_{contrast}_{condition}','conditional_credibility'))
    term=OUT/'specs/term_direction_curve.json'
    if term.exists():
        spec=json.loads(term.read_text())
        plans.extend((f'term_direction_curve_{topic}','term_direction_curve') for topic in spec['topics'])
    return plans

def run():
    plans=planned();rows={}
    files=[OUT/p for p in ['structural_tests.csv','joint_tests.csv','timing_tests.csv','survey_tests.csv','scope_tests.csv','election_tests.csv','productivity_tests.csv','common_information_tests.csv','conditional_credibility_tests.csv','term_direction_curve_tests.csv']]
    files+=list((OUT/'models').glob('market_tail_*/tests.csv'))
    for algorithm in ['linear','hist_gradient_boosting','extra_trees','gru']:
        corrected=OUT/'models_boundary_corrected'/algorithm/'tests.csv'
        files.append(corrected if corrected.exists() else OUT/'models'/algorithm/'tests.csv')
    for path in files:
        if not path.exists():continue
        for r in pd.read_csv(path).to_dict('records'):
            if path.parent.name in ['linear','hist_gradient_boosting','extra_trees','gru'] and path.parent.parent.name=='models' and r.get('task')=='unemployment_downturn':
                r.update(status='pending',p_value=1.,reason='Initial float-boundary audit; corrected classifier rerun pending')
            if r['test'] in rows:raise ValueError('Duplicate question '+r['test'])
            r['result_file']=str(path.relative_to(ROOT));rows[r['test']]=r
    cross=OUT/'cross_topic_robustness.csv'
    if cross.exists():
        f=pd.read_csv(cross);f=f[f.source_set.eq('verified')&f.block_years.eq(5)]
        for t in ['general_business','markets','prices']:
            r=f[f.variant.eq('conditional_component_'+t)].iloc[0].to_dict()
            r.update(test='cross_component_'+t,batch='cross_components',
                result_file=str(cross.relative_to(ROOT)),role='Post-screen component interpretation; cannot replace main gap test')
            rows[r['test']]=r
    extension=[]
    for test,batch in plans:
        r=rows.get(test,dict(test=test,batch=batch,p_value=1.,effect=np.nan,n=0,n_blocks=0,status='pending'))
        r['research_round']='extension';extension.append(r)
    unexpected=set(rows)-set(t for t,_ in plans)
    if unexpected:raise ValueError('Unregistered results '+repr(unexpected))
    new=pd.DataFrame(extension)
    # Remove earlier narrower-family q-values before producing the final family.
    new=new.drop(columns=['holm_p','bh_q'],errors='ignore')
    n_new=len(plans);n_total=68+n_new
    new=adjust(new,n_new)
    new_filename=f'extension_{n_new}_tests.csv'
    pooled_filename=f'cumulative_{n_total}_tests.csv'
    new.to_csv(OUT/new_filename,index=False)
    new.to_csv(OUT/'extension_current_tests.csv',index=False)
    prior=pd.read_csv(PRIOR/'session_wide_68_tests.csv').drop(columns=['holm_p','bh_q'],errors='ignore')
    prior['research_round']='prior'
    pooled=adjust(pd.concat([prior,new.drop(columns=['holm_p','bh_q'])],ignore_index=True),n_total)
    pooled.to_csv(OUT/pooled_filename,index=False)
    pooled.to_csv(OUT/'cumulative_current_tests.csv',index=False)
    done=int((new.status.fillna('estimated')!='pending').sum())
    save_json(OUT/'audits/ledger_status.json',dict(planned_new_tests=n_new,completed_new_tests=done,
        prior_tests=68,pooled_family=n_total,pending_new_tests=n_new-done,
        extension_ledger_file=new_filename,pooled_ledger_file=pooled_filename,
        rejected_new_holm=new.loc[new.holm_p<.05,'test'].tolist(),
        rejected_pooled_holm=pooled.loc[pooled.holm_p<.05,'test'].tolist(),
        warning='The two discovery sessions do not exhaust prior project experimentation. These are exploratory families, not an untouched holdout or project-wide error guarantee.'))
    print('Completed',done,'of',n_new,'new tests; pooled family',n_total)
    print(pooled.sort_values('p_value')[['test','effect','p_value','holm_p','bh_q','research_round']].head(12).to_string(index=False))

if __name__=='__main__':run()
