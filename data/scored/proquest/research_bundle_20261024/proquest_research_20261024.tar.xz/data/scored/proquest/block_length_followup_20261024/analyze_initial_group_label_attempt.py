"""Requested shorter-block sensitivity of the frozen GRU forecasts.

No fitting, horizon changes, source changes, or replacement of the sealed study.
Run from the repository root with /opt/anaconda3/bin/python3.
"""
from pathlib import Path
import datetime as dt
import hashlib
import html
import json
import sys

import numpy as np
import pandas as pd
import scipy.stats as st
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
STUDY = OUT.parent / 'discovery_session_20261023_extended'
DRAWS = 99999
SEED = 20261024


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2, default=str) + '\n')


def wild_cluster(y, codes, seed):
    """Null-restricted intercept wild-t, with finite-sample cluster correction."""
    _, inv = np.unique(codes, return_inverse=True)
    g = int(inv.max()) + 1
    n = len(y)
    mass = np.bincount(inv, minlength=g).astype(float)
    totals = np.bincount(inv, weights=y, minlength=g)
    effect = float(np.mean(y))
    se = np.sqrt(g / (g - 1) * np.square(totals - effect * mass).sum()) / n
    observed = abs(effect / se)
    exact = g <= 18
    count = 1 << g if exact else DRAWS
    rng = np.random.default_rng(seed)
    extreme = 0
    for start in range(0, count, 10000):
        batch = min(10000, count - start)
        if exact:
            ids = np.arange(start, start + batch, dtype=np.uint64)[:, None]
            signs = 2 * ((ids >> np.arange(g, dtype=np.uint64)) & 1).astype(float) - 1
        else:
            signs = rng.integers(0, 2, size=(batch, g), dtype=np.int8).astype(float) * 2 - 1
        means = signs @ totals / n
        scores = signs * totals - means[:, None] * mass
        ses = np.sqrt(g / (g - 1) * np.square(scores).sum(axis=1)) / n
        assert np.isfinite(ses).all() and (ses > 0).all()
        extreme += int((abs(means / ses) >= observed - 1e-12).sum())
    p_wild = extreme / count if exact else (extreme + 1) / (count + 1)
    p_t = float(2 * st.t.sf(observed, g - 1))
    # Independent library calculation of the cluster sandwich.
    fit = sm.OLS(y, np.ones((n, 1))).fit(cov_type='cluster',
        cov_kwds={'groups': codes, 'use_correction': True}, use_t=True)
    np.testing.assert_allclose(se, fit.bse[0], rtol=1e-10, atol=1e-12)
    q = st.t.ppf(.975, g - 1)
    return dict(effect=effect, se=se, low=effect-q*se, high=effect+q*se,
        p_cluster_t=p_t, p_wild=p_wild, p_value=max(p_t, p_wild),
        n=n, n_blocks=g, wild_exact=exact, wild_draws=count, wild_extreme=extreme)


def hac(y, lag):
    n = len(y)
    z = y - y.mean()
    total = z @ z
    for k in range(1, lag + 1):
        total += 2 * (1 - k / (lag + 1)) * (z[k:] @ z[:-k])
    se = float(np.sqrt(total / n**2 * n / (n - 1)))
    fit = sm.OLS(y, np.ones((n, 1))).fit(cov_type='HAC',
        cov_kwds={'maxlags': lag, 'use_correction': True}, use_t=True)
    np.testing.assert_allclose(se, fit.bse[0], rtol=1e-10, atol=1e-12)
    p = float(2 * st.t.sf(abs(y.mean()/se), n-1))
    q = st.t.ppf(.975, n-1)
    return dict(effect=float(y.mean()), se=se, low=y.mean()-q*se,
        high=y.mean()+q*se, p_value=p, n=n)


def run():
    inputs = [STUDY/'cumulative_current_tests.csv',
        STUDY/'models_boundary_corrected/gru/predictions.csv',
        STUDY/'models_boundary_corrected/gru/tests.csv',
        STUDY/'models/market_tail_gru/predictions.csv',
        STUDY/'models/market_tail_gru/tests.csv', STUDY/'final_manifest.json']
    hashes = {str(p.relative_to(ROOT)): digest(p) for p in inputs}
    sealed=json.loads((STUDY/'final_manifest.json').read_text())
    for path in inputs[:-1]:
        assert digest(path)==sealed['derived_files'][str(path.relative_to(STUDY))]
    for name, expected in sealed['original_source_hashes'].items():
        assert digest(ROOT/name)==expected
    specification = dict(created_utc=dt.datetime.now(dt.timezone.utc),
        interpretation='Inference blocks, not forecast horizons. Forecast horizon stays six months.',
        scope='All 8 macro GRU comparisons plus both stock-tail GRU comparisons; no other corpus.',
        forecast_policy='Frozen historical time-block predictions; no refitting or new predictor selection.',
        blocks_months=[12, 6], offsets='All 12 annual and all 6 half-year placements retained.',
        primary_display_anchor='January; other anchors cannot replace it.',
        statistic='Two-sided maximum of cluster-t and null-restricted wild-t p-values.',
        random_sign_draws=DRAWS, random_seed=SEED,
        hac_lags=[6, 12, 24], hac_reference='Bartlett Newey-West, n/(n-1), t(n-1) reference; diagnostic only.',
        multiplicity='210 new method/comparison pairs plus original 204 = 414 conservative local family. Also show 204-question reference replacing only the matching original p-value. Neither is a fresh holdout/project-wide error guarantee.',
        warning='Short disjoint blocks can miss dependence across their boundaries. No specification is chosen by its p-value. Inference conditions on fitted predictions.',
        source_hashes=hashes, code_sha256=digest(__file__))
    specpath = OUT/'specification.json'
    if specpath.exists():
        old=json.loads(specpath.read_text())
        assert old['source_hashes']==hashes and old['code_sha256']==digest(__file__)
    else:
        save('specification.json',specification)
    original = pd.read_csv(STUDY/'cumulative_current_tests.csv')
    datasets = []
    macro = pd.read_csv(inputs[1])
    for task, data in macro.groupby('task'):
        datasets.append((task, data, 'macro_coverage', 'ml_gru_'+task+'_'))
    datasets.append(('market_tail', pd.read_csv(inputs[3]), 'financial_coverage', 'market_tail_gru_'))
    rows=[]; baseline=[]
    for task, data, base, prefix in datasets:
        losses=data.pivot(index='origin',columns='arm',values='loss').sort_index()
        calendar=pd.PeriodIndex(losses.index,freq='M')
        assert calendar.is_unique and list(calendar)==list(pd.period_range(calendar.min(),calendar.max(),freq='M'))
        comparisons=[(base,base+'_net','net_minus_'+base),
            (base+'_net',base+'_net_structure','structure_minus_net')]
        for old, new, label in comparisons:
            test=prefix+label
            y=(losses[old]-losses[new]).to_numpy(float)
            assert np.isfinite(y).all()
            saved=original.set_index('test').loc[test]
            assert abs(saved.effect-y.mean())<1e-12
            # Reproduce the original 5-year inference before shortening blocks.
            anchor=1930 if task=='market_tail' else 1977
            primary=wild_cluster(y,(calendar.year-anchor)//5,SEED)
            np.testing.assert_allclose(primary['p_value'],saved.p_value,rtol=1e-9,atol=1e-12)
            baseline.append(dict(test=test,task=task,method='original_5_year',**primary))
            for months in [12,6]:
                for offset in range(months):
                    codes=(calendar.asi8-offset)//months
                    result=wild_cluster(y,codes,SEED+1000*months+offset)
                    rows.append(dict(test=test,task=task,method='calendar_blocks',
                        block_months=months,offset_months=offset,**result))
            for lag in [6,12,24]:
                rows.append(dict(test=test,task=task,method='newey_west',hac_lag_months=lag,**hac(y,lag)))
            print(test,'done',flush=True)
    results=pd.DataFrame(rows)
    assert len(results)==210 and len(baseline)==10
    pvalues=np.r_[original.p_value.to_numpy(),results.p_value.to_numpy()]
    results['holm_joint_414']=multipletests(pvalues,method='holm')[1][len(original):]
    references=[]
    for row in results.itertuples(index=False):
        p=original.p_value.copy();mask=original.test.eq(row.test)
        assert mask.sum()==1
        p.loc[mask]=row.p_value
        references.append(multipletests(p,method='holm')[1][np.flatnonzero(mask)[0]])
    results['holm_204_single_replacement_reference']=references
    results.to_csv(OUT/'all_sensitivities.csv',index=False)
    pd.DataFrame(baseline).to_csv(OUT/'original_5_year_reproduction.csv',index=False)
    lead='ml_gru_unemployment_downturn_structure_minus_net'
    display=results[(results.test.eq(lead)) & ((results.method.eq('calendar_blocks') & results.offset_months.eq(0)) | results.method.eq('newey_west'))]
    display.to_csv(OUT/'employment_rise_comparison.csv',index=False)
    summary=results.groupby(['test','method','block_months'],dropna=False).agg(
        specifications=('p_value','size'),minimum_p=('p_value','min'),maximum_p=('p_value','max'),
        minimum_joint_holm=('holm_joint_414','min'),maximum_joint_holm=('holm_joint_414','max')).reset_index()
    summary.to_csv(OUT/'anchor_summary.csv',index=False)
    assert all(digest(ROOT/name)==value for name,value in hashes.items())
    validation=dict(status='passed',completed_utc=dt.datetime.now(dt.timezone.utc),
        original_five_year_tests_reproduced=10,independent_cluster_sandwich_checks=190,
        independent_hac_checks=30,followup_rows=len(results),original_inputs_unchanged=True,
        original_family_size=len(original),expanded_diagnostic_family_size=len(pvalues),
        joint_rejections=int((results.holm_joint_414<.05).sum()),
        minimum_p=float(results.p_value.min()),minimum_joint_holm=float(results.holm_joint_414.min()))
    save('validation.json',validation)
    text='''<!doctype html><html lang="en"><meta charset="utf-8"><title>GRU block-length follow-up</title>
    <style>body{font:16px/1.55 system-ui;max-width:1100px;margin:40px auto;padding:20px}table{border-collapse:collapse;font-size:12px}th,td{padding:7px;border-bottom:1px solid #ddd}.scroll{overflow:auto}</style>
    <h1>GRU: shorter inference blocks</h1><p>This requested post-hoc sensitivity keeps the original forecasts, features, six-month horizon and outcomes fixed. It changes their uncertainty calculation. All calendar placements are retained; January supplies the main display. Shorter blocks do not create independent economic observations.</p>
    <p>The old 204-question study remains sealed. A conservative local joint correction includes those 204 original tests plus all 210 new method/comparison pairs. The single-replacement 204-question adjustment is a reference calculation, not a new primary specification or project-wide guarantee.</p>
    <h2>Previously discussed unemployment-rise comparison</h2><p>Adding structures to the GRU with topic directions. Positive loss gain means lower Brier loss. Pointwise intervals are not simultaneous. The original five-year unadjusted p-value was 0.043966.</p><div class="scroll">'''
    columns=['method','block_months','hac_lag_months','n_blocks','effect','se','p_value','holm_204_single_replacement_reference','holm_joint_414']
    text+=display[columns].to_html(index=False,float_format=lambda x:f'{x:.6g}',na_rep='')+'</div>'
    text+='<h2>Every retained anchor and comparison</h2><div class="scroll">'+summary.to_html(index=False,float_format=lambda x:f'{x:.6g}',na_rep='')+'</div>'
    text+='''<p>Monthly six-month forecasts have overlapping outcomes. Disjoint six- or twelve-month blocks may leave relevant correlation across boundaries. Newey-West diagnostics retain lagged covariance, but their bandwidths and asymptotic approximations also require assumptions. These checks condition on fitted forecasts; they do not reproduce model selection uncertainty, validate machine labels, or establish a fresh discovery.</p>
    <p>Method references: <a href="https://www.nber.org/papers/w18391">Diebold: comparing predictive accuracy and model-search limits</a>; <a href="https://www.nber.org/papers/t0055">Newey and West: autocorrelation-consistent covariance</a>.</p>
    <p><a href="all_sensitivities.csv">All 210 diagnostics</a> · <a href="specification.json">Specification</a> · <a href="validation.json">Numerical validation</a></p></html>'''
    (OUT/'report.html').write_text(text)
    print(display[columns].to_string(index=False),flush=True)
    print(json.dumps(validation,indent=2),flush=True)


if __name__=='__main__':
    run()
