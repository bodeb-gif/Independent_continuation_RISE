"""Near/far outlook ordering versus deterministic 6/12-month direction changes."""
from associations import *
from proquest_descriptive import load_reference, realized_outcome, BANDS

SPEC=json.loads((OUT/'specs/term_direction_curve.json').read_text())

def direction_targets():
    series,meta=load_reference();rows=[]
    previous=json.loads((PRIOR/'primary_manifest.json').read_text())['references']
    for topic,receipt in meta.items():
        if receipt['sha256']!=previous[topic]['sha256']:raise ValueError('Reference changed '+topic)
    for origin in pd.period_range('1900-01','2010-12',freq='M'):
        for topic in TOPICS:
            rec=dict(origin=origin,topic=topic)
            values=[]
            for months in [6,12]:
                label,basis,reason=realized_outcome(series,topic,origin-1,months)
                if label is None or basis=='NBER proxy':value=np.nan
                elif topic=='employment':value={'down':1.,'flat':0.,'up':-1.}[label]
                else:value={'improve':1.,'up':1.,'flat':0.,'worsen':-1.,'down':-1.}[label]
                rec[f'direction_{months}m']=value;rec[f'basis_{months}m']=basis
                values.append(value)
            rec['realized_direction_curve']=values[1]-values[0];rows.append(rec)
    result=pd.DataFrame(rows)
    result.to_csv(OUT/'cache/term_direction_targets.csv',index=False)
    save_json(OUT/'audits/term_direction_targets.json',dict(reference=meta,bands=BANDS,
        scorer_sha256=digest(ROOT/'src/proquest_descriptive.py'),
        mapping='Unemployment down is improvement; CPI up is rising prices. 12month direction minus6month direction from same origin-1 baseline.'))
    return result

def run():
    targets=direction_targets();rows=[];sensitivity=[];samples=[]
    for source in ['verified','raw']:
        f=inputs(source).merge(targets,on=['origin','topic'],validate='one_to_one')
        for topic in SPEC['topics']:
            d=f[f.topic.eq(topic)].copy();test='term_direction_curve_'+topic
            controls=['net_direction','net_squared','flat_share','log_articles','n_papers']
            if topic=='markets':controls+=['stock_past_return','stock_past_volatility']
            r,fit,used=estimate(d,'term_slope','realized_direction_curve',controls,wild=True)
            row=dict(test=test,batch='term_direction_curve',topic=topic,feature='term_slope',
                outcome='realized_direction_curve',block_years=5,**r)
            if source=='verified':rows.append(row);samples.append(used.assign(test=test))
            else:sensitivity.append(dict(variant='raw',**row))
            if source=='verified' and fit is not None:
                for label,sub,span in [('blocks_2',d,2),('blocks_10',d,10),
                    ('exclude_2007_2009',d[~d.year.between(2007,2009)],5),
                    ('pre_1980',d[d.year<1980],5),('1980_onward',d[d.year>=1980],5)]:
                    rr,_,_=estimate(sub,'term_slope','realized_direction_curve',controls,span=span,wild=False)
                    sensitivity.append(dict(test=test,variant=label,**rr))
                from proquest_vintages import CORE_FEATURES
                rr,_,_=estimate(d,'term_slope','realized_direction_curve',controls+list(CORE_FEATURES),wild=True)
                sensitivity.append(dict(test=test,variant='vintage_macro_controls',**rr))
            print(source,test,r['status'],r['effect'],r['p_value'],r['n'],flush=True)
    result=adjust(pd.DataFrame(rows),136);assert len(result)==4
    result.to_csv(OUT/'term_direction_curve_tests.csv',index=False)
    pd.DataFrame(sensitivity).to_csv(OUT/'term_direction_curve_sensitivities.csv',index=False)
    pd.concat(samples,ignore_index=True).to_csv(OUT/'audits/term_direction_curve_analysis_rows.csv.gz',index=False,
        compression={'method':'gzip','mtime':0})
    save_json(OUT/'audits/term_direction_curve_manifest.json',dict(status='complete',n_tests=4,
        code_sha256=digest(__file__),source_count=check_sources(),interpretation=SPEC['interpretation']))
    journal('term_direction_curve','Completed all four near/far direction-ordering questions')
    print(result[['test','effect','low','high','p_value','holm_p','n','n_blocks']].to_string(index=False))

if __name__=='__main__':run()
