"""Chronological block-multiplier model refits, including linear reselection."""
import argparse
import datetime as dt
import time
import warnings
from monthly_ml import configurations, fallback, GRID
from model_data import *
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge,LogisticRegression
from sklearn.ensemble import HistGradientBoostingRegressor,HistGradientBoostingClassifier
from sklearn.ensemble import ExtraTreesRegressor,ExtraTreesClassifier
from threadpoolctl import threadpool_limits

def weighted_median(values,weights):
    result=[]
    for j in range(values.shape[1]):
        good=np.isfinite(values[:,j])&(weights>0)
        if not good.any():result.append(0.);continue
        v=values[good,j];w=weights[good];order=np.argsort(v,kind='stable');v=v[order];w=w[order]
        c=np.cumsum(w);half=c[-1]/2;k=int(np.searchsorted(c,half))
        value=(v[k]+v[k+1])/2 if k+1<len(v) and abs(c[k]-half)<=1e-12*max(1.,c[-1]) else v[k]
        result.append(value)
    return np.asarray(result)

def transform(a,b,w):
    if np.all(w==w[0]):
        # Preserve the exact unweighted numerical path at the uniform case.
        # Weighted StandardScaler can produce a negative rounding residual for
        # constant features; tree histogram ties can also change at a last bit.
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',RuntimeWarning)
            med=np.nanmedian(a,axis=0)
        med=np.where(np.isfinite(med),med,0.)
        aa=np.where(np.isnan(a),med,a);bb=np.where(np.isnan(b),med,b)
        scaler=StandardScaler().fit(aa)
        return np.column_stack([scaler.transform(aa),np.isnan(a)]),np.column_stack([scaler.transform(bb),np.isnan(b)])
    med=weighted_median(a,w)
    aa=np.where(np.isnan(a),med,a);bb=np.where(np.isnan(b),med,b)
    mean=np.average(aa,axis=0,weights=w)
    # Explicit centered squares are nonnegative, including constant columns.
    variance=np.average((aa-mean)**2,axis=0,weights=w)
    bound=(len(w)*np.finfo(float).eps*variance+(len(w)*mean*np.finfo(float).eps)**2)
    scale=np.sqrt(variance);scale[variance<=bound]=1.
    left=np.column_stack([(aa-mean)/scale,np.isnan(a)])
    right=np.column_stack([(bb-mean)/scale,np.isnan(b)])
    if not np.isfinite(left).all() or not np.isfinite(right).all():raise ValueError('Invalid weighted preprocessing')
    return left,right

def predict_weighted(algorithm,task,config,frame,train,y,test,features,weights,seed):
    w=weights.reindex(train).to_numpy(float);w=w/w.mean()
    if algorithm=='gru':
        return neural_weighted(task,config,frame,train,y,test,features,w,seed)
    a,b=transform(frame.loc[train,features].to_numpy(float),frame.loc[test,features].to_numpy(float),w)
    binary=task.endswith('downturn')
    if binary and len(np.unique(y))<2:return np.full(len(test),(np.dot(w,y)+1)/(w.sum()+2))
    if algorithm=='linear':
        fit=LogisticRegression(C=config['value'],max_iter=3000,solver='lbfgs',random_state=seed) if binary else Ridge(alpha=config['value'])
    elif algorithm=='hist_gradient_boosting':
        cls=HistGradientBoostingClassifier if binary else HistGradientBoostingRegressor
        fit=cls(max_iter=config['iterations'],max_leaf_nodes=config['leaves'],learning_rate=.05,
                l2_regularization=10,min_samples_leaf=30,early_stopping=False,random_state=seed)
    else:
        cls=ExtraTreesClassifier if binary else ExtraTreesRegressor
        fit=cls(n_estimators=300,max_depth=config['depth'],min_samples_leaf=config['leaf'],
                max_features=.8,bootstrap=False,n_jobs=1,random_state=seed)
    # Using None for uniform weights reproduces estimator optimized fast paths.
    fit.fit(a,y,sample_weight=None if np.all(w==w[0]) else w)
    return fit.predict_proba(b)[:,list(fit.classes_).index(1)] if binary else fit.predict(b)

def neural_weighted(task,config,frame,train,y,test,features,w,seed):
    import torch
    from torch import nn
    from recurrent_ml import MonthlyGRU,sequences
    a=sequences(frame,train,features);b=sequences(frame,test,features);shape=a.shape
    aw,bw=transform(a.reshape(-1,shape[-1]),b.reshape(-1,shape[-1]),np.repeat(w,shape[1]))
    a=aw.reshape(len(a),shape[1],-1).astype('float32');b=bw.reshape(len(b),shape[1],-1).astype('float32')
    # transform returns [scaled features,missing flags] in exactly that order.
    torch.manual_seed(seed);rng=np.random.default_rng(seed)
    model=MonthlyGRU(a.shape[-1],config['hidden']);optimizer=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.01)
    binary=task.endswith('downturn')
    center=0. if binary else float(np.average(y,weights=w))
    scale=1. if binary else max(float(np.sqrt(np.average((y-center)**2,weights=w))),1e-6)
    with torch.no_grad():
        if binary:
            prior=(np.dot(w,y)+1)/(w.sum()+2);model.output[-1].bias.fill_(float(np.log(prior/(1-prior))))
        else:model.output[-1].bias.zero_()
    x=torch.from_numpy(a);z=torch.from_numpy(b);label=torch.from_numpy(((y-center)/scale).astype('float32'))
    mass=torch.from_numpy(w.astype('float32'))
    criterion=nn.BCEWithLogitsLoss(reduction='none') if binary else nn.MSELoss(reduction='none')
    for _ in range(config['epochs']):
        model.train();order=rng.permutation(len(train))
        for start in range(0,len(order),64):
            ix=order[start:start+64];optimizer.zero_grad(set_to_none=True)
            loss=(criterion(model(x[ix]),label[ix])*mass[ix]).mean()
            loss.backward();nn.utils.clip_grad_norm_(model.parameters(),1.);optimizer.step()
    model.eval()
    with torch.no_grad():
        v=model(z);return v.sigmoid().numpy() if binary else v.numpy()*scale+center

def select_weighted(algorithm,task,arm,frame,valid,targets,outer,weights):
    folds=inner_folds(frame,valid,targets,outer,task)
    if not folds:
        c=fallback(algorithm)
        if algorithm=='linear' and not task.endswith('downturn'):c=dict(value=10.,window=None)
        return c
    configs=configurations(algorithm,task);scores=[]
    for config in configs:
        numerator=0.;denominator=0.
        for fold in folds:
            train,y,_=eligible(frame,valid,targets,fold['origin'],task,config['window'])
            p=predict_weighted(algorithm,task,config,frame,train,y,fold['validation'],ARMS[arm],weights,113+fold['origin'].year)
            v=weights.reindex(fold['validation']).to_numpy(float)
            numerator+=np.dot(v,(p-fold['y_validation'])**2);denominator+=v.sum()
        scores.append(numerator/denominator)
    return configs[int(np.argmin(scores))]

def run(algorithm,draws,reselect=False,stop_utc='2026-10-24T12:50:00+00:00'):
    started=time.monotonic();frame,valid=feature_frame();targets=HistoricalTargets()
    folder=OUT/'models'/algorithm;out=folder/'refit_multiplier';out.mkdir(exist_ok=True)
    if not (folder/'completion.json').exists():raise ValueError('Initial algorithm has not finished')
    original=pd.read_csv(folder/'predictions_without_truth.csv');original['origin']=pd.PeriodIndex(original.origin,freq='M')
    originals={(t,a):g.set_index('origin').prediction for (t,a),g in original.groupby(['task','arm'])}
    audits={}
    for path in (folder/'annual').glob('*.json'):
        audit=json.loads(path.read_text());audits[(audit['task'],audit['arm'],audit['refit_year'])]=audit
    groups=(valid.year-1977)//5;codes=np.unique(groups);rng=np.random.default_rng(SEED+821)
    all_rows=[];changes=[];uniform_errors=[]
    stop=dt.datetime.fromisoformat(stop_utc)
    for draw in range(-1,draws):
        if draw>=0 and dt.datetime.now(dt.timezone.utc)>=stop:break
        exp=np.ones(len(codes)) if draw==-1 else rng.exponential(1.,len(codes))
        weights=pd.Series(exp[np.searchsorted(codes,groups)],index=valid)
        done=out/f'draw_{draw:04}.json'
        if done.exists():
            all_rows+=json.loads(done.read_text())['results'];continue
        gains={};metrics={};configuration_changes=0;total_configurations=0
        for task in TASKS:
            task_predictions={arm:[] for arm in ARMS}
            for year in range(1977,2011):
                outer=pd.Period(f'{year}-01','M');test=valid[valid.year==year]
                for arm in ARMS:
                    original_config=audits[(task,arm,year)]['configuration']
                    config=select_weighted(algorithm,task,arm,frame,valid,targets,outer,weights) if reselect else original_config
                    configuration_changes+=int(config!=original_config);total_configurations+=1
                    train,y,_=eligible(frame,valid,targets,outer,task,config['window'])
                    seeds=GRID['gru']['seeds'] if algorithm=='gru' else [113]
                    p=np.mean([predict_weighted(algorithm,task,config,frame,train,y,test,ARMS[arm],weights,seed+year)
                        for seed in seeds],axis=0)
                    task_predictions[arm].append(pd.Series(p,index=test))
            truth=evaluation_truth(pd.period_range('1977-01','2010-12',freq='M'),task)
            losses={}
            for arm,parts in task_predictions.items():
                values=pd.concat(parts).sort_index();w=weights.reindex(values.index).to_numpy(float)
                losses[arm]=(values.to_numpy()-truth)**2
                metrics[arm]=float(np.average(losses[arm],weights=w))
                if draw==-1:
                    error=float(abs(values-originals[(task,arm)]).max())
                    uniform_errors.append(dict(task=task,arm=arm,max_error=error))
                    tolerance=2e-5 if algorithm=='gru' else 1e-8
                    if error>tolerance:raise ValueError(f'Uniform-weight reproduction failed {algorithm} {task} {arm}: {error}')
            for newer,older,label in [('macro_coverage_net','macro_coverage','net_minus_macro_coverage'),
                ('macro_coverage_net_structure','macro_coverage_net','structure_minus_net')]:
                gain=float(np.average(losses[older]-losses[newer],weights=w))
                gains[(task,label)]=gain
        rows=[dict(draw=draw,algorithm=algorithm,task=task,comparison=label,gain=value,
            configurations_changed=configuration_changes,configurations_total=total_configurations)
            for (task,label),value in gains.items()]
        save_json(done,dict(draw=draw,block_codes=codes,block_weights=exp,results=rows,
            elapsed_seconds=time.monotonic()-started))
        if draw==-1:
            save_json(out/'uniform_reproduction.json',dict(status='passed',errors=uniform_errors,
                configurations_changed=configuration_changes))
            journal('refit_multiplier','Uniform weights reproduce original forecasts',algorithm=algorithm)
        else:all_rows+=rows
        if all_rows:
            table=pd.DataFrame(all_rows);table.to_csv(out/'draws.csv',index=False)
            summary=table.groupby(['algorithm','task','comparison']).gain.agg(
                draws='size',mean='mean',median='median',low=lambda v:v.quantile(.025),high=lambda v:v.quantile(.975),
                positive_fraction=lambda v:(v>0).mean()).reset_index()
            summary.to_csv(out/'intervals.csv',index=False)
        save_json(out/'status.json',dict(status='running',algorithm=algorithm,last_completed_draw=draw,
            maximum_draws=draws,reselect=reselect,elapsed_seconds=time.monotonic()-started,updated_utc=dt.datetime.now(dt.timezone.utc)))
        print(algorithm,'draw',draw,'complete',round(time.monotonic()-started,1),'seconds',flush=True)
        journal('refit_multiplier','Completed model reweighting draw',algorithm=algorithm,draw=draw,
            reselection=reselect,configuration_changes=configuration_changes)
    completed=len(all_rows)//8
    save_json(out/'status.json',dict(status='complete' if completed==draws else 'time_limited',algorithm=algorithm,
        completed_draws=completed,maximum_draws=draws,reselect=reselect,
        elapsed_seconds=time.monotonic()-started,updated_utc=dt.datetime.now(dt.timezone.utc),source_count=check_sources()))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--algorithm',required=True,
        choices=['linear','hist_gradient_boosting','extra_trees','gru'])
    parser.add_argument('--draws',type=int,required=True);parser.add_argument('--reselect',action='store_true')
    args=parser.parse_args()
    with threadpool_limits(limits=1):run(args.algorithm,args.draws,args.reselect)
