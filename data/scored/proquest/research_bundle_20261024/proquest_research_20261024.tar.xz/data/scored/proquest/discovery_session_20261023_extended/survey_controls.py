"""Compare explicit forecast signals with consumer current/expected conditions."""
from associations import *

def survey_panel(buffer=2):
    p=OUT/'reference/tbmiccice.csv';f=pd.read_csv(p)
    date=pd.to_datetime(f.Month.astype(str)+' '+f.YYYY.astype(str),format='%B %Y')
    f.index=pd.PeriodIndex(date,freq='M');f=f[f.index<=pd.Period('2010-12','M')]
    if not f.index.is_unique:raise ValueError('Duplicate survey date')
    rows=[]
    for origin in pd.period_range('1900-01','2010-12',freq='M'):
        row=dict(origin=origin)
        for field in ['ICC','ICE']:
            s=pd.to_numeric(f[field],errors='coerce').dropna()
            older=s[s.index<=origin-buffer]
            if len(older) and origin.ordinal-older.index[-1].ordinal<=5:
                month=older.index[-1];row[field]=older.iloc[-1]
                row[field+'_observation']=month;row[field+'_age']=origin.ordinal-month.ordinal
                earlier=s[s.index<=month-6]
                row[field+'_change_6m']=older.iloc[-1]-earlier.iloc[-1] if len(earlier) and month.ordinal-earlier.index[-1].ordinal<=9 else np.nan
            else:
                row[field]=np.nan;row[field+'_age']=np.nan;row[field+'_change_6m']=np.nan
        rows.append(row)
    return pd.DataFrame(rows)

def run():
    primary=[];sensitivity=[];samples=[]
    survey_cols=['ICC','ICE','ICC_change_6m','ICE_change_6m','ICC_age','ICE_age']
    for source in ['verified','raw']:
        data=inputs(source)
        for topic,feature,outcome,label in [('employment','net_direction','employment_growth','employment_net'),
            ('general_business','net_direction','general_business_growth','business_net'),
            ('employment','cross_topic_gap','employment_growth','employment_cross_gap')]:
            d=data[data.topic.eq(topic)].copy()
            if topic=='general_business':d=d[d.origin>=pd.Period('1919-02','M')]
            base=['net_squared','flat_share','log_articles','n_papers']
            if feature=='cross_topic_gap':base+=['net_direction']
            test='survey_conditional_'+label
            joined=d.merge(survey_panel(),on='origin',validate='one_to_one')
            r,_,used=estimate(joined,feature,outcome,base+survey_cols,wild=True)
            row=dict(test=test,batch='survey_controls',topic=topic,feature=feature,outcome=outcome,block_years=5,**r)
            if source=='verified':primary.append(row);samples.append(used.assign(test=test))
            else:sensitivity.append(dict(variant='raw',**row))
            if source=='verified':
                for span in [2,10]:
                    rr,_,_=estimate(joined,feature,outcome,base+survey_cols,span=span,wild=True)
                    sensitivity.append(dict(test=test,variant=f'blocks_{span}',**rr))
                for buffer in [1,3]:
                    alternate=d.merge(survey_panel(buffer),on='origin',validate='one_to_one')
                    rr,_,_=estimate(alternate,feature,outcome,base+survey_cols,wild=True)
                    sensitivity.append(dict(test=test,variant=f'survey_buffer_{buffer}',**rr))
                for variant,columns in [('survey_levels_only',base+['ICC','ICE','ICC_age','ICE_age']),
                    ('vintage_macro',base+survey_cols+list(__import__('proquest_vintages').CORE_FEATURES))]:
                    rr,_,_=estimate(joined,feature,outcome,columns,wild=True)
                    sensitivity.append(dict(test=test,variant=variant,**rr))
            print(source,test,r['effect'],r['p_value'],r['n'],flush=True)
    result=adjust(pd.DataFrame(primary),86);result.to_csv(OUT/'survey_tests.csv',index=False)
    pd.DataFrame(sensitivity).to_csv(OUT/'survey_sensitivities.csv',index=False)
    pd.concat(samples,ignore_index=True).to_csv(OUT/'audits/survey_analysis_rows.csv.gz',index=False,
        compression={'method':'gzip','mtime':0})
    survey_panel().to_csv(OUT/'cache/survey_retrospective_controls.csv',index=False)
    save_json(OUT/'audits/survey_manifest.json',dict(status='complete',n_tests=3,
        input_sha256=digest(OUT/'reference/tbmiccice.csv'),code_sha256=digest(__file__),
        source_count=check_sources(),role='Retrospective external covariates only; no survey model-feature real-time availability claim.'))
    journal('survey_controls','Completed all three survey-conditional associations')
    print(result[['test','effect','low','high','p_value','holm_p','n','n_blocks']].to_string(index=False))

if __name__=='__main__':run()
