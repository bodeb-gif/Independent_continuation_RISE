"""Build a self-contained research report and standalone scientific figures."""
from common import *
import base64
import html
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter

COLORS={'ink':'#182d44','teal':'#147d83','gold':'#b87a22','red':'#b24a48','gray':'#738396'}


def savefig(fig,name):
    fig.savefig(OUT/(name+'.png'),dpi=200,bbox_inches='tight')
    fig.savefig(OUT/(name+'.svg'),bbox_inches='tight')
    plt.close(fig)


def figure(name,caption):
    data=base64.b64encode((OUT/(name+'.png')).read_bytes()).decode()
    return f'<figure><img src="data:image/png;base64,{data}" alt="{html.escape(caption)}"><figcaption>{caption}</figcaption></figure>'


def table(frame,columns=None,formats=None):
    d=frame[columns].copy() if columns else frame.copy()
    for col,fmt in (formats or {}).items():
        if col in d:d[col]=d[col].map(lambda v:fmt.format(v) if pd.notna(v) else '—')
    return '<div class="scroll">'+d.to_html(index=False,escape=True,border=0,classes='data')+'</div>'


def plots():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':COLORS['ink'],'text.color':COLORS['ink'],'axes.titleweight':'bold','figure.facecolor':'white'})
    primary=pd.read_csv(OUT/'primary_results.csv')
    fig,axes=plt.subplots(1,2,figsize=(11,3.5),gridspec_kw={'width_ratios':[1,1.4]})
    for ax,names,labels in [(axes[0],['direction_employment'],['Employment expectations']),
                            (axes[1],['direction_general_business','market_direction_output'],['Business expectations','Market expectations'])]:
        d=primary.set_index('test').loc[names]
        y=np.arange(len(d));ax.errorbar(d.effect,y,xerr=[d.effect-d.low,d.high-d.effect],fmt='o',color=COLORS['teal'],capsize=4,ms=7)
        ax.set_yticks(y,labels);ax.invert_yaxis();ax.axvline(0,color=COLORS['gray'],lw=1)
        ax.grid(axis='x',alpha=.15)
    axes[0].set_xlabel('Lower unemployment over next 6 months (pp)')
    axes[1].set_xlabel('Next 6-month industrial-production growth (log %)')
    axes[0].set_title('Primary labor association')
    axes[1].set_title('Secondary output associations')
    fig.suptitle('Economic content in prior newspaper expectations',fontsize=14,y=1.08)
    fig.text(.01,-.08,'Effects per full-panel SD of prior net direction. Pointwise 95% five-year-cluster intervals; only labor passes session-wide Holm.',fontsize=9)
    fig.tight_layout();savefig(fig,'economic_associations')

    bins=pd.read_csv(OUT/'economic_signal_quartiles.csv');d=bins[bins.test.eq('employment_to_unemployment')]
    profile=pd.read_csv(OUT/'lead_lag_profiles.csv');p=profile[profile.topic.eq('employment')]
    fig,axes=plt.subplots(1,2,figsize=(11,4))
    axes[0].bar(d.quartile,d.unemployment_rise_gt05_share,color=[COLORS['red'],'#cb8f6c','#6c9da3',COLORS['teal']])
    for _,r in d.iterrows():axes[0].text(r.quartile,r.unemployment_rise_gt05_share+.012,f'{r.unemployment_rise_gt05_share:.1%}',ha='center')
    axes[0].set_xticks([1,2,3,4],['Most\npessimistic','2','3','Most\noptimistic']);axes[0].set_ylim(0,.49)
    axes[0].yaxis.set_major_formatter(PercentFormatter(1));axes[0].set_ylabel('Share with unemployment rise >0.5 pp')
    axes[0].set_title('Descriptive six-month labor risk')
    axes[1].errorbar(p.shift_months,p.effect,yerr=[p.effect-p.simultaneous_low,p.simultaneous_high-p.effect],fmt='o-',color=COLORS['teal'],capsize=4,label='Simultaneous 95% intervals')
    axes[1].axhline(0,color=COLORS['gray'],lw=1);axes[1].axvspan(-2,2,color='#e5f0ef',zorder=-1)
    axes[1].set_xticks([-12,-6,0,6,12],['−12 to −7','−6 to −1','Next 1–6','Next 7–12','Next 13–18'],rotation=25,ha='right')
    axes[1].set_ylabel('Unemployment improvement (pp / SD signal)');axes[1].set_title('Timing on 687 common months')
    fig.text(.01,-.07,'Quartiles are full-sample descriptive bins, not historical trading/model rules. The lead–lag profile uses Bonferroni bands across five windows.',fontsize=9)
    fig.tight_layout();savefig(fig,'employment_risk_and_timing')

    robust=pd.read_csv(OUT/'confidence_robustness.csv').set_index('variant')
    names=['primary_verified','raw_sensitivity','stated','exclude_great_depression','exclude_great_recession','within_same_article']
    d=robust.loc[names]
    fig,axes=plt.subplots(1,2,figsize=(12,4.8),gridspec_kw={'width_ratios':[1,1.3]})
    y=np.arange(len(d));axes[0].errorbar(100*d.effect,y,xerr=[100*(d.effect-d.low),100*(d.high-d.effect)],fmt='o',capsize=4,color=COLORS['teal'])
    axes[0].set_yticks(y,['Verified primary','Raw sensitivity','Stated horizons','Exclude 1929–1939','Exclude 2007–2009','Within same article']);axes[0].invert_yaxis()
    axes[0].set_xlabel('Assertive minus hedged accuracy (pp)');axes[0].axvline(0,color=COLORS['gray']);axes[0].set_title('Machine-label pattern')
    h=pd.read_csv(OUT/'measurement_corrected_confidence.csv')
    y=np.arange(len(h));axes[1].errorbar(100*h.effect,y,xerr=[100*(h.effect-h.low),100*(h.high-h.effect)],fmt='o',capsize=4,color=COLORS['gold'])
    labels=['Reviewer 1: sample only','Reviewer 1: design correction','Reviewer 2: sample only','Reviewer 2: design correction']
    axes[1].set_yticks(y,labels);axes[1].invert_yaxis();axes[1].axvline(0,color=COLORS['gray']);axes[1].set_title('Human correction is inconclusive')
    axes[1].set_xlabel('Corrected gap in fixed original support (pp)')
    fig.text(.01,-.04,'Left: historical five-year-cluster intervals. Right: annotation-sampling intervals; 31–32 human-eligible matched claims. Different uncertainty sources.',fontsize=9)
    fig.tight_layout();savefig(fig,'confidence_and_measurement')

    tests=pd.read_csv(OUT/'backtest_tests_alpha10.csv')
    fig,axes=plt.subplots(1,2,figsize=(11,4))
    for ax,task in zip(axes,['unemployment','production']):
        d=tests[(tests.task==task)&(tests.baseline=='macro')]
        y=np.arange(len(d));ax.errorbar(d.effect,y,xerr=[d.effect-d.low,d.high-d.effect],fmt='o',capsize=4,color=COLORS['teal'])
        ax.set_yticks(y,['Add employment','Add business','Add both']);ax.invert_yaxis();ax.axvline(0,color=COLORS['gray']);ax.set_xlabel('Paired mean squared error reduction');ax.set_title(task.capitalize())
    fig.suptitle('Point improvements are not reliable forecast superiority',y=1.04,fontsize=14)
    fig.text(.01,-.04,'408 monthly origins, 1977–2010. Annual vintage-label refits; fixed ridge α=10. Pointwise 95% five-year-cluster intervals include zero.',fontsize=9)
    fig.tight_layout();savefig(fig,'backtest_improvements')

    decomp=pd.read_csv(OUT/'confidence_decomposition.csv');d=decomp[decomp.grouping.eq('realized')].set_index('group').loc[['improve','flat','worsen']]
    fig,ax=plt.subplots(figsize=(8,3.8));x=np.arange(3);width=.34
    ax.bar(x-width/2,d.assertive_accuracy,width,label='Assertive',color=COLORS['teal']);ax.bar(x+width/2,d.hedged_accuracy,width,label='Hedged',color=COLORS['gold'])
    ax.set_xticks(x,['Output grows >2%','Within ±2%','Output falls >2%']);ax.yaxis.set_major_formatter(PercentFormatter(1));ax.set_ylabel('Matched directional accuracy');ax.legend(frameon=False);ax.set_ylim(0,.78)
    ax.set_title('The confidence advantage depends on the realized state')
    fig.text(.01,-.02,'Retrospective decomposition of the original matched comparison; not independently tested subgroups or a print-time state feature.',fontsize=9)
    fig.tight_layout();savefig(fig,'confidence_state_decomposition')


def main():
    plots()
    results=pd.read_csv(OUT/'session_wide_68_tests.csv').sort_values('p_value')
    primary=pd.read_csv(OUT/'primary_results.csv').set_index('test')
    emp=primary.loc['direction_employment'];conf=primary.loc['confidence_general_business']
    global_p=results.set_index('test').holm_p
    secondary=results[results.test.isin(['direction_general_business','market_direction_output'])]
    confidence=pd.read_csv(OUT/'confidence_robustness.csv')
    labor=pd.read_csv(OUT/'monthly_robustness.csv');labor=labor[(labor.topic=='employment')&(labor.block_years==5)&(labor.outcome=='employment_growth')]
    human=pd.read_csv(OUT/'measurement_corrected_confidence.csv')
    metrics=pd.read_csv(OUT/'backtest_metrics_alpha10.csv');tests=pd.read_csv(OUT/'backtest_tests_alpha10.csv')
    spf=pd.read_csv(OUT/'spf_metrics.csv');spftests=pd.read_csv(OUT/'spf_tests.csv')
    tone=pd.read_csv(OUT/'tone_control_tests.csv')
    classification=pd.read_csv(OUT/'labor_classification_metrics.csv')
    classification_tests=pd.read_csv(OUT/'labor_classification_tests.csv')
    decomposition=pd.read_csv(OUT/'confidence_decomposition.csv')
    fresh=pd.read_csv(OUT/'phase2/fresh_vintage_metrics.csv')
    fresh=fresh[((fresh.task=='unemployment')&(fresh.condition=='fresh_features_fresh_labels'))|((fresh.task=='production')&(fresh.condition=='fresh_features_old_labels'))]
    gdp=pd.read_csv(OUT/'phase2/gdp_metrics.csv')
    wild=pd.read_csv(OUT/'phase2/phase1_wild_inference_audit.csv')
    variance=pd.read_csv(OUT/'phase2/directional_variance_summary.csv')
    variance=variance[(variance.source_set=='verified')&(variance.cohort=='own_support')&(variance.block_years==5)&variance.topic.isin(['general_business','employment'])]
    refs='''<ul>
      <li><a href="https://www.policyuncertainty.com/us_monthly.html">Baker, Bloom and Davis: US Economic Policy Uncertainty data and definitions</a>. Historical reconstruction and partly overlapping newspapers; association covariate only.</li>
      <li><a href="https://www.frbsf.org/research-and-insights/data-and-indicators/daily-news-sentiment-index/">San Francisco Fed Daily News Sentiment Index</a>. Broad economic-news tone, composition-adjusted, from 1980. Retrospective control only.</li>
      <li><a href="https://www.philadelphiafed.org/surveys-and-data/unemp">Philadelphia Fed SPF unemployment forecasts</a> and <a href="https://www.philadelphiafed.org/-/media/frbp/assets/surveys-and-data/survey-of-professional-forecasters/spf-documentation.pdf">survey documentation</a>. UNEMP4 forecasts the quarterly unemployment average two quarters after the survey quarter. Historical release dates were checked individually.</li>
      <li><a href="https://www.philadelphiafed.org/surveys-and-data/real-time-data-research/ruc">Philadelphia Fed real-time unemployment data</a>. Quarterly vintage snapshots provide historical information, with observation ages retained.</li>
      <li><a href="https://www.nber.org/papers/w32026">van Binsbergen, Bryzgalova, Mukhopadhyay and Sharma, (Almost) 200 Years of News-Based Economic Sentiment</a>. Long historical newspaper tone predicting activity already has a substantial precedent. The candidate contribution here is source-forecast structure, topic and confidence, with an explicit measurement audit—not the generic claim that newspapers contain macroeconomic information.</li>
      <li><a href="https://doi.org/10.1111/j.1540-6261.2007.01232.x">Tetlock (2007), Giving Content to Investor Sentiment</a>. Daily market-news sentiment is a distinct task from these six-month directional claims and monthly-average-price outcomes.</li>
      <li><a href="https://pubs.aeaweb.org/doi/10.1257/mac.5.2.217">Bachmann, Elstner and Sims (2013), Uncertainty and Economic Activity</a>. Survey disagreement can contain uncertainty information; heterogeneous newspaper claims need their own construct validation.</li>
    </ul>'''
    parts=[f'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>ProQuest economic discovery session — October 22, 2026</title>
    <style>body{{font:16px/1.58 system-ui,-apple-system,sans-serif;color:#182d44;background:#f5f7fa;margin:0}}main{{max-width:1120px;margin:auto;background:white;padding:44px 52px}}h1{{font-size:34px;line-height:1.2}}h2{{margin-top:46px;border-top:1px solid #d8e0e7;padding-top:26px}}h3{{margin-top:28px}}a{{color:#087a83}}.lede{{font-size:20px}}.note{{padding:16px 20px;background:#eef4f7;border-left:4px solid #147d83}}.warning{{background:#fff5e9;border-left-color:#b87a22}}.small,figcaption{{font-size:13px;color:#526475}}figure{{margin:30px 0}}figure img{{width:100%;height:auto}}.scroll{{overflow:auto;margin:20px 0}}table{{border-collapse:collapse;min-width:700px;width:100%;font-size:13px}}th,td{{padding:8px 10px;text-align:left;border-bottom:1px solid #e0e5ea;white-space:nowrap}}th{{background:#edf3f7;position:sticky;top:0}}tr:nth-child(even){{background:#f8fafb}}code{{background:#eef2f5;padding:2px 5px}}pre{{overflow:auto;background:#eef2f5;padding:20px}}details{{margin:18px 0}}.cards{{display:grid;grid-template-columns:1fr 1fr;gap:18px}}.card{{border:1px solid #dce5ec;border-radius:8px;padding:18px}}@media(max-width:700px){{main{{padding:22px}}.cards{{grid-template-columns:1fr}}h1{{font-size:27px}}}}</style><main>
    <p class="small">RESEARCH SESSION · OCTOBER 22–23, 2026 · ANNUAL PROQUEST 1900–2010</p>
    <h1>Economic information, forecast confidence, and the limits of the labels</h1>
    <p class="lede">Employment expectations are the strongest economic lead. A business-confidence accuracy gap is stable in machine labels, but the available human review cannot establish that it survives measurement correction. New predictive-superiority claims are not supported.</p>
    <p class="note warning">This is exploratory historical analysis. Earlier project results were already inspected. The 68-test session correction does not erase that history or incorporate extraction error. No causal effect, new untouched holdout, or externally validated forecast skill is claimed.</p>
    <p class="note warning"><strong>Time-window disclosure:</strong> The user extended the requested window to ten hours, ending about 7:33 a.m. Central on October 23. One browser download call stalled for about 7 hours 56 minutes despite a short requested timeout. That stalled interval is not represented as productive analysis. The completed work, data and validation are reported below; unfinished prospective model-selection ideas were not run.</p>
    <p><a href="#findings">Findings</a> · <a href="#measurement">Measurement</a> · <a href="#models">Forecast tests</a> · <a href="#nulls">Nulls</a> · <a href="#all">All 68 tests</a> · <a href="#reproduce">Reproduce</a></p>
    <h2 id="findings">What the experiments found</h2>
    <div class="cards"><div class="card"><h3>1. Labor expectations carry a strong historical signal</h3>
    <p>A one-standard-deviation increase in prior employment net optimism is associated with <strong>{emp.effect:.2f} percentage points lower unemployment over the next six months</strong> (95% interval {emp.low:.2f}–{emp.high:.2f}; session-wide Holm p={global_p['direction_employment']:.4f}).</p>
    <p>There are 699 qualifying monthly origins in 1948–2010 and 14 occupied five-year blocks. This is an aggregate signal from the selected archive, conditional on machine source interpretation.</p></div>
    <div class="card"><h3>2. Assertive business claims score better in machine labels</h3>
    <p>Matched accuracy is <strong>{conf.left_rate:.1%} for assertive and {conf.right_rate:.1%} for hedged claims</strong>: {100*conf.effect:.2f} percentage points (95% interval {100*conf.low:.2f}–{100*conf.high:.2f}; session-wide Holm p={global_p['confidence_general_business']:.4f}).</p>
    <p>The comparison contains 4,690 exact paper/month/topic/horizon/voice cells and 19 occupied five-year blocks. Human correction is too imprecise to validate this as an economic skill result.</p></div></div>
    <p>Two output relationships were promising in the earlier screen, but no longer pass either adjustment after expanding to all 68 session hypotheses: prior business optimism relates to +2.24 log percentage points of subsequent six-month industrial-production growth, and market optimism to +1.48. They remain secondary leads. GDP and quarterly-average outcome checks retain positive associations, but do not replace the primary targets.</p>''']
    parts.append(figure('economic_associations','The labor association passes the conservative 68-test Holm screen under the five-year design. The output relationships are secondary; neither passes the expanded family adjustment. Intervals condition on machine labels.'))
    parts.append('''<h3>Economic size and timing</h3><p>In the most pessimistic full-sample quarter of employment-signal months, unemployment subsequently rises more than 0.5 percentage points in 40.6% of cases, versus 4.6% in the most optimistic quarter. Mean six-month unemployment changes are +0.56 pp and −0.27 pp respectively. These bins are descriptive; thresholds were not learned and evaluated as historical forecasting rules.</p>
    <p>On 687 common months, the employment relationship peaks at the following six-month window rather than the preceding window. The future-minus-recent slope difference is nominally positive (p=0.019), but fails the session-wide correction. Thus the timing is encouraging without independently establishing foresight or ruling out persistent conditions and extraction contamination.</p>''')
    parts.append(figure('employment_risk_and_timing','The raw labor-risk gradient is large. The five-window timing bands control simultaneous coverage within that profile; they do not validate the machine labels or establish a causal mechanism.'))
    parts.append('''<h3>Employment robustness</h3><p>The direction and size persist in raw exports, machine-stated horizons, 4–8 month stated horizons, fixed newspaper coverage, publisher leave-outs, crisis exclusions and all six nonoverlapping six-month calendar offsets. Every five-year-block leave-out retains a positive coefficient, ranging from 0.27 to 0.35 pp. Separate era estimates have wider intervals. These are robustness diagnostics of the same inspected finding, not additional discoveries.</p>''')
    parts.append(table(labor,['variant','effect','low','high','p_value','n'],{'effect':'{:.3f}','low':'{:.3f}','high':'{:.3f}','p_value':'{:.4f}'}))
    parts.append('''<p>With eight historical-vintage macro controls, the employment coefficient falls to about 0.16 pp but remains nominally positive. Restricting to March/June/September/December, when the quarterly unemployment snapshot is freshest, gives about 0.15 pp with a wider interval. The claim-specific novelty is less clear after controlling broad newspaper tone:</p>''')
    parts.append(table(tone,['test','effect','low','high','p_value','n','n_blocks'],{'effect':'{:.3f}','low':'{:.3f}','high':'{:.3f}','p_value':'{:.4f}'}))
    parts.append('''<p>The SF Fed tone control begins in 1980. Neither claim coefficient is significant in that shorter, macro-controlled comparison. This does not prove the signals are identical; it means the present evidence does not establish incremental information beyond general news tone.</p>
    <h2 id="measurement">The confidence result needs a measurement qualification</h2>
    <p>Exact-month matching holds the deterministic outcome and fixed growth comparator constant, while matching paper, topic, benchmark, exact horizon, horizon basis and voice. Claims are averaged within article and arm, then both arms receive the same harmonic article-overlap cell weights. Matching does not hold forecast direction constant, because that would make correctness identical within the cell. Thus the contrast can reflect different directional choices as well as useful confidence.</p>
    <p>The gap survives raw exports (+7.66 pp), stated horizons (+5.17 pp), and within-article comparisons (+5.29 pp). It is not present equally across realized states: assertive calls do better before growth; hedged calls do better before output declines. Both groups lose to the fixed growth rule on the primary matched mix. An assertive language label is not a numerical probability and cannot establish calibrated confidence or overconfidence.</p>''')
    parts.append(figure('confidence_state_decomposition','This retrospective state decomposition explains the pooled confidence contrast. It is not an implementable rule using knowledge of the future state.'))
    parts.append(table(confidence,['variant','effect','low','high','p_value','n','n_blocks'],{'effect':'{:.4f}','low':'{:.4f}','high':'{:.4f}','p_value':'{:.5f}'}))
    parts.append('''<p>The earlier historical review contains 250 probability-sampled claims and two distinct reviewers. For the fixed matched business support, only 79 reviewed candidates occur, with 32 scorable national business forecasts under Reviewer 1 and 31 under Reviewer 2. That is too little information to tightly correct eligibility, direction, topic and horizon.</p>
    <p>The table below keeps the originally machine-defined confidence arms and matched support fixed, excluding the 12 pilot claims from the frame. It estimates human-corrected accuracy in those original groups. It does not estimate a wholly human-defined assertive-versus-hedged matched contrast. Full design-based correction adds the inverse-probability human-minus-machine discrepancy to each census numerator and denominator. The resulting intervals include zero for both reviewers and both estimators.</p>''')
    parts.append(table(human,['reviewer','estimator','effect','low','high','sampled_human_eligible_assertive','sampled_human_eligible_hedged'],{'effect':'{:.3f}','low':'{:.3f}','high':'{:.3f}'}))
    parts.append(figure('confidence_and_measurement','Strong conditional machine-label evidence coexists with weak human-corrected evidence. Temporal and annotation-sampling uncertainty are different; neither interval incorporates all uncertainty.'))
    parts.append('''<p class="note warning">The corrected point estimates are unstable and should not replace the machine estimate with a confident opposite conclusion. The appropriate conclusion is that the current human audit cannot establish the confidence advantage. Employment aggregate signals also remain conditional on machine interpretation; the sparse review cannot reconstruct a human-labeled monthly panel.</p>
    <h2 id="models">Association did not become established forecasting superiority</h2>
    <p>The continuous-outcome experiment uses 408 common monthly origins, January 1977–December 2010. Every January, fixed ridge models with α=10 fit only mature labels from the production or unemployment vintage available before that refit. Predictors are the eight audited vintage macro features and prior completed-month press signals. Scaling and imputation use training data only. Final frozen economic outcomes are attached after fitting.</p>
    <p>Adding employment to the unemployment macro model reduces MSE from 0.3012 to 0.2747 (8.8%); RMSE changes from 0.549 to 0.524 pp. Its paired five-year-cluster MSE improvement is 0.0265, with interval [−0.0162, +0.0692]. This is a useful point estimate, not a reliable forecasting-superiority result. Adding business or both signals also helps some point estimates but remains uncertain.</p>''')
    parts.append(figure('backtest_improvements','All six displayed macro-addition contrasts have pointwise intervals crossing zero. Every specified arm is retained; no evaluation-selected winner is promoted.'))
    parts.append(table(metrics,['task','model','n','mse','rmse','mae','sign_accuracy'],{'mse':'{:.4f}','rmse':'{:.4f}','mae':'{:.4f}','sign_accuracy':'{:.1%}'}))
    parts.append('''<p>Fixed α=1 and α=100 sensitivities retain broadly similar directions. Re-estimating all annual models under 3,000 joint calendar-block weight draws, while preserving chronology and vintage labels, also leaves every primary 95% MSE-gain interval spanning zero. Those are weighted resampling diagnostics, not extra discovery tests.</p>
    <h3>A different labor target did not rescue the claim</h3><p>The three-class labor task predicts a six-month unemployment change beyond ±0.5 pp, with a flat class inside the existing band. Press-only annual vintage-label fits evaluate 540 origins in 1966–2010. A separate macro comparison uses 408 origins. Employment helps the macro model's Brier score by 0.0209 with nominal p=0.047, but this fails both the four-test task adjustment and the session correction. The large flat-class share also makes accuracy alone a poor summary.</p>''')
    parts.append(table(classification,['study','model','n','brier','log_loss','accuracy'],{'brier':'{:.4f}','log_loss':'{:.4f}','accuracy':'{:.1%}'}))
    parts.append('''<h3>Professional forecasts are a demanding external comparator</h3><p>The SPF comparison evaluates the same future quarterly-average unemployment level as UNEMP4. The newspaper model uses vintage macro inputs and prior employment expectations, with fixed α=10; a 50/50 SPF/model average is specified without choosing its weight from outcomes. The evaluation uses 77 available quarterly origins in 1991–2010. Three origins were excluded because the public ledger shows the survey was released on or after the intended first-day origin: 1993Q1, 1993Q2 and 1996Q1.</p>
    <p>The SPF RMSE is 0.510 pp, versus 0.526 for the newspaper-plus-macro model and 0.508 for the fixed average. Neither comparison establishes improvement. There are only four five-year blocks. Newspapers may include several weeks more information than the SPF response deadline, so the information sets are not identical even after checking release availability.</p>''')
    parts.append(table(spf,['model','n','mse','rmse','mae','bias'],{'mse':'{:.4f}','rmse':'{:.4f}','mae':'{:.4f}','bias':'{:.4f}'}))
    parts.append('''<h2>Stronger benchmark and inference checks</h2><p>The full public ALFRED archive supplies 609 month-end unemployment snapshots, 1960–2010. Every requested vintage and observation date validates; 225 separately cached graph snapshots match exactly. In 1977–2010, replacing quarter-stale unemployment inputs reduces average observation age from three to two months. The old-input arm reproduces the original predictions before replacement.</p>
    <p>Under fresh input and label snapshots, adding employment expectations reduces unemployment MSE from 0.2958 to 0.2704 (8.6%), but the paired interval still includes zero: [−0.0154, +0.0661]. This benchmark improvement does not turn the newspaper addition into statistically established forecasting superiority. Feature-only and label-only changes are reported separately.</p>''')
    parts.append(table(fresh,['task','model','n','mse','rmse','mae'],{'mse':'{:.4f}','rmse':'{:.4f}','mae':'{:.4f}'}))
    parts.append('''<h3>Real GDP as a forecasting target</h3><p>A separate fixed-ridge experiment evaluates 143 quarter-start origins, 1975–2010, using two-quarter GDP growth. The models use native real-time GNP/GDP history, the fresher unemployment inputs, and the same earlier press signals. The known December-2003 archive hole excludes January 2004 for every arm based solely on input availability. Older training labels are GNP rather than GDP, a historical concept mismatch retained as a limitation.</p>
    <p>Adding employment, or all three press topic signals, improves point MSE by roughly 10% relative to macro-only. The employment addition has an exact block-studentized p=0.0234, which fails both its six-comparison adjustment and the cumulative session test. No GDP forecasting winner is promoted.</p>''')
    parts.append(table(gdp,['model','n','mse','rmse','mae'],{'mse':'{:.4f}','rmse':'{:.4f}','mae':'{:.4f}'}))
    parts.append('''<h3>Exact small-cluster audit</h3><p>The main association and confidence tests were checked by enumerating every cluster sign assignment and recomputing the studentized statistic. For four existing hypotheses, the final table uses the larger of the original cluster-t p and the five-year restricted-wild p; this rule can only weaken significance. The labor and confidence tests remain significant under that stated design.</p>
    <p>With ten-year blocks there are only eight occupied labor clusters: its exact p is 0.015625 and fails the 68-test adjustment. The relationship remains positive, but robust family-wide significance under this more conservative dependence assumption is not established. Exact enumeration removes Monte Carlo noise, not the assumptions of approximately independent, sign-symmetric cluster errors or correct source interpretation.</p>''')
    parts.append(table(wild,['test','block_years','wild_p','enumerated_assignments','n_blocks'],{'wild_p':'{:.6f}','enumerated_assignments':'{:.0f}','n_blocks':'{:.0f}'}))
    parts.append('''<h3>Disagreement is not solely between newspapers</h3><p>Exact variance accounting puts 26.6% of general-business directional variance between newspapers and 73.4% within them. Employment's between-paper share is 45.1%. About 17.9% of business variation is within articles. These are descriptive properties of the labels, not causal effects or proof of political polarization. Horizon, voice and confidence decompositions overlap and must not be added together.</p>''')
    parts.append(table(variance,['topic','attribute','between_fraction','low','high','n_months'],{'between_fraction':'{:.1%}','low':'{:.1%}','high':'{:.1%}','n_months':'{:.0f}'}))
    parts.append('''<h2 id="nulls">Leads that did not survive</h2><ul>
    <li>Prior political polarization did not show a robust association with business pessimism or cross-paper dispersion. The proxy measures earlier partisan voting separation, not public affective polarization.</li>
    <li>Historical EPU did not establish a reliable relationship with claim accuracy, hedging, pessimism or dispersion after correction. Its baseline-gap association is nominally negative but fails the adjusted screen.</li>
    <li>Market or business disagreement did not reliably predict future market volatility or the magnitude of output changes. Direction shares mechanically constrain several disagreement measures, and mixed horizons are not disagreement about one identical proposition.</li>
    <li>Numerical content and direct quotation did not establish a corrected accuracy premium. A number in a quotation need not be a quantitative forecast.</li>
    <li>The bad-state recovery-versus-continuation contrast is large but fails the session-wide screen. It is not promoted by changing the test family after inspection.</li>
    <li>Recovery-phase pessimism, expert-versus-journalist accuracy and the market-return relationships are inconclusive under the specified uncertainty and correction.</li>
    </ul><p>A null here means insufficient evidence in this selected corpus and design, not evidence of no economic relationship.</p>
    <h2>Design, scope and uncertainty</h2>
    <p>Only the 111 annual verified ProQuest shards, 1900–2010, supply primary claims; annual raw exports supply sensitivity data. The primary saved scorer contains 175,855 scorable claims, while the readable national direction panel includes 182,817 claims regardless of outcome/horizon eligibility. There are no LOC claims, abandoned crisis-window exports or modern claims in the analysis. All 222 raw/verified source hashes match the previously frozen manifest. Identical stripped labels are retained; article averaging is weighting, not deduplication.</p>
    <p>Monthly signals average claims within article, articles within newspaper/topic/month, then observed newspapers within month. A three-month signal requires adequate observed-month, newspaper and article support. Origins use only earlier complete print months. Missing coverage stays missing; it is not neutral sentiment. Counts describe this export, not newspapers' population attention, because full retrieval/article denominators are unavailable.</p>
    <p>The continuous target compares t−1 with t+5. Production and prices use log percentage change; employment improvement is minus the unemployment-rate change. The market proxy is the Shiller nominal monthly-average S&amp;P Composite price, excluding dividends. Its six monthly-return volatility is not daily realized volatility or an executable close-to-close strategy. Claim scoring retains the existing deterministic bands and reports stated horizons separately. No retrospective window/cycle labels or verifier prose enter any feature.</p>
    <p>The primary direct family contained 24 questions, recorded before those fits. Subsequent fixed batches added ten vintage MSE tests, ten narrative tests, two external SPF comparisons, two timing contrasts, four labor-probability tests, two broad-tone controls, eight fresh-vintage comparisons and six GDP comparisons: 68 total. Holm and BH adjustments cover all 68. For four audited phase-one effects and the GDP tests, p-values use the conservative maximum of cluster-t and exact studentized block inference; other families retain their recorded cluster-t method. Earlier repository experimentation, adaptive question choice, robustness variants and semantic uncertainty are not erased by this correction. All final p-values are two-sided and cluster based.</p>
    <p>Five-year calendar blocks are primary; two- and ten-year variants are retained. The confidence contrast's ten-year nominal p≈0.004 would fail a fresh session-wide Holm adjustment at that block length, while the labor association remains stronger. Some older cells have little mass; occupied-block counts are not equal effective information. All model comparisons preserve exact shared dates. Short evaluation histories, overlapping outcomes, revised evaluation references, quarter-stale unemployment snapshots, selected newspaper/query coverage and changing language limit external validity.</p>
    <h2 id="all">Every session hypothesis: 68 retained tests</h2><p>Effect units depend on the test: matched accuracy and probabilities are proportions; unemployment is percentage points; production/market changes are log percent; squared-error gains retain squared outcome units. Positive paired loss gain favors the added model. Intervals are pointwise and unadjusted, so they can exclude zero even when the adjusted test does not reject. Use each batch's specification for the precise population and estimand.</p>''')
    cols=['test','batch','effect','low','high','p_value','holm_p','bh_q','n','n_blocks']
    parts.append(table(results,cols,{'effect':'{:.5f}','low':'{:.5f}','high':'{:.5f}','p_value':'{:.5f}','holm_p':'{:.5f}','bh_q':'{:.5f}','n':'{:.0f}','n_blocks':'{:.0f}'}))
    parts.append('''<h2>Where the economic contribution could be</h2><p>The most defensible next paper direction is <strong>what explicit employment expectations add to broad economic language, and when</strong>. The measured labor signal is economically large, stable to several coverage and timing challenges, and stronger than most other screened relationships. However, current evidence does not establish improvement beyond professional forecasts or broad newspaper tone. The business-confidence contrast is a second candidate whose main obstacle is source measurement.</p>
    <p>It would be premature to claim the first discovery that historical newspapers predict the economy. The distinctive contribution would require validated forecast identity, topic, direction and horizon; confidence or source structure that adds information beyond existing tone indexes; and a genuinely untouched later evaluation activated under the repository's separate-scope rules. This session does not pool or analyze modern claims to obtain that result.</p>
    <h2>External sources and related work</h2>'''+refs)
    parts.append('''<h2 id="reproduce">Reproduction and artifacts</h2><p>All new scripts and outputs are in this directory. The source exports and existing fitted artifacts remain unchanged. Run from the repository root in a working environment with NumPy, pandas, SciPy, statsmodels, scikit-learn, matplotlib, xlrd and openpyxl. The run used <code>/opt/anaconda3/bin/python3</code>; the broken repository-root environment was not used.</p>
    <pre>python data/scored/proquest/discovery_session_20261022/run_primary.py
python data/scored/proquest/discovery_session_20261022/robust_claims.py
python data/scored/proquest/discovery_session_20261022/robust_monthly.py
python data/scored/proquest/discovery_session_20261022/backtest.py
python data/scored/proquest/discovery_session_20261022/backtest.py --alpha 1
python data/scored/proquest/discovery_session_20261022/backtest.py --alpha 100
python data/scored/proquest/discovery_session_20261022/narrative.py
python data/scored/proquest/discovery_session_20261022/spf_comparison.py
python data/scored/proquest/discovery_session_20261022/measurement.py
python data/scored/proquest/discovery_session_20261022/refit_uncertainty.py
python data/scored/proquest/discovery_session_20261022/timing.py
python data/scored/proquest/discovery_session_20261022/labor_classification.py
python data/scored/proquest/discovery_session_20261022/economic_signal_audit.py
python data/scored/proquest/discovery_session_20261022/tone_control.py
python data/scored/proquest/discovery_session_20261022/benchmark_sensitivity.py
python data/scored/proquest/discovery_session_20261022/phase2/disagreement_decomposition.py
python data/scored/proquest/discovery_session_20261022/phase2/inference_audit.py
python data/scored/proquest/discovery_session_20261022/phase2/vintage_data.py
python data/scored/proquest/discovery_session_20261022/phase2/fresh_vintage.py
python data/scored/proquest/discovery_session_20261022/phase2/gdp_forecast.py
python data/scored/proquest/discovery_session_20261022/validate_session.py
python data/scored/proquest/discovery_session_20261022/make_report.py</pre>
    <p><a href="session_wide_68_tests.csv">All tests CSV</a> · <a href="primary_results.csv">Primary estimates</a> · <a href="economic_signal_robustness.csv">Economic robustness</a> · <a href="measurement_corrected_confidence.csv">Human correction</a> · <a href="backtest_predictions_alpha10.csv">Monthly model predictions</a> · <a href="spf_availability_audit.csv">SPF release audit</a> · <a href="validation.json">Validation checks</a> · <a href="specification.json">Initial specification</a></p>
    <p class="small">Figures are also saved as standalone PNG and SVG files. Per-batch manifests retain input/source hashes. The final session manifest records code versions, checks and run timing.</p></main></html>''')
    (OUT/'report.html').write_text('\n'.join(parts))
    print('Report:',OUT/'report.html')


if __name__=='__main__':main()
