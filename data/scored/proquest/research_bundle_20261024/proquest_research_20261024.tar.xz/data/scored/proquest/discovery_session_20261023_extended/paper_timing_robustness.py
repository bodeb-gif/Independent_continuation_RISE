"""Publisher, exact coverage, annual effects and timing challenges to one lead."""
from associations import *
from proquest_panel import build_panels

def basic_features(claims,require_both=False):
    _,_,monthly=build_panels(claims)
    if require_both:
        bad=monthly.n_papers.ne(2)
        monthly.loc[bad,['net_direction','flat_share']]=np.nan
        monthly.loc[bad,['n_articles','n_papers']]=0
    rows=[]
    for topic in TOPICS:
        m=monthly[monthly.topic.eq(topic)].set_index('month').sort_index()
        adequate=(m.n_articles.gt(0).rolling(3,min_periods=1).sum().shift(1)>=2)&(
            m.n_papers.rolling(3,min_periods=1).max().shift(1)>=2)&(
            m.n_articles.rolling(3,min_periods=1).sum().shift(1)>=5)
        d=pd.DataFrame(index=m.index)
        d['net_direction']=m.net_direction.rolling(3,min_periods=2).mean().shift(1).where(adequate)
        d['flat_share']=m.flat_share.rolling(3,min_periods=2).mean().shift(1).where(adequate)
        d['n_articles']=m.n_articles.rolling(3,min_periods=1).sum().shift(1).fillna(0)
        d['n_papers']=m.n_papers.rolling(3,min_periods=1).mean().shift(1)
        d['log_articles']=np.log1p(d.n_articles)
        d['net_squared']=d.net_direction**2
        d.index.name='origin';d=d.reset_index();d['topic']=topic;d['year']=d.origin.dt.year
        rows.append(d)
    f=pd.concat(rows,ignore_index=True)
    wide=f.pivot(index='origin',columns='topic',values='net_direction')
    for topic in TOPICS:
        other=wide.drop(columns=topic)
        mean=other.mean(axis=1).where(other.notna().sum(axis=1)>=2)
        mask=f.topic.eq(topic)
        f.loc[mask,'cross_topic_gap']=f.loc[mask,'origin'].map(wide[topic]-mean)
    return f

def analysis_frame(features):
    d=features[features.topic.eq('employment')].copy()
    truth=pd.read_csv(PRIOR/'continuous_targets.csv');truth['origin']=pd.PeriodIndex(truth.origin,freq='M')
    return d.merge(truth.drop(columns='year'),on='origin',validate='one_to_one')

def run():
    claims=pd.read_csv(OUT/'cache/print_claims_verified.csv.gz',dtype={'page_id':str})
    claims['month']=pd.PeriodIndex(claims.month,freq='M')
    rebuilt=basic_features(claims)
    saved=pd.read_csv(OUT/'cache/features_verified.csv.gz');saved['origin']=pd.PeriodIndex(saved.origin,freq='M')
    joined=rebuilt.merge(saved,on=['origin','topic'],suffixes=('_new','_saved'),validate='one_to_one')
    for col in ['net_direction','flat_share','n_articles','n_papers','log_articles','cross_topic_gap']:
        np.testing.assert_allclose(joined[col+'_new'],joined[col+'_saved'],rtol=1e-12,atol=1e-12,equal_nan=True)
    base=analysis_frame(rebuilt);controls=['net_direction','net_squared','flat_share','log_articles','n_papers']
    primary,_,_=estimate(base,'cross_topic_gap','employment_growth',controls,wild=True)
    sigma=primary['feature_sd'];rows=[];samples=[]
    def retain(label,d,columns):
        r,_,used=estimate(d,'cross_topic_gap','employment_growth',columns,wild=True)
        if r.get('status')=='estimated':
            for key in ['effect','low','high']:r[key+'_per_primary_sd']=r[key]/r['feature_sd']*sigma
        rows.append(dict(variant=label,**r));samples.append(used.assign(variant=label))
        print(label,r['effect'],r['p_value'],r['n'],flush=True)
    retain('primary_reproduced',base,controls)
    for paper in sorted(claims.paper.unique()):
        f=basic_features(claims[claims.paper.ne(paper)])
        retain('omit_'+paper,analysis_frame(f),controls)
    fixed=['New York Times','Los Angeles Times','Washington Post','Boston Globe','Chicago Tribune']
    f=basic_features(claims[claims.paper.isin(fixed)])
    d=analysis_frame(f);retain('fixed_five_through_2001',d[d.year<=2001],controls)
    pair=claims[claims.paper.isin(['New York Times','Los Angeles Times'])]
    f=basic_features(pair,require_both=True)
    retain('both_NYT_and_LAT_in_every_used_month',analysis_frame(f),controls)
    # Year effects absorb broad annual cycle movements retrospectively. These
    # are association diagnostics, not historical model predictors or refits.
    d=base.copy();year_dummies=pd.get_dummies(d.year,prefix='year_FE',drop_first=True,dtype=float)
    months=pd.get_dummies(d.origin.dt.month,prefix='month_FE',drop_first=True,dtype=float)
    for col in year_dummies:d[col]=year_dummies[col]
    for col in months:d[col]=months[col]
    retain('month_of_year_effects',d,controls+list(months))
    retain('year_effects',d,controls+list(year_dummies))
    retain('year_and_month_effects',d,controls+list(year_dummies)+list(months))
    # Align latest print information with the conservative survey observation
    # cutoff: move the full previous-origin feature vector to the next origin.
    shifted=rebuilt.copy();shifted['origin']=shifted.origin+1;shifted['year']=shifted.origin.dt.year
    d=analysis_frame(shifted)
    from survey_controls import survey_panel
    survey=survey_panel();d=d.merge(survey,on='origin',validate='one_to_one')
    survey_cols=['ICC','ICE','ICC_change_6m','ICE_change_6m','ICC_age','ICE_age']
    retain('latest_print_t_minus_2_no_survey',d,controls)
    retain('latest_print_t_minus_2_survey_aligned',d,controls+survey_cols)
    result=pd.DataFrame(rows);result.to_csv(OUT/'paper_timing_robustness.csv',index=False)
    pd.concat(samples,ignore_index=True).to_csv(OUT/'audits/paper_timing_analysis_rows.csv.gz',index=False,
        compression={'method':'gzip','mtime':0})
    save_json(OUT/'audits/paper_timing_manifest.json',dict(status='complete',primary_feature_sd=sigma,
        code_sha256=digest(__file__),source_count=check_sources(),
        role='All listed robustness variants of the same inspected cross-topic lead; none replaces its primary test or becomes a selected new target.'))
    journal('paper_timing_robustness','Completed all publisher, balanced coverage, annual and survey-aligned timing challenges')

if __name__=='__main__':run()
