"""All 32 fixed structure tests, including unsupported and null questions."""
import argparse
import time
import statsmodels.api as sm
from session_utils import *
from design import STRUCTURES

OUTCOMES={'general_business':'general_business_growth','employment':'employment_growth',
          'markets':'markets_growth','prices':'prices_growth'}

def select_design(d,controls):
    x=pd.concat([d[['tested_predictor']+controls].astype(float),
        pd.get_dummies(d.year//10*10,prefix='decade',drop_first=True,dtype=float)],axis=1)
    x=sm.add_constant(x,has_constant='add')
    kept=[];rank=0
    for col in x:
        a=x[kept+[col]].to_numpy();new=np.linalg.matrix_rank(a)
        if new>rank: kept.append(col);rank=new
    return x[kept]

def restricted_wild(X,y,groups,j,draws=99999):
    """Restricted cluster wild bootstrap with refitted cluster sandwich.

    Batch algebra is independently checked against explicit statsmodels refits
    by validate_extension.py. Exact sign enumeration is used up to 20 blocks;
    otherwise a conservative 99% binomial upper bound is used for MC p.
    """
    groups=np.asarray(groups);unique=np.unique(groups);g=len(unique)
    n,k=X.shape
    bread=np.linalg.inv(X.T@X);beta=bread@X.T@y
    keep=[i for i in range(k) if i!=j]
    beta0=np.zeros(k);beta0[keep]=np.linalg.lstsq(X[:,keep],y,rcond=None)[0]
    u0=y-X@beta0;u=y-X@beta
    S0=[];S=[];C=[]
    for code in unique:
        z=X[groups==code]
        S0.append(z.T@u0[groups==code]);S.append(z.T@u[groups==code])
        C.append(bread[j]@(z.T@z))
    S0=np.array(S0);S=np.array(S);C=np.array(C)
    factor=g/(g-1)*(n-1)/(n-k)
    se=np.sqrt(factor*np.square(S@bread[j]).sum());t=beta[j]/se
    contributions=S0@bread.T;q=S0@bread[j]
    exact=g<=20;total=1<<g if exact else draws
    rng=np.random.default_rng(SEED+g+n);extreme=0
    for start in range(0,total,5000):
        size=min(5000,total-start)
        if exact:
            ids=np.arange(start,start+size,dtype=np.uint64)
            signs=2*((ids[:,None]>>np.arange(g,dtype=np.uint64))&1).astype(float)-1
        else: signs=rng.choice([-1.,1.],(size,g))
        delta=signs@contributions
        score=signs*q-delta@C.T
        ses=np.sqrt(factor*np.square(score).sum(1))
        ts=np.divide(delta[:,j],ses,out=np.zeros(size),where=ses>0)
        extreme+=int((abs(ts)>=abs(t)-1e-10).sum())
    p=extreme/total if exact else (extreme+1)/(total+1)
    upper=p if exact else float(st.beta.ppf(.99,extreme+1,total-extreme)) if extreme<total else 1.
    return dict(p_wild=p,p_wild_conservative=upper,wild_exact=exact,
                wild_draws=total,wild_extreme=extreme,wild_se=se)

def estimate(frame,feature,outcome,controls,span=5,anchor=1900,wild=False):
    cols=list(dict.fromkeys(['origin','year',feature,outcome]+controls))
    d=frame[cols].replace([np.inf,-np.inf],np.nan).dropna().copy()
    groups=(d.year.to_numpy()-anchor)//span;g=len(np.unique(groups))
    if len(d)<60 or g<6 or d[feature].std()<=1e-10:
        return dict(effect=np.nan,p_value=1.,n=len(d),n_blocks=g,status='insufficient_support'),None,d
    center=d[feature].mean();scale=d[feature].std()
    d['tested_predictor']=(d[feature]-center)/scale
    x=select_design(d,controls)
    if len(d)<2*x.shape[1] or 'tested_predictor' not in x:
        return dict(effect=np.nan,p_value=1.,n=len(d),n_blocks=g,status='insufficient_rank'),None,d
    fit=sm.OLS(d[outcome],x).fit(cov_type='cluster',
        cov_kwds={'groups':groups,'use_correction':True,'df_correction':True},use_t=True)
    lo,hi=fit.conf_int().loc['tested_predictor']
    row=dict(effect=fit.params['tested_predictor'],se=fit.bse['tested_predictor'],
        low=lo,high=hi,p_value=fit.pvalues['tested_predictor'],p_cluster_t=fit.pvalues['tested_predictor'],
        n=len(d),n_blocks=g,status='estimated',feature_mean=center,feature_sd=scale,
        controls=';'.join(x.columns),r_squared=fit.rsquared,
        first_origin=d.origin.min(),last_origin=d.origin.max())
    if wild:
        info=restricted_wild(x.to_numpy(float),d[outcome].to_numpy(float),groups,list(x).index('tested_predictor'))
        np.testing.assert_allclose(info['wild_se'],row['se'],rtol=1e-7,atol=1e-9)
        row.update(info);row['p_value']=max(row['p_cluster_t'],row['p_wild_conservative'])
    return row,fit,d

def inputs(variant='verified'):
    f=pd.read_csv(OUT/'cache'/f'features_{variant}.csv.gz')
    f['origin']=pd.PeriodIndex(f.origin,freq='M')
    truth=pd.read_csv(PRIOR/'continuous_targets.csv')
    truth['origin']=pd.PeriodIndex(truth.origin,freq='M')
    f=f.merge(truth.drop(columns='year'),on='origin',validate='many_to_one')
    macro=pd.read_csv(PRIOR/'phase2/fresh_core_forecast_features.csv')
    macro['origin']=pd.PeriodIndex(macro.origin,freq='M')
    from proquest_vintages import CORE_FEATURES
    f=f.merge(macro[['origin']+list(CORE_FEATURES)],on='origin',how='left',validate='many_to_one')
    return f

def main():
    check_sources();start=time.monotonic();data=inputs()
    rows=[];sensitivities=[];samples=[];params=[]
    for topic in TOPICS:
        d=data[data.topic.eq(topic)].copy();outcome=OUTCOMES[topic]
        if topic=='general_business':d=d[d.origin>=pd.Period('1919-02','M')]
        controls=['net_direction','net_squared','flat_share','log_articles','n_papers']
        if topic=='markets':controls+=['stock_past_return','stock_past_volatility']
        for feature in STRUCTURES:
            name=f'structure_{topic}_{feature}'
            r,fit,used=estimate(d,feature,outcome,controls,wild=True)
            rows.append(dict(test=name,batch='structural',topic=topic,feature=feature,
                outcome=outcome,variant='primary',block_years=5,**r))
            if len(used):samples.append(used.assign(test=name))
            if fit is not None:
                params.extend([dict(test=name,term=k,coefficient=v) for k,v in fit.params.items()])
                variants=[('blocks_2',d,2),('blocks_10',d,10),
                    ('exclude_2007_2009',d[~d.year.between(2007,2009)],5),
                    ('pre_1980',d[d.year<1980],5),('1980_onward',d[d.year>=1980],5)]
                for label,sub,span in variants:
                    rr,_,_=estimate(sub,feature,outcome,controls,span=span,wild=False)
                    sensitivities.append(dict(test=name,variant=label,block_years=span,**rr))
                from proquest_vintages import CORE_FEATURES
                rr,_,_=estimate(d,feature,outcome,controls+list(CORE_FEATURES),wild=False)
                sensitivities.append(dict(test=name,variant='vintage_macro_controls',block_years=5,**rr))
            pd.DataFrame(rows).to_csv(OUT/'structural_tests_partial.csv',index=False)
            journal('associations','Completed fixed structure test',test=name,**{k:r[k] for k in ['effect','p_value','n','n_blocks','status']})
            print(name, r['status'], 'effect',r['effect'],'p',r['p_value'],'n',r['n'],flush=True)
    assert len(rows)==32
    result=adjust(pd.DataFrame(rows),64)
    result.to_csv(OUT/'structural_tests.csv',index=False)
    old=pd.read_csv(PRIOR/'session_wide_68_tests.csv').assign(research_round='prior')
    pooled=adjust(pd.concat([old,result.assign(research_round='extension')],ignore_index=True),132)
    pooled.to_csv(OUT/'cumulative_tests_partial.csv',index=False)
    pd.DataFrame(sensitivities).to_csv(OUT/'structural_sensitivities.csv',index=False)
    pd.DataFrame(params).to_csv(OUT/'structural_parameters.csv',index=False)
    pd.concat(samples,ignore_index=True).to_csv(OUT/'audits/structural_analysis_rows.csv.gz',index=False,
        compression={'method':'gzip','mtime':0})
    save_json(OUT/'audits/structural_manifest.json',dict(elapsed_seconds=time.monotonic()-start,
        tests=32,planned_round_tests=64,cumulative_minimum_family=132,source_count=check_sources(),
        algebra_note='Within-paper plus between-paper variance equals 1-flat_share-net_direction^2 at the print-month level. Three-month averaging also introduces temporal variation in monthly net direction; the two tests are related decompositions, not independent mechanisms.',
        code_sha256={str(p.relative_to(ROOT)):digest(p) for p in [Path(__file__),OUT/'features.py',OUT/'session_utils.py',OUT/'specs/initial_design.json']}))
    print(result.sort_values('p_value')[['test','effect','p_value','holm_p','n','n_blocks']].to_string(index=False))

if __name__=='__main__':main()
