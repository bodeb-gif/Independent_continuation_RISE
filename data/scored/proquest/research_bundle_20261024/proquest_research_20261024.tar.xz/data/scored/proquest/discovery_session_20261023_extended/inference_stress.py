"""Delete-calendar-block uncertainty and exact-test resolution diagnostics."""
from associations import *
from collect_results import planned

def run():
    family=68+len(planned());rows=[];deleted=[]
    sources=[('structure_employment_cross_topic_gap','structural_analysis_rows.csv.gz',
        'structural_tests.csv','cross_topic_gap',['net_direction','net_squared','flat_share','log_articles','n_papers']),
        ('common_information_pca_factor','common_information_analysis_rows.csv.gz',
         'common_information_tests.csv','pca_factor',['flat_share','log_articles','n_papers','employment_residual']),
        ('common_information_other_after_halves','common_information_analysis_rows.csv.gz',
         'common_information_tests.csv','other_topic_mean',['flat_share','log_articles','n_papers','half0_net_direction','half1_net_direction'])]
    for name,filename,resultfile,feature,controls in sources:
        d=pd.read_csv(OUT/'audits'/filename);d=d[d.test.eq(name)].copy()
        d['origin']=pd.PeriodIndex(d.origin,freq='M')
        result=pd.read_csv(OUT/resultfile).set_index('test').loc[name]
        x=select_design(d,controls).to_numpy(float);j=1
        names=list(select_design(d,controls));j=names.index('tested_predictor')
        y=d.employment_growth.to_numpy(float);groups=(d.year.to_numpy(int)-1900)//5
        codes=np.unique(groups);g=len(codes);n,k=x.shape
        fit=sm.OLS(y,x).fit(cov_type='cluster',cov_kwds={'groups':groups,'use_correction':True,'df_correction':True},use_t=True)
        np.testing.assert_allclose([fit.params[j],fit.bse[j]],[result.effect,result.se],rtol=1e-8,atol=1e-10)
        values=[]
        for block in codes:
            keep=groups!=block;xx=x[keep];yy=y[keep]
            # Deleted era dummies may become zero. The tested coefficient must
            # remain estimable independently of those harmless zero columns.
            other=np.delete(xx,j,axis=1)
            residual=xx[:,j]-other@np.linalg.lstsq(other,xx[:,j],rcond=None)[0]
            if residual@residual<=1e-10:raise ValueError('Tested coefficient not estimable after deletion')
            beta=np.linalg.lstsq(xx,yy,rcond=None)[0][j];values.append(beta)
            deleted.append(dict(test=name,deleted_block=int(block),first_year=int(1900+block*5),
                n_deleted=int((~keep).sum()),remaining_rank=int(np.linalg.matrix_rank(xx)),
                effect_same_full_sample_sd=beta))
        v=np.array(values);effect=fit.params[j]
        for method,center in [('CV3_full_coefficient',effect),('CV3J_leaveout_mean',v.mean())]:
            se=np.sqrt((g-1)/g*np.square(v-center).sum());q=st.t.ppf(.975,g-1)
            p=float(2*st.t.sf(abs(effect/se),g-1))
            rows.append(dict(test=name,method=method,effect=effect,se=se,low=effect-q*se,high=effect+q*se,
                p_value_diagnostic=p,bonferroni_bound_diagnostic=min(1.,p*family),n=n,n_blocks=g,
                primary_p=result.p_value,min_leaveout=v.min(),max_leaveout=v.max(),
                same_sign_leaveouts=int((np.sign(v)==np.sign(effect)).sum())))
    pd.DataFrame(rows).to_csv(OUT/'inference_stress.csv',index=False)
    pd.DataFrame(deleted).to_csv(OUT/'audits/inference_stress_deleted_blocks.csv',index=False)
    resolution=[]
    for g in range(6,24):
        floor=2/(2**g)
        resolution.append(dict(occupied_blocks=g,minimum_two_sided_sign_p=floor,
            conservative_family_size=family,bonferroni_threshold=.05/family,
            can_cross_bonferroni_threshold=bool(floor<=.05/family)))
    pd.DataFrame(resolution).to_csv(OUT/'audits/exact_test_resolution.csv',index=False)
    save_json(OUT/'audits/inference_stress.json',dict(status='complete',family_size=family,
        explanation='At least two mirrored Rademacher sign patterns attain the observed absolute statistic, so the minimum enumerated two-sided p is 2/2^G. Seven five-year blocks in the monthly ML evaluation cannot cross the pooled threshold. Failure of rejection is not evidence of equivalence.',
        jackknife_role='Sensitivity of existing associations to deleting whole occupied calendar blocks. Full-sample feature units and nuisance design are held fixed; zero deleted-era columns are permitted but tested coefficient estimability is checked.',
        limits='CV3/CV3J reference t diagnostics do not repair dependence between blocks, semantic errors or adaptive search. They do not replace the original inference.',
        code_sha256=digest(__file__),source_count=check_sources()))
    journal('inference_stress','Completed calendar-block jackknife and exact-test resolution audit')
    print(pd.DataFrame(rows).to_string(index=False))

if __name__=='__main__':run()
