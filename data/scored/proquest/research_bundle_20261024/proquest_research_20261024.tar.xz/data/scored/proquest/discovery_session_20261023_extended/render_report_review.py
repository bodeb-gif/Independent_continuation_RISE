"""Bounded local Chrome rendering with explicit viewport and image readiness."""
import base64
import subprocess
import tempfile
import time
import urllib.request
import websocket
from session_utils import *


def run():
    chrome='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
    profile=Path(tempfile.mkdtemp(prefix='proquest-report-cdp-'))
    process=subprocess.Popen([chrome,'--headless=new','--disable-gpu','--no-first-run',
        '--no-default-browser-check','--remote-debugging-port=0',
        '--remote-debugging-address=127.0.0.1','--user-data-dir='+str(profile),'about:blank'],
        stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    connection=None
    try:
        deadline=time.monotonic()+15
        port_file=profile/'DevToolsActivePort'
        while not port_file.exists() and time.monotonic()<deadline:
            if process.poll() is not None:raise RuntimeError('Local render browser exited')
            time.sleep(.1)
        if not port_file.exists():raise TimeoutError('Local rendering port unavailable')
        port=int(port_file.read_text().splitlines()[0])
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/json/list',timeout=10) as response:
            targets=json.load(response)
        page=next(x for x in targets if x['type']=='page')
        connection=websocket.create_connection(page['webSocketDebuggerUrl'],timeout=20,suppress_origin=True)
        sequence=0
        def call(method,params=None):
            nonlocal sequence
            sequence+=1;request_id=sequence
            connection.send(json.dumps(dict(id=request_id,method=method,params=params or {})))
            while True:
                response=json.loads(connection.recv())
                if response.get('id')==request_id:
                    if 'error' in response:raise ValueError(response['error'])
                    return response.get('result',{})
        call('Page.enable');call('Runtime.enable')
        records=[]
        for name,anchor,width,height in [('models','models',1440,1200),
            ('neural','neural-reselection',1440,1200),
            ('artifacts','artifacts',1440,1200),('mobile','',390,1000),('desktop','',1440,1200)]:
            call('Emulation.setDeviceMetricsOverride',dict(width=width,height=height,
                deviceScaleFactor=1,mobile=width<700))
            call('Page.navigate',dict(url=(OUT/'report.html').as_uri()))
            ready='''(async()=>{
              if(document.readyState!=='complete')await new Promise(r=>addEventListener('load',r,{once:true}));
              await document.fonts.ready;
              await Promise.all([...document.images].map(i=>i.decode().catch(()=>{})));
              await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
              return {width:innerWidth,height:innerHeight,scrollWidth:document.documentElement.scrollWidth,
                reportTitle:document.title,images:document.images.length};
            })()'''
            result=call('Runtime.evaluate',dict(expression=ready,awaitPromise=True,returnByValue=True))
            if result.get('exceptionDetails'):raise ValueError(result['exceptionDetails'])
            dimensions=result['result']['value']
            if dimensions['width']!=width or dimensions['scrollWidth']>width:
                raise ValueError('Unexpected viewport or horizontal document overflow: '+str(dimensions))
            if dimensions['images']<1 or not dimensions['reportTitle'].startswith('ProQuest economic discovery'):
                raise ValueError('The expected report has not loaded')
            if anchor:
                expression=f'''(async()=>{{document.getElementById({json.dumps(anchor)}).scrollIntoView();
                  await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
                  return {{scrollY,top:document.getElementById({json.dumps(anchor)}).getBoundingClientRect().top}};}})()'''
                scroll=call('Runtime.evaluate',dict(expression=expression,awaitPromise=True,returnByValue=True))['result']['value']
            else:
                call('Runtime.evaluate',dict(expression='scrollTo(0,0)'))
                scroll=dict(scrollY=0,top=0)
            screenshot=call('Page.captureScreenshot',dict(format='png',captureBeyondViewport=False))
            filename='report_'+name+'_review.png'
            png=base64.b64decode(screenshot['data'])
            (OUT/'audits'/filename).write_bytes(png)
            (OUT/'audits'/('report_'+name+'_latest.png')).write_bytes(png)
            records.append(dict(name=name,screenshot='audits/'+filename,dimensions=dimensions,scroll=scroll))
            print(name,dimensions,flush=True)
        save_json(OUT/'audits/report_render_review.json',dict(status='rendered',
            updated_utc=dt.datetime.now(dt.timezone.utc),records=records,
            report_sha256=digest(OUT/'report.html'),code_sha256=digest(__file__),
            role='Local display inspection only; no analysis, source files, model settings or website publication.'))
    finally:
        if connection:connection.close()
        process.terminate()
        try:process.wait(timeout=5)
        except subprocess.TimeoutExpired:process.kill();process.wait(timeout=5)


if __name__=='__main__':run()
