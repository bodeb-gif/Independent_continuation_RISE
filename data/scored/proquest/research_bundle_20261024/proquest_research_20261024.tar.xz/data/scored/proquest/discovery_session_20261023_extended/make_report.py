"""Self-contained economic research report; live status until the time boundary."""
import base64
import datetime as dt
import html
from zoneinfo import ZoneInfo
from session_utils import *
from collect_results import run as collect

def esc(value):return html.escape(str(value))

def table(frame,columns=None):
    d=frame[columns].copy() if columns else frame.copy()
    d.columns.name=None
    if 'task' in d:
        labels={'production_continuous':'Production growth (MSE)',
            'unemployment_continuous':'Unemployment improvement (MSE)',
            'production_downturn':'Production decline (Brier)',
            'unemployment_downturn':'Unemployment rise (Brier)'}
        d['task']=d.task.map(lambda x:labels.get(x,x))
    if 'algorithm' in d:
        labels={'linear':'Ridge / logistic','hist_gradient_boosting':'Boosted trees',
            'extra_trees':'Extra trees','gru':'GRU'}
        d['algorithm']=d.algorithm.map(lambda x:labels.get(x,x))
    if 'comparison' in d:
        labels={'net_minus_macro_coverage':'Add topic directions',
            'structure_minus_net':'Add structural features'}
        d['comparison']=d.comparison.map(lambda x:labels.get(x,x))
    for col in d:
        if pd.api.types.is_float_dtype(d[col]):
            d[col]=d[col].map(lambda x:'' if not np.isfinite(x) else
                f'{x:.2e}' if 0<abs(x)<1e-6 else f'{x:.6f}' if 0<abs(x)<.001 else f'{x:.4f}')
    d=d.fillna('')
    d=d.rename(columns={'macro_coverage':'Macro + coverage',
        'macro_coverage_net':'+ Topic directions',
        'macro_coverage_net_structure':'+ Structural features'})
    return '<div class="table-wrap">'+d.to_html(index=False,border=0,escape=True)+'</div>'

def figure(name,caption):
    path=OUT/'figures'/name
    if not path.exists():return ''
    content=base64.b64encode(path.read_bytes()).decode()
    return f'<figure><img src="data:image/png;base64,{content}" alt="{esc(caption)}"><figcaption>{esc(caption)}</figcaption></figure>'

def build():
    check_sources()
    collect();state=json.loads((OUT/'session.json').read_text());ledger=pd.read_csv(OUT/'cumulative_current_tests.csv')
    new=ledger[ledger.research_round.eq('extension')];status=json.loads((OUT/'audits/ledger_status.json').read_text())
    current=dt.datetime.now(dt.timezone.utc);start=dt.datetime.fromisoformat(state['start_utc'])
    elapsed=(current-start).total_seconds()/3600
    main=ledger.set_index('test').loc['structure_employment_cross_topic_gap']
    survey=ledger.set_index('test').loc['survey_conditional_employment_cross_gap']
    economic=json.loads((OUT/'audits/economic_scale.json').read_text()) if (OUT/'audits/economic_scale.json').exists() else None
    complete=state['status']=='complete'
    duration=float(state['elapsed_wall_hours']) if complete else elapsed
    badge='Completed research session' if complete else 'Research underway · results remain exploratory'
    blocks=[f'<header><p class="eyebrow">PROQUEST ECONOMIC DISCOVERY · SECOND SESSION</p><h1>Other economic outlooks and subsequent employment</h1><p class="lead">A shared economic-outlook signal meets the declared primary multiple-testing screen. Its significance changes with block placement and covariance method, so it remains a candidate finding. Reliable machine-learning forecasting superiority remains unestablished.</p><p class="badge">{badge}</p></header>']
    local=start.astimezone(ZoneInfo('America/Chicago'));end=dt.datetime.fromisoformat(state['minimum_end_utc']).astimezone(ZoneInfo('America/Chicago'))
    pending_note='Pending questions remain in the correction with p=1.' if status['pending_new_tests'] else 'All primary questions are complete.'
    accounting=f'Recorded session duration: {duration:.2f} hours; report generated {current.strftime("%Y-%m-%d %H:%M UTC")}.' if complete else f'This build is {elapsed:.2f} hours after the start.'
    blocks.append(f'<section class="notice"><strong>Session accounting.</strong> Started {esc(local.strftime("%B %d at %I:%M %p Central"))}; requested minimum endpoint {esc(end.strftime("%B %d at %I:%M %p Central"))}. {accounting} {status["completed_new_tests"]} of {status["planned_new_tests"]} locally specified new questions have completed. {pending_note} This is elapsed wall time, including model computation. Numerical repairs, model runs and any tool stalls are recorded in <a href="progress.jsonl">the work log</a>.</section>')
    blocks.append('<nav><a href="#finding">New association</a><a href="#models">Machine learning</a><a href="#other">Other experiments</a><a href="#tests">All tests</a><a href="#methods">Methods</a><a href="#artifacts">Artifacts</a></nav>')
    blocks.append('<section id="finding"><h2>What the new association says</h2>')
    blocks.append(f'<p>The tested gap is employment net direction minus the mean direction of the other supported topics. Conditional on employment direction, its square, neutral share, export coverage and decade effects, a reduction of one standard deviation in that gap corresponds to <strong>{-main.effect:.2f} percentage points more unemployment improvement over the following six months</strong> (pointwise 95% interval {-main.high:.2f} to {-main.low:.2f}; pooled Holm p={main.holm_p:.4f}). The estimate uses {int(main.n)} monthly origins and {int(main.n_blocks)} five-year blocks.</p>')
    if economic:
        blocks.append(f'<p>For a more natural scale, the same coefficient is <strong>{economic["effect_per_one_other_sd"]:.2f} pp per standard deviation of the other-topic index itself</strong> (interval {economic["low_per_one_other_sd"]:.2f}–{economic["high_per_one_other_sd"]:.2f}). A 0.1-point increase in that index corresponds to {economic["effect_per_0_1_index"]:.2f} pp more unemployment improvement. These are equivalent units of the original specified coefficient; its p-value is unchanged.</p>')
    blocks.append('<p>This is an equivalent parameterization of other-topic information after holding the employment signal fixed. It is not proof that forecasters disagree irrationally about the same proposition. Positive business/market/employment direction means stronger activity, higher stock prices or lower unemployment; positive price direction means rising prices and is not called good news.</p>')
    survey_size=f'{-survey.effect/survey.feature_sd*economic["other_direction_sd"]:.2f} pp per original other-topic-index SD' if economic else f'{-survey.effect:.2f} pp per SD of the registered gap'
    blocks.append(f'<p>Controlling earlier survey measures of consumers’ current and expected conditions retains an association of {survey_size} (pooled Holm p={survey.holm_p:.4f}; {int(survey.n)} origins). This is a second test of the same substantive lead, not a second independent economic discovery. The survey download is a retrospective reconstruction covariate; its exact historical vintages and release dates are not claimed as model inputs.</p>')
    if 'common_information_pca_factor' in set(ledger.test):
        factor=ledger.set_index('test').loc['common_information_pca_factor']
        halves=ledger.set_index('test').loc['common_information_other_after_halves']
        if factor.get('status')!='pending':
            blocks.append(f'<h3>Shared information is the clearest interpretation</h3><p>A PCA component learned only from earlier business, market and price outlooks is associated with {factor.effect:.2f} pp subsequent unemployment improvement per SD (interval {factor.low:.2f}–{factor.high:.2f}; pooled Holm p={factor.holm_p:.4f}; {int(factor.n)} origins). It enters jointly with an employment-specific residual, so total employment outlook can change with the common component. The separate employment-residual coefficient does not clear the full testing correction; that does not prove its contribution is zero.</p><p>The other-topic mean also remains associated after two disjoint article halves of employment outlooks enter the regression (pooled Holm p={halves.holm_p:.4f}). These are related measurements of the same historical pattern, not independent discoveries or new holdouts.</p>')
            blocks.append(figure('past_only_factor_loadings.png','PCA uses earlier source vectors only, with orientation fixed by business direction. Loadings describe a statistical component.'))
            blocks.append('<p>A second indicator can improve inference about a persistent current state without containing uniquely forward-looking content. The hypothetical model below demonstrates that interpretation; its parameters are illustrative and were not estimated from this archive. The actual data do not identify which mechanism dominates.</p>')
            blocks.append(figure('common_state_illustration.png','Analytic illustration only. A negative own-minus-other coefficient can reflect complementary noisy measurements of a persistent state.'))
    blocks.append(figure('cross_topic_partial_relationship.png','Partial historical relationship. The orange bins are descriptive full-sample summaries, not a historically evaluated forecasting rule.'))
    blocks.append('<h3>How far the evidence goes</h3><p>The point estimate persists in raw exports, publisher omissions, a two-paper coverage restriction, year effects and earlier print cutoffs. Fresh macro controls reduce it; controlling broad newspaper tone and macro data together leaves an interval spanning zero. Ten-year exact inference has very few clusters and does not support family-wide rejection. The primary five-year finding is therefore conditional on its dependence assumptions and machine interpretation.</p>')
    blocks.append(figure('cross_topic_robustness.png','Positive values show the additional other-topic association with unemployment improvement. Intervals are pointwise; robustness variants are not promoted as independent discoveries.'))
    anchors=OUT/'block_anchor_summary.csv'
    if anchors.exists():
        blocks.append('<h3>Block placement changes the strength of inference</h3><p>All five placements of five-year calendar blocks were retained. The simple gap fails the full-search threshold for several placements. The shared PCA coefficient passes the primary cluster/wild test at every placement, but fails some jackknife variants. No coefficient is uniformly significant across every reasonable dependence specification, and no favorable anchor replaces the original. This is a material qualification of the primary result.</p>')
        blocks.append(table(pd.read_csv(anchors)))
        blocks.append(figure('block_placement_sensitivity.png','All five placements are shown. Adjusted diagnostic bounds above the dotted line fail the 0.05 screen. The shared PCA result also depends on covariance method.'))
        if (OUT/'influence_accounting.csv').exists():
            blocks.append('<p>The fitted point coefficients stay unchanged when the block anchor moves. What changes is the grouping of regression scores: positive and negative annual contributions cancel differently within blocks, changing the estimated uncertainty. This is a covariance sensitivity, not a different economic point estimate.</p>')
            blocks.append(figure('inference_score_grouping.png','Annual fitted-regression score contributions are diagnostics computed using outcomes. They never enter any forecasting feature.'))
    measurement=OUT/'measurement_challenges.csv'
    if measurement.exists():
        d=pd.read_csv(measurement)
        blocks.append('<h3>Measurement challenges</h3><p>The point estimate persists when only stated horizons supply the signal and when employment and other-topic directions come from the same articles. These narrower samples do not retain the full family-wide rejection. Requiring all four topics in each article leaves only 107 supported origins and an interval spanning zero. These restrictions address composition; machine-stated horizons and directions still need source verification.</p>')
        blocks.append(table(d,['variant','effect_per_primary_sd','low_per_primary_sd','high_per_primary_sd','p_value','n','n_blocks']))
    stress=OUT/'inference_stress.csv'
    if stress.exists():
        d=pd.read_csv(stress)
        blocks.append('<p>Deleting any one five-year block preserves the signs of the main gap and PCA coefficients. At the original block placement, calendar-block jackknife reference intervals are wider than the primary intervals, and their nominal p-values remain below a simple Bonferroni bound for those two coefficients. This rejection does not extend to every shifted block placement or every related measurement. These are dependence-assumption sensitivities, not new independent discoveries.</p>')
        blocks.append(table(d[d.method.eq('CV3_full_coefficient')],['test','effect','se','low','high','p_value_diagnostic','bonferroni_bound_diagnostic','min_leaveout','max_leaveout']))
    calibration=OUT/'null_calibration/rejection_rates.csv'
    if calibration.exists():
        d=pd.read_csv(calibration)
        blocks.append('<h3>Calibration limits</h3><p>Forty thousand fixed-design simulations combine six-month overlapping errors with four specified innovation autocorrelations. At a nominal 5% level, the primary cluster/wild maximum rejects approximately 5.5–7.4% of true nulls in these illustrative cases. The block jackknife rejects approximately 1.4–4.3%. Thus exact enumeration of bootstrap signs is not an exact finite-sample guarantee about the null distribution. That pilot alone samples the extreme family-level tail too sparsely to assess its calibration precisely; the larger runs below address that numerical limitation. These simulations neither validate source labels nor establish that the real errors follow any of the simulated processes.</p>')
        blocks.append(table(d[d.level.eq(.05)],['rho','method','draws','rejection_rate','monte_carlo_low','monte_carlo_high']))
    blocks.append('<p><strong>Economic size versus statistical detection.</strong> The estimated other-topic effect is economically noticeable, but the ordinary 95% interval is pointwise. A Bonferroni cluster-t reference interval across this full search is substantially wider. The evidence does not establish a precisely known minimum practical effect, causal policy impact, or a deployable forecast improvement.</p>')
    precision=OUT/'economic_precision.csv'
    if precision.exists():
        blocks.append(table(pd.read_csv(precision),['method','interval','effect_per_other_index_sd','low','high','family_size']))
    high_precision=OUT/'null_calibration_precision/rejection_rates.csv'
    if high_precision.exists():
        d=pd.read_csv(high_precision);d=d[(d.method.eq('primary'))&(d.level.lt(.001))]
        blocks.append('<p>A separate high-precision run used one million simulations per case for the small family-level threshold. Rejection rates were below that threshold in all four specified cases. This reduces Monte Carlo uncertainty about those illustrative designs; it still cannot certify real-world calibration or semantic validity.</p>')
        blocks.append(table(d,['rho','level','draws','rejection_rate','monte_carlo_low','monte_carlo_high']))
    non_gaussian=OUT/'null_calibration_non_gaussian/rejection_rates.csv'
    if non_gaussian.exists():
        d=pd.read_csv(non_gaussian);d=d[(d.method.eq('primary'))&(d.level.lt(.001))]
        blocks.append('<p>Four further million-draw cases add left-skew errors, heavy tails and changing historical block variances. The primary family-threshold rejection rates also remain below nominal in these specified cases. These simulations concern the fixed gap-regression design; they do not validate every ledger test or every possible economic error process.</p>')
        blocks.append(table(d,['case_name','level','draws','rejection_rate','monte_carlo_low','monte_carlo_high']))
        blocks.append(figure('inference_calibration.png','Known-null simulations concern the fixed gap design. Low simulated rejection rates do not establish that real errors or machine labels follow the simulated models.'))
    common_controls=OUT/'common_sample_controls.csv'
    if common_controls.exists():
        blocks.append('<h3>Controls compared on identical origins and effect units</h3><p>On the same 521 origins, adding the historical macro controls changes the other-topic point coefficient from about 0.245 to 0.175 pp per original other-index SD. On the same 368 tone-supported origins, the base estimate is about 0.323 and the tone-plus-macro estimate is about 0.211. Thus control attenuation is not solely a change in sample or standard-deviation units. The shorter samples also have fewer calendar blocks, limiting the attainable adjusted significance.</p>')
        blocks.append(table(pd.read_csv(common_controls),['population','model','effect_per_primary_other_sd','low_per_primary_other_sd','high_per_primary_other_sd','p_value','n','n_blocks']))
    accounting=OUT/'employment_accounting/coefficients.csv'
    if accounting.exists():
        blocks.append('<h3>What the unemployment association represents</h3><p>A descriptive accounting check uses the same 694 origins. The implied unemployment-improvement coefficient is approximately 0.247 pp, with a 0.275 pp employment-level contribution and a −0.028 pp labor-force contribution. The point pattern therefore aligns with employment gains rather than primarily with labor-force contraction. Payroll and household employment growth also have positive point coefficients. These are accounting and benchmark diagnostics without a new significance test or an identified causal mechanism.</p>')
        blocks.append(table(pd.read_csv(accounting),['outcome','effect_per_other_sd','minimum_leaveblock_effect','maximum_leaveblock_effect','n']))
        blocks.append(figure('employment_accounting.png','Symmetric accounting of the implied unemployment change. Contributions are descriptive point coefficients, not identified causal effects.'))
    early_association=OUT/'association_vintage_challenge.csv'
    if early_association.exists():
        blocks.append('<h3>Outcome revisions do not explain much of the point relationship</h3><p>Exact earlier unemployment snapshots permit a same-origin comparison over a shorter historical subset. The gap coefficient changes from about −0.400 with revised outcomes to −0.382 with early-mature outcomes, in the same original gap-SD units and on the same 583 origins. The PCA and article-half point coefficients also change modestly. These are descriptive vintage checks; they do not remove the block-placement sensitivity or supply a new significance claim.</p>')
        blocks.append(table(pd.read_csv(early_association),['test','outcome_vintage','effect_per_original_feature_sd','minimum_leaveblock_effect','maximum_leaveblock_effect','n']))
    blocks.append('</section><section id="models"><h2>Machine learning: gains, uncertainty and the benchmark</h2>')
    blocks.append('<p>Four model families—linear regression/logistic regression, histogram gradient boosting, extra trees and a small unidirectional GRU—use 408 common monthly origins in 1977–2010. Every January, model settings are selected using earlier chronological folds and historical-vintage labels. Every arm shares macro inputs and export-coverage controls. Adding four topic nets and then 32 structural features supplies the two specified comparisons. The GRU uses structured monthly label histories; no raw article text is locally available to this experiment.</p>')
    metrics=[]
    for algorithm in ['linear','hist_gradient_boosting','extra_trees','gru']:
        path=OUT/'models_boundary_corrected'/algorithm/'metrics.csv'
        if path.exists():metrics.append(pd.read_csv(path))
    if metrics:
        m=pd.concat(metrics,ignore_index=True)
        summary=m.pivot(index=['task','algorithm'],columns='arm',values='primary_loss').reset_index()
        blocks.append(table(summary))
        u=m[m.task.eq('unemployment_continuous')].set_index(['algorithm','arm']).primary_loss
        blocks.append(f'<p>For unemployment, the linear macro-plus-coverage baseline has MSE {u.loc[("linear","macro_coverage")]:.3f}, versus {u.loc[("hist_gradient_boosting","macro_coverage")]:.3f} for boosted trees. Adding topic nets improves the boosted-tree point estimate to {u.loc[("hist_gradient_boosting","macro_coverage_net")]:.3f}. That is a substantial within-model improvement, but it also shows why gains against a weaker nonlinear baseline do not establish superiority to a stronger forecasting process.</p>')
    blocks.append(figure('ml_primary_gains.png','All 32 original monthly model-addition tests are retained. Pointwise intervals can exclude zero while the cumulative adjusted test fails.'))
    blocks.append('<p>None of these primary model additions survives the full correction. The joint block-multiplier diagnostics below repeat inner selection for the linear procedure; nonlinear diagnostics hold the originally selected settings fixed. They recompute weighted preprocessing and every chronological fit, averaging all three declared neural seeds. Multiplier ranges are sensitivity diagnostics, not a replacement significant p-value or a correction for semantic label error.</p>')
    blocks.append(f'<p><strong>Power and test resolution.</strong> The 34-year ML evaluation has seven five-year blocks. An enumerated two-sided sign test has a minimum attainable p of 2/2⁷ = 0.015625, which cannot cross the pooled {status["pooled_family"]}-question threshold. Even two-year-block sensitivities do not produce a corrected model gain. The primary failure to reject therefore does not establish equivalence or zero information. More simulations or a larger neural network cannot create additional historical evaluation blocks.</p>')
    combinations=OUT/'benchmark_diagnostics/metrics.csv'
    if combinations.exists():
        d=pd.read_csv(combinations)
        blocks.append('<h3>Stronger benchmark combinations</h3><p>Two descriptive combination rules were constructed after inspecting the original results: equal-weight forecasts from all four families, and selection of the family with the lowest earlier inner-validation loss at each yearly refit. Choices and forecasts were saved before attaching evaluation truth. The equal ensemble improves some point losses with topic signals; prior-validation family selection gives no continuous-unemployment improvement. These adaptive diagnostics receive no new p-value or independent discovery claim.</p>')
        blocks.append(table(d.pivot(index=['task','rule'],columns='arm',values='mean_loss').reset_index()))
    early=OUT/'early_truth_sensitivity/revisions.csv'
    if early.exists():
        d=pd.read_csv(early)
        blocks.append('<h3>Early versus revised outcomes</h3><p>Frozen forecasts were also assessed against the source snapshot strictly before origin + 9 months, allowing three months after the six-month endpoint. This is an early-mature vintage, not the first release. Nine production-downturn labels and ten unemployment-downturn labels change among 408 origins. Point forecast gains remain model-dependent. These later assessment snapshots never enter historical model features or refits.</p>')
        blocks.append(table(d,['task','n','mean_absolute_revision','max_absolute_revision','changed_outcome_months','early_event_rate','final_event_rate']))
    progress=[]
    for algorithm in ['linear','hist_gradient_boosting','extra_trees','gru']:
        path=OUT/'models_boundary_corrected'/algorithm/'refit_multiplier/status.json'
        if path.exists():
            d=json.loads(path.read_text());progress.append(dict(algorithm=algorithm,status=d['status'],
                completed_draws=d.get('completed_draws',d.get('last_completed_draw',-1)+1),
                maximum_draws=d.get('maximum_draws'),selection_repeated=d.get('reselect')))
    if progress:blocks.append(table(pd.DataFrame(progress)))
    combined=OUT/'refit_summary/samplers.csv'
    if combined.exists():
        blocks.append('<p>Independent GRU workers use distinct multiplier streams and the same three-seed estimator. Their completed draws are combined after checking source hashes, uniform reproduction and duplicate weights.</p>')
        blocks.append(table(pd.read_csv(combined)))
        blocks.append(figure('model_refit_ranges.png','Conditional model-reweighting ranges are not the primary time-block test or confidence intervals for unseen economic cycles. The accompanying Monte Carlo precision columns use fixed-count reference calculations, without time-uniform coverage guarantees for the budget stops.'))
    paired=OUT/'models_boundary_corrected/hist_gradient_boosting/reselection_counterfactual/paired_gains.csv'
    if paired.exists():
        d=pd.read_csv(paired)
        if len(d):
            summary=d.groupby(['task','comparison']).agg(draws=('draw','size'),
                fixed_median=('fixed_setting_gain','median'),reselected_median=('full_reselection_gain','median'),
                reselected_min=('full_reselection_gain','min'),reselected_max=('full_reselection_gain','max'),
                paired_difference_min=('reselection_minus_fixed','min'),paired_difference_max=('reselection_minus_fixed','max')).reset_index()
            blocks.append('<h3>Repeating nonlinear model selection</h3><p>A separate time-budgeted boosted-tree probe repeats every chronological inner selection. At exactly the same multiplier weights, a paired counterfactual holds the original settings fixed. Several incremental gains change substantially, including sign changes. The table reports the complete available small probe, with observed minima and maxima rather than purported tail confidence intervals. This diagnoses procedural sensitivity and supplies no new significant forecasting claim.</p>')
            blocks.append(table(summary))
            changes=paired.parent/'selection_changes.csv'
            if changes.exists():blocks.append(table(pd.read_csv(changes)))
    neural_probe=OUT/'models_boundary_corrected/gru/reselection_probe'
    if (neural_probe/'implementation.json').exists():
        blocks.append('<h3 id="neural-reselection">Paired neural reselection audit</h3>')
        neural_pairs=neural_probe/'paired_gains.csv'
        if neural_pairs.exists():
            d=pd.read_csv(neural_pairs)
            observed=d[['task','comparison','draw','fixed_setting_gain','full_reselection_gain','reselection_minus_fixed']].copy()
            observed['draw']=observed.draw+1
            observed=observed.rename(columns={'draw':'Draw','fixed_setting_gain':'Gain: fixed settings',
                'full_reselection_gain':'Gain: full reselection','reselection_minus_fixed':'Reselection − fixed'})
            blocks.append(f'<p>A separately bounded GRU probe repeats the complete historical inner-selection rule and averages every declared outer seed. The fixed-setting counterpart uses exactly the same weights. At most two nonuniform draws were planned; {d.draw.nunique()} completed. This table reports every observed paired gain. It supplies no tail interval, p-value or additional economic discovery.</p>')
            blocks.append(table(observed))
        else:
            blocks.append('<p>This bounded procedural audit has no completed nonuniform draw at this build. It checks full historical model reselection against fixed settings at identical weights; partial draws supply no result. The larger GRU reweighting ranges above continue to hold selected settings fixed.</p>')
        uniform=neural_probe/'uniform_reproduction.json'
        if uniform.exists():
            u=json.loads(uniform.read_text())
            blocks.append(f'<p>The full neural reselection procedure reproduces the canonical forecasts at uniform weights (maximum absolute difference {max(r["max_error"] for r in u["errors"]):.2g}). This checks implementation, without creating independent economic observations.</p>')
    simple=OUT/'simple_benchmarks/metrics.csv'
    seed_gains=OUT/'gru_seed_diagnostics/seed_gains.csv'
    if seed_gains.exists():
        g=pd.read_csv(seed_gains)
        summary=g.groupby(['task','comparison']).gain.agg(seeds='size',minimum='min',median='median',maximum='max').reset_index()
        blocks.append('<h3>All three neural initializations retained</h3><p>Reconstructing every declared seed reproduces the original average within numerical precision. For production growth, structural features raise the loss of each individual seed, yet reduce ensemble MSE by about 0.083. The exact squared-loss decomposition attributes that small gain to the larger benefit from averaging dispersed predictions: mean individual-seed loss rises by about 0.533, while the averaging benefit rises by about 0.616. This is a property of these three fitted seeds, with no new test or evidence about independent economic cycles.</p>')
        blocks.append(table(summary))
    if simple.exists():
        blocks.append('<h3>Simple historical benchmarks</h3><p>An annual training-only historical mean supplies an additional descriptive benchmark, using the same mature historical-vintage labels. Binary frequencies receive fixed Beta(1,1) smoothing. For production growth, its MSE is about 7.408; the GRU with topic nets has MSE about 7.368, an almost negligible point gain compared with the much larger gain against the GRU’s own weaker baseline. This benchmark receives no new significance claim.</p>')
        blocks.append(table(pd.read_csv(simple)))
        blocks.append(figure('probability_reliability.png','Fixed probability bins summarize frozen monthly forecasts. Sparse bins and overlapping months limit interpretation; this is not an independent calibration experiment.'))
    blocks.append('<p class="small">A boundary audit found one exact half-point unemployment increase classified as beyond the band by floating-point rounding. Initial outputs remain under <code>models/</code>. Corrected classifier fits and their audits are under <code>models_boundary_corrected/</code>; unaffected predictions reproduce unchanged, and corrected labels match independent decimal arithmetic.</p></section>')
    blocks.append('<section id="other"><h2>Other questions were retained, including the nulls</h2><ul><li>Confidence/voice differences, horizon structure, revision, breadth and variance components mostly fail the adjusted screen.</li><li>Real-activity/price expectation combinations and same-article co-movement do not establish a corrected discovery.</li><li>Industry employment outlooks show a positive nominal association, but none of the six industry/regional/foreign indicator tests survives correction. They are indicator tests, not individual forecast accuracy against national outcomes.</li><li>The cross-topic future-versus-recent timing contrast is nominally positive in the other-topic parameterization but fails the full screen; it does not independently establish foresight.</li><li>A new six-month stock-price-decline task uses 972 origins in 1930–2010. Its target and -10 log-percent threshold are fixed. The Shiller price history is a retrospective broad-market proxy; this is not an executable trading strategy or exact historical index-vintage test.</li></ul>')
    market=new[new.batch.eq('market_tail')]
    blocks.append('<p>The market task uses only price history, never interpolated dividends, earnings or valuation ratios. Nevertheless, its long price series is a retrospective reconstruction with weaker real-time provenance than the native-vintage macro models. Treat it as a reconstruction diagnostic; its lag checks alone do not establish exact historical index availability.</p>')
    blocks.append(table(market,['test','effect','low','high','p_value','holm_p','n','status']))
    for batch,title,description in [
        ('conditional_credibility','Confidence, expertise and uncertainty','Sixteen matched-cell questions test whether assertive-minus-hedged or expert-minus-journalist accuracy varies with earlier policy uncertainty or dated-rollcall polarization. The two historical conditions enter jointly. None establishes a corrected relationship. Both conditions are retrospective historical descriptors, excluded from the ML inputs. EPU also uses overlapping newspaper sources.'),
        ('term_direction_curve','Near versus far outlooks','Four questions test whether the earlier long-minus-short outlook index relates to the change in realized direction between six- and twelve-month cumulative outcomes. Original deterministic bands are used. Mixed stated horizons prevent a calibrated term-structure interpretation.'),
        ('election_voice','Election-calendar comparisons','Matched official-minus-expert direction, assertiveness and accuracy are tested around the fixed pre-election calendar. No party identity or causal political influence is inferred.'),
        ('productivity_distribution','Productivity and labor compensation','The business-minus-employment outlook gap is compared with subsequent productivity, real compensation and labor-share changes. Average real compensation is not median wages or inequality. None of the three establishes a corrected discovery.')]:
        selected=new[new.batch.eq(batch)]
        if len(selected):
            blocks.append(f'<h3>{esc(title)}</h3><p>{esc(description)}</p>')
            blocks.append(table(selected,['test','effect','low','high','p_value','holm_p','n','status']))
    blocks.append(f'</section><section id="tests"><h2>All {status["pooled_family"]} questions across the two discovery sessions</h2><p>The new round contains {status["planned_new_tests"]} locally specified questions, pooled conservatively with the previous session’s 68. Both Holm and BH values are retained. These sessions do not exhaust older repository experimentation, adaptive question choice, or measurement uncertainty. No historical period here is a new untouched holdout.</p>')
    accounting=new.assign(estimated=new.status.eq('estimated'),
        unsupported=new.status.fillna('').str.startswith('insufficient'),
        pooled_rejection=new.holm_p.lt(.05)).groupby('batch').agg(
            questions=('test','size'),estimated=('estimated','sum'),unsupported=('unsupported','sum'),
            pooled_holm_rejections=('pooled_rejection','sum')).reset_index()
    assert accounting.questions.sum()==status['planned_new_tests']
    accounting.to_csv(OUT/'question_family_summary.csv',index=False)
    display_accounting=accounting.copy()
    labels={'structural':'Forecast structure','monthly_ml':'Macro forecasting models',
        'cross_components':'Separate topic components','joint_expectations':'Joint activity / price outlooks',
        'cross_timing':'Future versus recent outcomes','survey_controls':'Consumer-survey controls',
        'market_tail':'Stock-decline models','scope_indicators':'Industry / regional / foreign indicators',
        'election_voice':'Election-calendar contrasts','productivity_distribution':'Productivity / compensation / labor share',
        'common_information':'Common information measurements','conditional_credibility':'Credibility and uncertainty / polarization',
        'term_direction_curve':'Near versus far stated outlooks'}
    display_accounting['batch']=display_accounting.batch.map(lambda x:labels.get(x,x))
    display_accounting=display_accounting.rename(columns={'batch':'New question group','questions':'Questions',
        'estimated':'Estimated','unsupported':'Unsupported','pooled_holm_rejections':'Pooled Holm rejections'})
    blocks.append(table(display_accounting))
    blocks.append('<p>Unsupported questions stay in the family with p=1. Rejection counts describe tests; the related employment measurements represent one substantive lead.</p>')
    display=ledger.sort_values('p_value').copy()
    blocks.append(table(display,['test','research_round','effect','low','high','p_value','holm_p','bh_q','n','n_blocks','status']))
    blocks.append('<p>The previous confidence contrast, which passed the 68-test screen, no longer clears pooled Holm after this expanded search. Its source-measurement qualification also remains. Rows describing the same substantive signal are not counted as multiple independent economic discoveries.</p></section>')
    blocks.append('<section id="methods"><h2>Scope, timing and what significance does not validate</h2><p>Only the 111 annual verified ProQuest exports, 1900–2010, supply primary claims. The matching 111 annual raw exports supply sensitivity data. There are no pooled LOC claims, old crisis-window exports, or modern claims. Identical stripped labels remain; article averaging is weighting, not deduplication. All 222 annual source hashes remain unchanged.</p><p>Features are explicitly whitelisted printed metadata. No retrospective window annotations, verifier prose, economic outcomes, or outcome eligibility enter them. Monthly signals use completed earlier print months. Macro forecasts use native historical production vintages and exact prior-as-of unemployment snapshots, with endpoint+three months strictly before each fitting or selection cutoff. Missing source coverage is missing, not neutral sentiment. Export counts do not measure population newspaper attention.</p><p>Claims remain machine interpreted. The existing historical human sample is too small to reconstruct a validated monthly panel or establish the confidence advantage. Strong temporal p-values cannot repair a false forecast, wrong topic, wrong scope or wrong horizon. Current results establish conditional relationships in the selected archive; they establish neither causation nor distinct information beyond every existing predictor.</p>')
    packet=OUT/'source_validation_packet/protocol.json'
    if packet.exists():
        p=json.loads(packet.read_text())
        blocks.append(f'<p>An outcome-blind probability sample is prepared for source review of the employment lead: {p["n_origins"]} calendar-stratified origins, {p["n_articles"]} articles and {p["n_machine_panel_rows"]} machine panel rows. The reviewer file withholds machine labels and outcomes. Original article text is not locally available, so this is a prepared packet, <strong>not completed human validation</strong>. Its frame excludes articles without readable machine panel labels and therefore cannot estimate newspaper-wide recall.</p>')
    blocks.append('<p><strong>Novelty.</strong> Published work already uses newspaper sentiment, topics and common factors to model output and employment. The candidate contribution here is a specific cross-topic contrast in this historical forecast-claim archive. The present evidence does not establish a first-in-literature finding or prove that its information is distinct from the current economic state and broader news tone.</p>')
    blocks.append('<p>Historical length alone is also insufficient: <a href="https://onlinelibrary.wiley.com/doi/10.1111/jofi.13377">Bybee and coauthors</a> extend topic attention back to 1890, while <a href="https://www.nber.org/papers/w32026">van Binsbergen and coauthors</a> study roughly 170 years of local-newspaper sentiment. The <a href="reference/literature_comparison.csv">comparison table</a> records the narrower measurement distinction and the evidence still missing. The forecasting exercises here use different data and targets from those papers and are not direct replications.</p>')
    blocks.append('<p>Cross-variable forecast consistency also has an established literature, including <a href="https://www.imf.org/external/pubs/ft/wp/2014/wp1424.pdf">aligned output and unemployment forecasts</a> and <a href="https://www.imf.org/en/publications/wp/issues/2026/07/31/looking-for-underlying-structure-in-weo-forecasts-578363">recent WEO-coherence research</a>. Directions taken from different articles, targets and horizons do not supply the matched quantitative objects needed to infer individual incoherence or an Okun-law violation.</p>')
    notes=json.loads((OUT/'reference/literature_notes.json').read_text())['notes']
    blocks.append('<h3>Primary literature and external benchmarks</h3><ul>')
    for item in notes:blocks.append(f'<li><a href="{esc(item["url"])}">{esc(item["title"])}</a>: {esc(item["role"])}</li>')
    blocks.append('</ul></section><section id="artifacts"><h2>Reproduce and inspect</h2><p>Use the working scientific Python environment for panels and regression; the isolated <code>/private/tmp/proquest-ml-20261023/bin/python</code> contains the model libraries. Do not use the broken repository-root environment. All source data and previous results remain unchanged. The final manifest records code, input, environment and output hashes. Work on a copy for regeneration: rebuilding updates derived files covered by that manifest.</p>')
    links=[('cumulative_current_tests.csv','Pooled test ledger'),('extension_current_tests.csv','New-round test ledger'),
        ('question_family_summary.csv','Question-family accounting'),
        ('specs/initial_design.json','Initial design'),('specs/ml_grid.json','Model grid'),
        ('audits/validation_initial.json','Independent inference/timing checks'),
        ('audits/boundary_validation.json','Exact boundary validation'),('audits/boundary_correction.json','Classifier repair audit'),
        ('paper_timing_robustness.csv','Publisher and timing challenges'),('survey_sensitivities.csv','Survey-control sensitivities'),
        ('measurement_challenges.csv','Horizon and same-article challenges'),('inference_stress.csv','Calendar-block jackknife'),
        ('benchmark_diagnostics/metrics.csv','Forecast combination benchmarks'),('early_truth_sensitivity/gains.csv','Outcome-vintage sensitivity'),
        ('null_calibration/rejection_rates.csv','Illustrative inference calibration'),('source_validation_packet/protocol.json','Prepared source-review sample'),
        ('block_anchor_challenge.csv','All five block placements'),('common_sample_controls.csv','Controls on identical samples'),
        ('employment_accounting/coefficients.csv','Employment and labor-force accounting'),
        ('simple_benchmarks/model_comparison.csv','Historical-mean model benchmarks'),('refit_summary/ranges.csv','Combined model-reweighting ranges'),
        ('gru_seed_diagnostics/seed_gains.csv','Every declared neural-seed gain'),
        ('gru_seed_diagnostics/ensemble_accounting.csv','Exact neural ensemble-loss accounting'),
        ('models_boundary_corrected/hist_gradient_boosting/reselection_counterfactual/paired_gains.csv','Paired full-reselection sensitivity'),
        ('models_boundary_corrected/gru/reselection_probe/paired_gains.csv','Paired neural reselection values'),
        ('models_boundary_corrected/gru/reselection_probe/uniform_reproduction.json','Full neural reselection reproduction check'),
        ('association_vintage_challenge.csv','Earlier versus revised association outcomes'),('audits/estimability_validation.json','Full-control coefficient identification checks'),
        ('audits/leading_tail_validation.json','Direct exhaustive refits of the leading test tails'),
        ('audits/saved_model_inputs_validation.json','Features and assessment truth versus fitted-model snapshots'),
        ('audits/saved_model_dependencies.json','Bound model dependencies and library versions'),
        ('audits/gru_saved_draw_replay.json','Saved GRU draw reproduction'),
        ('audits/linear_saved_draw_replay.json','Saved linear/logistic draw reproduction with reselection'),
        ('audits/hgb_saved_draw_replay.json','Saved boosted-tree draw reproduction'),
        ('audits/extra_trees_saved_draw_replay.json','Saved extra-trees draw reproduction'),
        ('replay_refit.py','Replay one saved model reweighting'),('safe_refit_runner.py','Explicit-deadline sampler wrapper'),
        ('final_manifest.json','Final source, code and output manifest'),
        ('progress.jsonl','Work log'),('session.json','Session accounting')]
    blocks.append('<ul>'+''.join(f'<li><a href="{esc(path)}">{esc(label)}</a></li>' for path,label in links if (OUT/path).exists() or (complete and path=='final_manifest.json'))+'</ul>')
    final_validation=OUT/'audits/final_validation.json'
    if final_validation.exists():
        v=json.loads(final_validation.read_text())
        blocks.append(f'<p><strong>Closing verification.</strong> All {v["required_test_checks"]} required software checks passed across the offline, scoring and forecasting suites. The final source audit confirms {v["source_hashes_unchanged"]} unchanged original source/document/code hashes, including all 222 annual claim exports. Independent direct-source aggregation, full-control coefficient identification, time availability, classification-boundary and no-future-feature checks are linked in the audit artifacts.</p>')
    commands=f'''study={OUT.relative_to(ROOT)}
science_python=/opt/anaconda3/bin/python3
ml_python=/private/tmp/proquest-ml-20261023/bin/python

# Rebuild the report from the saved results, from the repository root.
"$science_python" "$study/collect_results.py"
"$science_python" "$study/summarize_refits.py"
"$science_python" "$study/make_report.py"

# Reproduce a saved GRU draw without changing its sampler checkpoints.
"$ml_python" "$study/replay_refit.py" "$study/models_boundary_corrected/gru/refit_multiplier_shards/shard_1/draw_0000.json"
'''
    blocks.append('<pre>'+esc(commands)+'</pre><p class="small">The environment freezes are saved under <code>audits/</code>; the temporary ML environment may need to be recreated later. Full analysis entry points and their specifications are retained in this directory. For additional replications, copy the result directory and use the explicit-deadline wrapper, which checks frozen model dependencies and library versions before fitting. The original sampler CLI preserves the session’s fixed stop time, so it should not be used directly to resume after that date. Initial model outputs remain for the numerical audit.</p></section>')
    style='''body{font:16px/1.6 system-ui,-apple-system,sans-serif;color:#203340;background:#f8fafb;margin:0}header,section,nav{max-width:1180px;margin:0 auto;padding:28px 32px}header{padding-top:55px;padding-bottom:25px}h1{font-size:42px;line-height:1.15;max-width:950px;color:#123f54}h2{font-size:27px;color:#123f54;line-height:1.25}h3{font-size:21px}a{color:#12677d}section{background:white;margin-top:20px;border-radius:7px;border:1px solid #e4ebef;box-sizing:border-box}nav{display:flex;gap:22px;flex-wrap:wrap;font-size:14px}.eyebrow{font-size:12px;font-weight:700;letter-spacing:.12em;color:#527885}.lead{font-size:20px;max-width:1030px}.badge{display:inline-block;background:#e3f0f3;color:#184f61;padding:6px 13px;border-radius:4px;font-size:13px}.notice{background:#fff5e7;border-color:#efdfc9;font-size:14px}figure{margin:30px 0}img{max-width:100%;height:auto;display:block}figcaption,.small{font-size:13px;color:#566a76}.table-wrap{overflow-x:auto;margin:22px 0}table{border-collapse:collapse;min-width:100%;font-size:12px;line-height:1.4}th{background:#edf3f5;text-align:left;white-space:nowrap}th,td{padding:9px 10px;border-bottom:1px solid #e4ebef;vertical-align:top}tr:nth-child(even){background:#fafcfd}td:first-child{min-width:230px}pre{overflow:auto;background:#eef3f5;padding:18px;font-size:12px}li{margin:8px 0}@media(max-width:700px){header,section,nav{padding:20px}h1{font-size:30px}.lead{font-size:18px}}'''
    document='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>ProQuest economic discovery · second session</title><style>'+style+'</style></head><body>'+''.join(blocks)+'</body></html>'
    (OUT/'report.html').write_text(document)
    save_json(OUT/'audits/report_build.json',dict(generated_utc=current,elapsed_wall_hours=duration,
        generated_hours_after_start=elapsed,
        session_status=state['status'],completed_new_tests=status['completed_new_tests'],bytes=len(document.encode()),
        code_sha256=digest(__file__)))
    print('Built',OUT/'report.html','bytes',len(document.encode()),'status',state['status'])

if __name__=='__main__':build()
