"""Standalone scientific figures for inference and economic interpretation."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from session_utils import *

def save(fig,name):
    fig.savefig(OUT/'figures'/(name+'.png'),dpi=170,bbox_inches='tight')
    fig.savefig(OUT/'figures'/(name+'.svg'),bbox_inches='tight');plt.close(fig)

def run():
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    fig,axes=plt.subplots(1,2,figsize=(12,4.6))
    sources=[('null_calibration_precision','rho',['0','0.5','0.9','0.98'],'Gaussian innovation autocorrelation'),
        ('null_calibration_non_gaussian','case_name',['Left skew','Student t3','Variable variance\nGaussian AR0.5','Variable variance\nleft-skew AR0.5'],'Additional error cases')]
    methods=[('cluster','Cluster t','#7d8c95'),('primary','Primary max t/wild','#126b80'),('cv3','Block jackknife','#c97b32')]
    for ax,(directory,key,labels,title) in zip(axes,sources):
        f=pd.read_csv(OUT/directory/'rejection_rates.csv');f=f[f.level.lt(.001)]
        values=list(f[key].drop_duplicates());xx=np.arange(len(values))
        for offset,(method,label,color) in zip([-.2,0,.2],methods):
            g=f[f.method.eq(method)].set_index(key).reindex(values)
            rate=g.rejection_rate/g.level;low=g.monte_carlo_low/g.level;high=g.monte_carlo_high/g.level
            ax.errorbar(xx+offset,rate,yerr=[rate-low,high-rate],fmt='o',color=color,ms=5,capsize=3,label=label)
        ax.axhline(1,color='#9b3f3f',ls='--',lw=1);ax.set_xticks(xx,labels)
        ax.set_title(title,fontsize=11);ax.set_ylim(0,3.3);ax.set_ylabel('Null rejection rate / nominal threshold')
    axes[0].legend(frameon=False,fontsize=9,loc='upper left')
    fig.suptitle('Illustrative calibration at the full-search threshold',fontsize=14,y=1.03)
    fig.text(.01,-.06,'One million simulations per case at α = 0.05 / 204. Bars show Monte Carlo intervals. Fixed gap design only; this does not validate real-world assumptions.',fontsize=9)
    fig.tight_layout();save(fig,'inference_calibration')
    f=pd.read_csv(OUT/'block_anchor_challenge.csv')
    names=[('structure_employment_cross_topic_gap','Conditional other-topic gap'),
        ('common_information_pca_factor','Shared PCA component'),
        ('common_information_other_after_halves','Other topics after article halves')]
    fig,axes=plt.subplots(1,3,figsize=(12,4.2),sharey=True)
    for ax,(name,label) in zip(axes,names):
        d=f[f.test.eq(name)].sort_values('anchor_offset')
        ax.plot(d.anchor_offset,d.primary_bonferroni_bound,'o-',color='#126b80',label='Primary t/wild')
        ax.plot(d.anchor_offset,d.jackknife_bonferroni_bound,'s--',color='#c97b32',label='Block jackknife')
        ax.axhline(.05,color='#9b3f3f',ls=':',lw=1.5);ax.set_yscale('log');ax.set_ylim(.002,1.3)
        ax.set_xticks(range(5));ax.set_title(label,fontsize=11);ax.set_xlabel('Five-year block anchor offset')
    axes[0].set_ylabel('Diagnostic Bonferroni bound');axes[0].legend(frameon=False,fontsize=9)
    fig.suptitle('Significance depends on block placement and covariance method',fontsize=14,y=1.03)
    fig.text(.01,-.06,'Offsets shift the original 1900 boundary by 0–4 years. Every placement is retained. The dotted line is 0.05; these are related checks of the same lead.',fontsize=9)
    fig.tight_layout();save(fig,'block_placement_sensitivity')
    d=pd.read_csv(OUT/'employment_accounting/coefficients.csv').set_index('outcome').effect_per_other_sd
    employment=d['employment_accounting_component_pp'];labor=d['labor_force_accounting_component_pp']
    total=d['implied_unemployment_improvement_pp'];original=d['original_unemployment_improvement_pp']
    fig,ax=plt.subplots(figsize=(8,4.2));positions=np.arange(4)
    ax.bar(0,employment,color='#126b80',width=.62)
    ax.bar(1,labor,bottom=employment,color='#c97b32',width=.62)
    ax.bar(2,total,color='#4f8c97',width=.62)
    ax.bar(3,original,color='#65737d',width=.62)
    ax.plot([.31,.69],[employment,employment],color='#a0a8ae',lw=1)
    ax.plot([1.31,1.69],[total,total],color='#a0a8ae',lw=1)
    for x,y,label in [(0,employment,f'+{employment:.3f}'),(1,employment+labor/2,f'{labor:.3f}'),
        (2,total,f'{total:.3f}'),(3,original,f'{original:.3f}')]:
        ax.text(x,y+.009,label,ha='center',va='bottom',fontsize=10)
    ax.axhline(0,color='#a0a8ae',lw=1)
    ax.set_xticks(positions,['Employment\ncomponent','Labor-force\ncomponent','Implied rate\nimprovement','Published rate\nimprovement'])
    ax.set_ylabel('pp per standard deviation of other-topic index')
    ax.set_title('Accounting decomposition of the point association',fontsize=14);ax.set_ylim(-.02,.335)
    fig.text(.01,-.04,'Same 694 origins and original feature units. Exact symmetric ratio decomposition within household levels; descriptive coefficients, not causal effects or new significance tests.',fontsize=8.5)
    fig.tight_layout();save(fig,'employment_accounting')
    save_json(OUT/'audits/diagnostic_figures.json',dict(status='complete',code_sha256=digest(__file__),
        figures=['inference_calibration','block_placement_sensitivity','employment_accounting']))
    journal('figures','Created calibration, anchor sensitivity and employment-accounting figures')

if __name__=='__main__':run()
