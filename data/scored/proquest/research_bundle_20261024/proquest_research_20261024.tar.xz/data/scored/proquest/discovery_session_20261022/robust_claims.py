"""Challenge the business-confidence finding and inspect human measurement error."""
from common import *
from run_primary import matched_cells
from proquest_descriptive import load_reference, realized_outcome
from proquest_human_rescore import human_horizon
from score_predictions import predicted_norm
from statsmodels.stats.proportion import proportion_confint


def confidence_sensitivities():
    verified=pd.read_csv(BASE/'descriptive/scored_claims.csv.gz',dtype={'page_id':str})
    raw=pd.read_csv(BASE/'robustness/scored_claims.csv.gz',dtype={'page_id':str})
    assert set(raw.source_set)=={'raw','verified'}
    raw=raw[raw.source_set.eq('raw')]
    for f in [verified,raw]:
        f['month']=pd.PeriodIndex(pd.to_datetime(f.date),freq='M')
    v=verified
    specs=[('primary_verified',v,2),('raw_sensitivity',raw,2),
           ('stated',v[v.horizon_basis.eq('stated')],2),
           ('nondefault',v[v.horizon_basis.ne('default')],2),
           ('default_only',v[v.horizon_basis.eq('default')],2),
           ('exclude_great_depression',v[~v.year.between(1929,1939)],2),
           ('exclude_great_recession',v[~v.year.between(2007,2009)],2),
           ('expansion_print_months',v[v.recession_at_print.eq(0)],2),
           ('1919_1964',v[v.year.between(1919,1964)],2),
           ('1965_2010',v[v.year.between(1965,2010)],2),
           ('minimum_one_article',v,1),('minimum_five_articles',v,5)]
    specs += [('omit_'+paper,v[v.paper.ne(paper)],2) for paper in sorted(v.paper.unique())]
    rows=[]
    for name,f,minimum in specs:
        cells=matched_cells(f,'confidence','assertive','hedged','general_business',minimum)
        if cells.empty:continue
        result=clustered_mean(cells.difference,cells.weight,cells.year)
        rows.append(dict(variant=name,n_cells=len(cells),left_rate=np.average(cells.hit_left,weights=cells.weight),right_rate=np.average(cells.hit_right,weights=cells.weight),**result))
    cells=matched_cells(v,'confidence','assertive','hedged','general_business',2)
    for span in [2,5,10]:
        for anchor in [1900,1902]:
            rows.append(dict(variant=f'blocks_{span}_anchor_{anchor}',**clustered_mean(cells.difference,cells.weight,cells.year,span,anchor)))
    # Equal print-month mass after preserving the primary within-month cell mix.
    month=cells.assign(weighted=cells.difference*cells.weight).groupby('month').agg(weighted=('weighted','sum'),weight=('weight','sum'))
    rows.append(dict(variant='equal_occupied_months',**clustered_mean(month.weighted/month.weight,np.ones(len(month)),month.index.year)))
    # Stronger same-article comparison; no assertion that two labels are duplicates.
    f=v[v.topic.eq('general_business') & v.basis.eq('INDPRO') & v.hit.notna() & v.confidence.isin(['assertive','hedged'])]
    keys=['page_id','month','topic','basis','horizon_basis','horizon_used','voice']
    a=f.groupby(keys+['confidence']).hit.mean().unstack('confidence').dropna()
    a['difference']=a.assertive-a.hedged
    a=a.reset_index()
    rows.append(dict(variant='within_same_article',left_rate=a.assertive.mean(),right_rate=a.hedged.mean(),**clustered_mean(a.difference,np.ones(len(a)),a.month.dt.year)))
    a.to_csv(OUT/'within_article_confidence.csv',index=False)
    # Read deterministic realized outcomes for descriptive contrast decomposition.
    ref=f.groupby(['month','topic','basis','horizon_basis','horizon_used']).agg(realized=('realized','first'),baseline=('fixed_baseline_hit','first')).reset_index()
    c=cells.merge(ref,on=['month','topic','basis','horizon_basis','horizon_used'],validate='many_to_one')
    c['horizon_group']=np.where(c.horizon_basis.eq('default'),'default','claim_grounded')
    tables=[]
    for key in ['realized','voice','horizon_group']:
        for value,g in c.groupby(key):
            tables.append(dict(grouping=key,group=value,n_cells=len(g),weight=g.weight.sum(),
                               assertive_accuracy=np.average(g.hit_left,weights=g.weight),hedged_accuracy=np.average(g.hit_right,weights=g.weight),
                               baseline_accuracy=np.average(g.baseline,weights=g.weight),gap=np.average(g.difference,weights=g.weight)))
    pd.DataFrame(tables).to_csv(OUT/'confidence_decomposition.csv',index=False)
    pd.DataFrame(rows).to_csv(OUT/'confidence_robustness.csv',index=False)
    return verified


def human_checks(verified):
    source=BASE/'reverify300_20261022/paired_comparison.json'
    paired=json.loads(source.read_text())
    hist=[r for r in paired if r['sampling_frame']=='historical_1900_2010']
    assert len(hist)==250
    lookup=verified.set_index('record_id');series,_=load_reference();rows=[]
    for r in hist:
        rid=':'.join(r['audit_id'].split(':')[1:]);m=lookup.loc[rid]
        assert r['source_metadata']['page_id']==m.page_id
        for reviewer in ['reviewer1','reviewer2']:
            h=r[reviewer];decision=r[reviewer+'_decision']
            pred=predicted_norm(h)
            months=human_horizon(h.get('horizon_months'),m.horizon_months,m.horizon_used)
            genuine=decision=='include';eligible=genuine and h.get('scope')=='national' and h.get('topic') in ['general_business','markets','prices','employment'] and pred is not None and months is not None
            realized=None;basis=None;error='human eligibility'
            if eligible:
                realized,basis,error=realized_outcome(series,h['topic'],str(m.month),months)
            g=eligible and error is None
            rows.append(dict(record_id=rid,reviewer=reviewer,year=m.year,date=m.date,machine_topic=m.topic,
                             machine_confidence=m.confidence,machine_voice=m.voice,machine_horizon_basis=m.horizon_basis,machine_hit=m.hit,
                             human_decision=decision,human_scope=h.get('scope'),human_topic=h.get('topic'),human_confidence=h.get('confidence'),
                             genuine=int(genuine),human_scorable=int(g),human_hit=int(pred==realized) if g else np.nan,
                             human_basis=basis,human_months=months,reason=error,extra_pass_keep=r['new_keep']))
    d=pd.DataFrame(rows);d.to_csv(OUT/'historical_human_measurement.csv',index=False)
    summaries=[]
    subsets={'all_historical':d,'machine_business_1919plus':d[d.machine_topic.eq('general_business')&(d.year>=1919)],
             'machine_employment':d[d.machine_topic.eq('employment')],
             'human_business_1919plus':d[d.human_topic.eq('general_business')&(d.year>=1919)]}
    for subset,f in subsets.items():
        for keys in [['reviewer','machine_confidence'],['reviewer','human_confidence']]:
            for values,g in f.groupby(keys):
                n=len(g);scorable=int(g.human_scorable.sum());hits=int(g.human_hit.sum())
                gl,gu=proportion_confint(g.genuine.sum(),n,method='wilson')
                sl,su=proportion_confint(scorable,n,method='wilson')
                al,au=proportion_confint(hits,scorable,method='wilson') if scorable else (np.nan,np.nan)
                summaries.append(dict(subset=subset,grouping=keys[-1],reviewer=values[0],confidence=values[1],
                                      n=n,genuine=g.genuine.mean(),genuine_low=gl,genuine_high=gu,
                                      scorable_share=scorable/n,scorable_low=sl,scorable_high=su,n_scorable=scorable,
                                      human_accuracy=hits/scorable if scorable else np.nan,accuracy_low=al,accuracy_high=au,
                                      machine_accuracy=g.machine_hit.mean()))
    pd.DataFrame(summaries).to_csv(OUT/'human_confidence_diagnostics.csv',index=False)
    write_json('human_measurement_manifest.json',dict(n_historical=250,n_reviewers=2,modern_included=0,
               caveat='Small unmatched subgroup checks, no validation of census effect; Wilson intervals omit reviewer and temporal uncertainty.',
               source_sha256={str(source.relative_to(ROOT)):digest(source)}))


if __name__=='__main__':
    human_checks(confidence_sensitivities())
    print(pd.read_csv(OUT/'confidence_robustness.csv')[['variant','effect','low','high','p_value','n','n_blocks']].to_string(index=False))
    print(pd.read_csv(OUT/'human_confidence_diagnostics.csv').to_string(index=False))
