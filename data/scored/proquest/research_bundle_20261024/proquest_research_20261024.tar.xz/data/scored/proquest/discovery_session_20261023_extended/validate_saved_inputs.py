"""Check frozen feature/truth snapshots and guard future sampler resumption."""
import importlib.metadata
from model_data import feature_frame,TASKS
from boundary_rules import corrected_evaluation_truth
from session_utils import *

FREEZE=OUT/'audits/saved_model_dependencies.json'


def versions():
    return {name:importlib.metadata.version(package) for name,package in [
        ('numpy','numpy'),('pandas','pandas'),('scipy','scipy'),
        ('sklearn','scikit-learn'),('torch','torch')]}


def resolve_recorded(name,session_root):
    """Keep a copied result folder bound to its own recorded local inputs."""
    path=Path(name);old=Path(session_root)
    return OUT/path.relative_to(old) if path.is_relative_to(old) else ROOT/path


def verify_frozen_inputs(check_runtime=True):
    receipt=json.loads(FREEZE.read_text())
    if receipt['validator_sha256']!=digest(__file__):
        raise ValueError('The saved-input validator changed; no sampler was invoked')
    for name,expected in receipt['input_hashes'].items():
        if digest(resolve_recorded(name,receipt['session_root_relative']))!=expected:
            raise ValueError('A frozen model dependency changed: '+name)
    if check_runtime and versions()!=receipt['library_versions']:
        raise ValueError('Model-library versions differ from the frozen ML environment')
    check_sources()
    return receipt


def run():
    if FREEZE.exists():verify_frozen_inputs()
    frame,valid=feature_frame()
    saved=pd.read_csv(OUT/'cache/model_features.csv.gz',index_col=0)
    saved.index=pd.PeriodIndex(saved.index,freq='M')
    assert list(saved.index)==list(frame.index) and list(saved.columns)==list(frame.columns)
    left=frame.to_numpy(float);right=saved.to_numpy(float)
    np.testing.assert_array_equal(np.isnan(left),np.isnan(right))
    np.testing.assert_allclose(left,right,rtol=1e-12,atol=1e-12,equal_nan=True)
    feature_error=float(np.nanmax(abs(left-right)))
    origins=pd.period_range('1977-01','2010-12',freq='M')
    truth={task:pd.Series(corrected_evaluation_truth(origins,task),index=origins) for task in TASKS}
    comparisons=0;truth_error=0.
    for algorithm in ['linear','hist_gradient_boosting','extra_trees','gru']:
        d=pd.read_csv(OUT/'models_boundary_corrected'/algorithm/'predictions.csv')
        d.origin=pd.PeriodIndex(d.origin,freq='M')
        for task,g in d.groupby('task'):
            expected=truth[task].reindex(g.origin).to_numpy(float)
            np.testing.assert_allclose(g.truth,expected,rtol=1e-12,atol=1e-12)
            truth_error=max(truth_error,float(np.max(abs(g.truth.to_numpy(float)-expected))))
            comparisons+=len(g)
    paths=[PRIOR/'phase2/fresh_core_forecast_features.csv',PRIOR/'continuous_targets.csv',
        PRIOR/'reference/alfred_UNRATE_month_end_1960_2010.zip',
        PRIOR/'reference/alfred_UNRATE_month_end_1960_2010.manifest.json',
        BASE/'macro_information/IPT_vintages_through_2010.csv.gz',
        OUT/'cache/model_features.csv.gz',OUT/'session_utils.py',OUT/'refit_multiplier_corrected.py',
        OUT/'model_data.py',OUT/'monthly_ml_corrected.py',OUT/'boundary_rules.py',OUT/'recurrent_ml.py',OUT/'design.py',
        OUT/'cache/features_verified.csv.gz',OUT/'specs/ml_grid.json',OUT/'specs/initial_design.json',
        ROOT/'src/proquest_vintages.py',ROOT/'src/score_predictions.py']
    for algorithm in ['linear','hist_gradient_boosting','extra_trees','gru']:
        completion=json.loads((OUT/'models_boundary_corrected'/algorithm/'completion.json').read_text())
        for name,expected in completion['input_hashes'].items():
            # Original canonical receipts record this same study-directory name.
            path=resolve_recorded(name,'data/scored/proquest/discovery_session_20261023_extended')
            if digest(path)!=expected:raise ValueError('Canonical input changed: '+name)
        for name,value in completion['library_versions'].items():
            if versions()[name]!=value:raise ValueError('Canonical estimator library changed: '+name)
        paths.append(OUT/'models_boundary_corrected'/algorithm/'predictions_without_truth.csv')
    target_receipt=json.loads((OUT/'audits/model_input_manifest.json').read_text())
    for name,expected in target_receipt['target_archive_hashes'].items():
        if digest(ROOT/name)!=expected:raise ValueError('Historical target archive changed')
    if not FREEZE.exists():
        save_json(FREEZE,dict(created_utc=dt.datetime.now(dt.timezone.utc),
            session_root_relative=str(OUT.relative_to(ROOT)),validator_sha256=digest(__file__),
            library_versions=versions(),input_hashes={str(p.relative_to(ROOT)):digest(p) for p in paths},
            provenance='Additional dependency snapshot recorded after comparison with the earlier saved full feature matrix and all canonical assessment truths. It is not misrepresented as a pre-analysis hash of these derived files.'))
    verify_frozen_inputs()
    result=dict(status='passed',updated_utc=dt.datetime.now(dt.timezone.utc),
        feature_cells_compared=left.size,maximum_feature_absolute_error=feature_error,
        canonical_truth_values_compared=comparisons,maximum_truth_absolute_error=truth_error,
        dependency_hashes=len(json.loads(FREEZE.read_text())['input_hashes']),
        code_sha256=digest(__file__),source_check=check_sources())
    save_json(OUT/'audits/saved_model_inputs_validation.json',result)
    journal('validation','Verified current features and truth against frozen model snapshots; bound additional derived dependencies',
        feature_cells=left.size,truth_values=comparisons,maximum_feature_error=feature_error,
        maximum_truth_error=truth_error)
    print(json.dumps(result,indent=2,default=json_default))


if __name__=='__main__':run()
