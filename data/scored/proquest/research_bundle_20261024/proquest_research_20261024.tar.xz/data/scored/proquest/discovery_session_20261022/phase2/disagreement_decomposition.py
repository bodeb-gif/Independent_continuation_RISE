"""Exact variance accounting for directional disagreement, without new p-values."""
from vintage_data import *
from common import SEED


def claims(source_set):
    if source_set=='verified':path=BASE/'descriptive/scored_claims.csv.gz'
    else:path=BASE/'robustness/scored_claims.csv.gz'
    f=pd.read_csv(path,dtype={'page_id':str})
    if source_set=='raw':f=f[f.source_set.eq('raw')]
    f=f[f.scope.eq('national') & f.topic.isin(['general_business','markets','prices','employment'])].copy()
    f['x']=f.predicted_norm.map({'improve':1.,'up':1.,'worsen':-1.,'down':-1.,'flat':0.})
    emp=f.topic.eq('employment');f.loc[emp,'x']=f.loc[emp,'predicted_norm'].map({'down':1.,'up':-1.,'flat':0.})
    f=f[f.x.notna()].copy();f['month']=pd.PeriodIndex(pd.to_datetime(f.date),freq='M')
    keys=['month','topic'];article=keys+['paper','page_id'];paper=keys+['paper']
    n_claims=f.groupby(article).record_id.transform('size')
    n_articles=f.groupby(paper).page_id.transform('nunique')
    n_papers=f.groupby(keys).paper.transform('nunique')
    total_articles=f.groupby(keys).page_id.transform('nunique')
    f['mass']=1/(n_claims*n_articles*n_papers)
    f['n_papers']=n_papers;f['n_articles']=total_articles
    f=f[(n_papers>=2)&(total_articles>=5)].copy()
    f['wx']=f.mass*f.x;f['wx2']=f.mass*f.x*f.x
    f['horizon_category']=f.horizon_basis.fillna('unresolved').astype(str)+':'+f.horizon_used.map(lambda x:str(int(x)) if pd.notna(x) else 'unresolved')
    for col in ['voice','confidence']:f[col]=f[col].fillna('unknown')
    return f


def decompose(f,source_set):
    keys=['month','topic']
    total=f.groupby(keys).agg(weight=('mass','sum'),mean=('wx','sum'),second=('wx2','sum'),
                              n_claims=('record_id','size'),n_articles=('n_articles','first'),n_papers=('n_papers','first'))
    assert np.allclose(total.weight,1)
    total['variance']=total.second-total['mean']**2
    if (total.variance < -1e-10).any():raise ValueError('Negative total variance')
    rows=[]
    for attribute,col in [('newspaper','paper'),('article','page_id'),('horizon','horizon_category'),('voice','voice'),('confidence','confidence')]:
        group=f.groupby(keys+[col]).agg(w=('mass','sum'),wx=('wx','sum'))
        group['term']=group.wx**2/group.w
        between=group.term.groupby(level=keys).sum()-total['mean']**2
        within=total.variance-between
        if (between < -1e-10).any() or (within < -1e-10).any():raise ValueError('Variance identity failed')
        d=total.copy();d['between']=between.clip(lower=0);d['within']=within.clip(lower=0)
        d['attribute']=attribute;d['source_set']=source_set
        d['between_fraction']=(d.between/d.variance).where(d.variance>1e-12)
        assert np.allclose(d.between+d.within,d.variance)
        rows.append(d.reset_index())
    result=pd.concat(rows,ignore_index=True)
    if source_set=='verified':
        old=pd.read_csv(SESSION/'monthly_information/national_topic_month.csv.gz') if (SESSION/'monthly_information/national_topic_month.csv.gz').exists() else pd.read_csv(BASE/'monthly_information/national_topic_month.csv.gz')
        old['month']=pd.PeriodIndex(old.month,freq='M')
        check=result[result.attribute.eq('newspaper')].merge(old[['month','topic','net_direction','paper_dispersion']],on=keys,validate='one_to_one')
        assert np.allclose(check['mean'],check.net_direction)
        assert np.allclose(check.between,check.paper_dispersion**2,atol=1e-12)
    return result


def bootstrap_ratio(g,span=5,draws=5000):
    block=(g.month.dt.year-1900)//span
    tab=g.groupby(block)[['between','variance']].sum()
    rng=np.random.default_rng(SEED+span)
    indices=rng.integers(0,len(tab),(draws,len(tab)))
    sums=tab.to_numpy()[indices].sum(axis=1)
    ratios=sums[:,0]/sums[:,1]
    low,high=np.quantile(ratios,[.025,.975])
    return dict(between_fraction=g.between.sum()/g.variance.sum(),low=low,high=high,n_blocks=len(tab),
                mean_monthly_fraction=g.between_fraction.mean(),n_months=len(g),
                total_variance_mean=g.variance.mean(),within_fraction=1-g.between.sum()/g.variance.sum())


def main():
    tables=[]
    for source in ['verified','raw']:
        print('Decomposing',source,flush=True);tables.append(decompose(claims(source),source))
    result=pd.concat(tables,ignore_index=True)
    common=result.groupby(['month','topic','attribute']).source_set.transform('nunique').eq(2)
    result['common_month']=common
    result.to_csv(OUT/'directional_variance_monthly.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    summaries=[];decades=[]
    for cohort,frame in [('own_support',result),('common_months',result[result.common_month])]:
        for (source,topic,attribute),g in frame.groupby(['source_set','topic','attribute']):
            for span in [2,5,10]:
                summaries.append(dict(cohort=cohort,source_set=source,topic=topic,attribute=attribute,block_years=span,**bootstrap_ratio(g,span)))
            for decade,d in g.groupby(g.month.dt.year//10*10):
                decades.append(dict(cohort=cohort,source_set=source,topic=topic,attribute=attribute,decade=int(decade),
                                    n_months=len(d),between_fraction=d.between.sum()/d.variance.sum(),within_fraction=1-d.between.sum()/d.variance.sum()))
    pd.DataFrame(summaries).to_csv(OUT/'directional_variance_summary.csv',index=False)
    pd.DataFrame(decades).to_csv(OUT/'directional_variance_decades.csv',index=False)
    manifest=dict(status='Descriptive variance identities, no causal attribution or new p-values',
                  source_hashes={str(p.relative_to(ROOT)):digest(p) for p in [BASE/'descriptive/scored_claims.csv.gz',BASE/'robustness/scored_claims.csv.gz',Path(__file__),OUT/'disagreement_specification.json']},
                  identities='All between+within components exactly reproduce directional variance; verified between-paper equals saved paper-dispersion squared')
    (OUT/'directional_variance_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(pd.DataFrame(summaries).query('cohort=="own_support" and block_years==5')[['source_set','topic','attribute','between_fraction','low','high','n_months']].to_string(index=False))


if __name__=='__main__':main()
