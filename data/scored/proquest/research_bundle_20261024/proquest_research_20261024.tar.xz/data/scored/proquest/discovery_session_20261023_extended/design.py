"""Freeze exploratory questions before their results are computed."""
from pathlib import Path
import json

OUT = Path(__file__).resolve().parent
TOPICS = ['general_business', 'employment', 'markets', 'prices']
STRUCTURES = ['revision_common', 'negative_breadth', 'term_slope',
              'confidence_gap', 'voice_gap', 'within_paper_variance',
              'between_paper_variance', 'cross_topic_gap']
SPEC = {
    'scope': 'Only annual ProQuest verified 1900–2010; annual raw sensitivity. No modern/LOC/crisis-window pooling.',
    'status': 'Exploratory extension. Historical outcomes and earlier repository studies have been inspected. This is not a fresh holdout or a preregistration of the project.',
    'prior_family': 68,
    'structural_family': {
        'n_tests': 32,
        'topics': TOPICS, 'features': STRUCTURES,
        'question': 'Does the specified forecast structure associate with its own subsequent six-month economic outcome after holding the aggregate direction level fixed?',
        'targets': {'general_business': 'Six-month log industrial-production change',
                    'employment': 'Minus six-month unemployment-rate change, in percentage points',
                    'markets': 'Six-month log Shiller nominal stock-price change, no dividends',
                    'prices': 'Six-month log CPI change, rising prices are not called good news'},
        'controls': 'Own net direction, net direction squared, neutral share, log article coverage, paper coverage, decade effects. Market-price past return/volatility also for stock outcome. Macro-controlled and tone-controlled regressions are sensitivities, not substitutes for this target.',
        'sample': 'All outcome-covered origins through 2010; business begins 1919 and excludes early NBER proxies. Require feature and control support; no outcome-based sample selection.',
        'effect_unit': 'One full-analysis-sample SD of the tested feature, for description only; model scaling is strictly training-only.',
        'inference': 'Five-year calendar clusters anchored 1900, conservative maximum of cluster-t and restricted wild-cluster p where computationally feasible; two- and ten-year clusters, era/crisis/source checks retained. Pointwise 95% intervals are not simultaneous intervals.',
    },
    'monthly_ml_family': {
        'n_tests': 32,
        'tasks': ['production_continuous', 'unemployment_continuous', 'production_downturn', 'unemployment_downturn'],
        'algorithms': ['linear', 'hist_gradient_boosting', 'extra_trees', 'gru'],
        'feature_arms': ['macro_coverage', 'macro_coverage_net', 'macro_coverage_net_structure'],
        'comparisons': ['net_minus_macro_coverage', 'structure_minus_net'],
        'evaluation': '408 common monthly origins 1977–2010, annual January refits. No random-month or random-claim splits.',
        'targets': 'Continuous six-month log IP growth or unemployment improvement. Binary production decline below -2 log percent and unemployment improvement below -0.5pp. These thresholds remain fixed.',
        'training_labels': 'IP from latest native historical vintage strictly before each refit; unemployment from exact prior-day ALFRED snapshots. Require endpoint+3 months strictly before refit. Final frozen truth is assessment-only.',
        'features': 'Eight audited vintage macro fields, fresh monthly unemployment; all arms include the same 4-topic export-coverage variables. Net adds prior-three-month net direction of each topic; structure adds all 8 specified structures per topic. Prior complete print months only, never verifier prose, outcomes, retrospective states, or quote-derived fields without independent print-time provenance.',
        'selection': 'Nested expanding forward validation, never outer evaluation truth. Inner origins outer-6, outer-4, outer-2 January, each followed by at most 24 mature validation months. Inner fits use inner-origin label vintages; selection truth uses available outer-origin vintage. Require at least 120 training observations; fallback settings recorded if support insufficient. All outer arms share train/evaluation dates.',
        'preprocessing': 'Fit median imputation/scaling only to eligible training rows; append missingness flags. Fixed chronological sequences for neural models, no bidirectional recurrence. All declared seeds averaged, none selected by outer performance.',
        'primary_loss': 'MSE for continuous; Brier for binary. Log loss, MAE, ranking, accuracy, calibration and subgroup tables are descriptive.',
        'inference': 'Paired monthly loss gains aggregated into five-year clusters anchored 1977. Retain exact/restricted-wild and cluster-t inference, 2/10-year and crisis/era sensitivities. Inference conditional on fitted predictions; refit bootstrap planned as robustness, not an extra discovery.',
    },
    'multiplicity': 'Retain all 64 new tests, unestimable tests p=1. Holm and BH over this round and pooled with all prior 68 (132 minimum total). Subsequent question batches are appended, never reset after inspecting outcomes. Robustness choices cannot rescue a failed primary test.',
    'measurement': 'Machine labels are provisional. Human review cannot be supplied by model self-review. No label error is erased by temporal inference.',
    'novelty': 'Statistical significance is insufficient for novelty. Compare surviving claims to primary literature before describing a distinctive contribution.',
    'time': 'Continue research until at least 2026-10-24 13:17:21 UTC. Log tool stalls separately and skip dependencies requiring user input.',
}

if __name__ == '__main__':
    path = OUT / 'specs/initial_design.json'
    if path.exists():
        raise FileExistsError('Initial specification is immutable: '+str(path))
    path.write_text(json.dumps(SPEC, indent=2)+'\n')
    print(path)
