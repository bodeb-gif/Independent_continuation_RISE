"""Matched relative forecast accuracy under uncertainty and polarization."""
from associations import *

SPEC=json.loads((OUT/'specs/conditional_credibility.json').read_text())
CONDITIONS=SPEC['conditions']

def condition_panel():
    workbook=PRIOR/'reference/US_Policy_Uncertainty_Data.xlsx'
    receipt=json.loads((PRIOR/'primary_manifest.json').read_text())['inputs_sha256']
    if digest(workbook)!=receipt[str(workbook.relative_to(ROOT))]:raise ValueError('EPU source changed')
    d=pd.read_excel(workbook,sheet_name='Main News Index')
    d=d.apply(pd.to_numeric,errors='coerce').dropna()
    dates=pd.PeriodIndex([f'{int(y)}-{int(m):02}' for y,m in zip(d.Year,d.Month)],freq='M')
    s=pd.Series(d.News_Based_Policy_Uncert_Index.to_numpy(float),index=dates).sort_index()
    if not s.index.is_unique or not (s>0).all():raise ValueError('EPU index invalid')
    origins=pd.period_range('1900-01','2010-12',freq='M')
    rows=[]
    for origin in origins:
        x=s.reindex(pd.period_range(origin-4,origin-2,freq='M'))
        rows.append(dict(month=origin,prior_log_epu=np.log(x).mean() if x.notna().sum()>=2 else np.nan,
            epu_latest_observation=origin-2,epu_observed_months=int(x.notna().sum())))
    result=pd.DataFrame(rows)
    pol=pd.read_csv(BASE/'polarization/features.csv')
    pol['month']=pd.PeriodIndex(pol.origin,freq='M')
    if not (pd.to_datetime(pol.political_latest_vote)<pol.month.dt.to_timestamp()).all():
        raise ValueError('Future rollcall')
    pol=pol.rename(columns={'political_polarization':'prior_rollcall_polarization'})
    result=result.merge(pol[['month','prior_rollcall_polarization','political_latest_vote']],on='month',validate='one_to_one')
    result.to_csv(OUT/'cache/credibility_conditions.csv',index=False)
    return result

def matched_cells(source,contrast,conditions):
    c=pd.read_csv(OUT/'cache'/f'print_claims_{source}.csv.gz',dtype={'page_id':str})
    c['month']=pd.PeriodIndex(c.month,freq='M')
    scorepath=BASE/('descriptive/scored_claims.csv.gz' if source=='verified' else 'robustness/scored_claims.csv.gz')
    scores=pd.read_csv(scorepath,usecols=['record_id','hit','basis']+(['source_set'] if source=='raw' else []))
    if source=='raw':scores=scores[scores.source_set.eq('raw')]
    scores['key']=scores.record_id.astype(str).str.replace(r'^(?:verified|raw):','',regex=True)
    c['key']=c.record_id.str.replace(r'^(?:verified|raw):','',regex=True)
    c=c.merge(scores[['key','hit','basis']],on='key',validate='one_to_one')
    c=c[c.hit.notna()&c.basis.ne('NBER proxy')&c.horizon_used.between(1,24)].copy()
    if contrast=='assertive_minus_hedged':field,left,right,extra='confidence','assertive','hedged','voice'
    elif contrast=='expert_minus_journalist':field,left,right,extra='voice','expert','journalist','confidence'
    else:raise ValueError(contrast)
    keys=['paper','month','topic','basis','horizon_used','horizon_basis',extra]
    c=c[c[field].isin([left,right])]
    a=c.groupby(keys+[field,'page_id'],observed=True).hit.mean().reset_index()
    means=a.groupby(keys+[field],observed=True).hit.agg(['mean','size'])
    v=means['mean'].unstack(field).reindex(columns=[left,right])
    n=means['size'].unstack(field).reindex(columns=[left,right])
    use=n.ge(2).all(axis=1)&v.notna().all(axis=1);v=v[use];n=n[use]
    result=(v[left]-v[right]).rename('difference').to_frame()
    result['weight']=2*n[left]*n[right]/(n[left]+n[right])
    result['left_hit']=v[left];result['right_hit']=v[right]
    result['left_articles']=n[left];result['right_articles']=n[right]
    result=result.reset_index();result['year']=result.month.dt.year
    result['calendar_month']=result.month.dt.month
    return result.merge(conditions,on='month',validate='many_to_one'),extra

def estimate_cells(frame,condition,extra,span=5,wild=True,year_effects=False):
    d=frame.replace([np.inf,-np.inf],np.nan).dropna(subset=['difference','weight']+CONDITIONS).copy()
    groups=(d.year.to_numpy()-1900)//span;g=len(np.unique(groups))
    if len(d)<60 or g<6 or d[condition].std()<=1e-10:
        return dict(effect=np.nan,p_value=1.,n=len(d),n_blocks=g,status='insufficient_support'),None,d
    center=d[condition].mean();scale=d[condition].std()
    x=((d[[condition]]-center)/scale).rename(columns={condition:'tested_predictor'})
    other=next(c for c in CONDITIONS if c!=condition)
    x[other]=(d[other]-d[other].mean())/d[other].std()
    for column in ['paper','calendar_month','horizon_used','horizon_basis',extra]:
        x=pd.concat([x,pd.get_dummies(d[column],prefix=column,drop_first=True,dtype=float)],axis=1)
    fixed=d.year if year_effects else d.year//10*10
    x=pd.concat([x,pd.get_dummies(fixed,prefix='year' if year_effects else 'decade',drop_first=True,dtype=float)],axis=1)
    x=sm.add_constant(x,has_constant='add');kept=[];rank=0
    for col in x:
        new=np.linalg.matrix_rank(x[kept+[col]].to_numpy(float))
        if new>rank:kept.append(col);rank=new
    x=x[kept]
    if len(d)<2*x.shape[1] or 'tested_predictor' not in x:
        return dict(effect=np.nan,p_value=1.,n=len(d),n_blocks=g,status='insufficient_rank_support'),None,d
    w=d.weight.to_numpy(float);w=w/w.mean();y=d.difference.to_numpy(float)
    fit=sm.WLS(y,x,weights=w).fit(cov_type='cluster',cov_kwds={'groups':groups,
        'use_correction':True,'df_correction':True},use_t=True)
    lo,hi=fit.conf_int().loc['tested_predictor']
    row=dict(effect=fit.params['tested_predictor'],se=fit.bse['tested_predictor'],low=lo,high=hi,
        p_value=fit.pvalues['tested_predictor'],p_cluster_t=fit.pvalues['tested_predictor'],
        n=len(d),n_blocks=g,status='estimated',feature_mean=center,feature_sd=scale,
        controls=';'.join(x.columns),first_month=d.month.min(),last_month=d.month.max())
    if wild:
        root=np.sqrt(w);info=restricted_wild(x.to_numpy(float)*root[:,None],y*root,groups,list(x).index('tested_predictor'))
        np.testing.assert_allclose(info['wild_se'],row['se'],rtol=1e-7,atol=1e-9)
        row.update(info);row['p_value']=max(row['p_cluster_t'],row['p_wild_conservative'])
    return row,fit,d

def run():
    check_sources();conditions=condition_panel();rows=[];sensitivity=[];samples=[];inputs={}
    for source in ['verified','raw']:
        for contrast in SPEC['contrasts']:
            cells,extra=matched_cells(source,contrast,conditions)
            cells.to_csv(OUT/'cache'/f'credibility_cells_{source}_{contrast}.csv.gz',index=False,
                compression={'method':'gzip','mtime':0})
            for topic in SPEC['topics']:
                d=cells[cells.topic.eq(topic)].copy()
                for condition in CONDITIONS:
                    test=f'credibility_{topic}_{contrast}_{condition}'
                    r,fit,used=estimate_cells(d,condition,extra)
                    row=dict(test=test,batch='conditional_credibility',topic=topic,contrast=contrast,
                        condition=condition,block_years=5,**r)
                    if source=='verified':rows.append(row);samples.append(used.assign(test=test))
                    else:sensitivity.append(dict(variant='raw',**row))
                    if source=='verified' and fit is not None:
                        for label,sub,span,annual in [('blocks_2',d,2,False),('blocks_10',d,10,False),
                            ('year_effects',d,5,True),('stated_horizons',d[d.horizon_basis.eq('stated')],5,False),
                            ('exclude_2007_2009',d[~d.year.between(2007,2009)],5,False),
                            ('exclude_1929_1939',d[~d.year.between(1929,1939)],5,False)]:
                            rr,_,_=estimate_cells(sub,condition,extra,span=span,wild=False,year_effects=annual)
                            sensitivity.append(dict(test=test,variant=label,**rr))
                    print(source,test,r['effect'],r['p_value'],r['n'],flush=True)
                    pd.DataFrame(rows).to_csv(OUT/'conditional_credibility_tests_partial.csv',index=False)
    result=adjust(pd.DataFrame(rows),132);assert len(result)==16
    result.to_csv(OUT/'conditional_credibility_tests.csv',index=False)
    pd.DataFrame(sensitivity).to_csv(OUT/'conditional_credibility_sensitivities.csv',index=False)
    pd.concat(samples,ignore_index=True).to_csv(OUT/'audits/conditional_credibility_analysis_rows.csv.gz',index=False,
        compression={'method':'gzip','mtime':0})
    paths=[Path(__file__),OUT/'specs/conditional_credibility.json',PRIOR/'reference/US_Policy_Uncertainty_Data.xlsx',BASE/'polarization/features.csv']
    save_json(OUT/'audits/conditional_credibility_manifest.json',dict(status='complete',n_tests=16,
        input_hashes={str(p.relative_to(ROOT)):digest(p) for p in paths},source_count=check_sources(),
        interpretation=SPEC['interpretation']))
    journal('conditional_credibility','Completed all16 matched accuracy-by-condition questions')
    print(result.sort_values('p_value')[['test','effect','low','high','p_value','holm_p','n','n_blocks']].to_string(index=False))

if __name__=='__main__':run()
