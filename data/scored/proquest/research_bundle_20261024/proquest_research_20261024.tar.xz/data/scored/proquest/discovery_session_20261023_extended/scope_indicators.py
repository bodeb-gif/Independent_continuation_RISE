"""Separate nonnational outlook indexes as predictors of national outcomes."""
from associations import *
from analyze_proquest import annual_files
from proquest_panel import sign_label,build_panels
from proquest_descriptive import paper_name

SPEC=json.loads((OUT/'specs/scope_indicators.json').read_text())

def read_scopes(source):
    rows=[]
    for path in annual_files(ROOT/f'data/proquest/{source}'):
        for number,line in enumerate(path.read_text().splitlines(),1):
            if not line.strip():continue
            d=json.loads(line)
            if d.get('no_predictions') or d.get('scope') not in ['industry','regional','foreign']:continue
            if d.get('topic') not in TOPICS:continue
            if d.get('source')!='proquest' or d.get('schema_version')!=2:raise ValueError('Wrong annual source')
            if source=='verified' and 'verify_reason' not in d:raise ValueError('Unverified source')
            sign=sign_label(d)
            if sign not in ['positive','negative','flat']:continue
            date=pd.Timestamp(d['date'])
            rows.append(dict(page_id=str(d['page_id']),date=str(date.date()),month=date.to_period('M'),
                paper=paper_name(d.get('publisher') or d.get('newspaper_title')),
                topic=d['topic'],scope=d['scope'],sign=sign))
    return pd.DataFrame(rows)

def signals(claims):
    _,_,national=build_panels(claims);rows=[]
    for topic in TOPICS:
        m=national[national.topic.eq(topic)].set_index('month')
        for origin in pd.period_range('1900-01','2010-12',freq='M'):
            w=m.reindex(pd.period_range(origin-3,origin-1,freq='M'))
            enough=(w.n_articles>0).sum()>=2 and w.n_papers.max()>=2 and w.n_articles.sum()>=5
            rows.append(dict(origin=origin,topic=topic,scope_net=w.net_direction.mean() if enough else np.nan,
                scope_flat=w.flat_share.mean() if enough else np.nan,
                scope_log_articles=np.log1p(w.n_articles.sum()),scope_papers=w.n_papers.mean()))
    return pd.DataFrame(rows)

def run():
    check_sources();rows=[];sensitivity=[];samples=[];supports=[]
    for source in ['verified','raw']:
        claims=read_scopes(source)
        claims.to_csv(OUT/'cache'/f'print_claims_nonnational_{source}.csv.gz',index=False,
            compression={'method':'gzip','mtime':0})
        national=pd.read_csv(OUT/'cache'/f'features_{source}.csv.gz');national['origin']=pd.PeriodIndex(national.origin,freq='M')
        n=national.pivot(index='origin',columns='topic',values=['net_direction','flat_share','log_articles','n_papers'])
        n.columns=[f'national_{t}_{c}' for c,t in n.columns];n=n.reset_index()
        truth=pd.read_csv(PRIOR/'continuous_targets.csv');truth['origin']=pd.PeriodIndex(truth.origin,freq='M')
        macro=pd.read_csv(PRIOR/'phase2/fresh_core_forecast_features.csv');macro['origin']=pd.PeriodIndex(macro.origin,freq='M')
        from proquest_vintages import CORE_FEATURES
        panels={}
        for scope in ['industry','regional','foreign']:
            sub=claims[claims.scope.eq(scope)]
            if not len(sub):continue
            f=signals(sub);panels[scope]=f
            f.to_csv(OUT/'cache'/f'scope_signals_{scope}_{source}.csv.gz',index=False,
                compression={'method':'gzip','mtime':0})
            for topic,g in sub.groupby('topic'):
                supports.append(dict(source_set=source,scope=scope,topic=topic,n_claims=len(g),
                    n_articles=g.page_id.nunique(),qualifying_origins=int(f[f.topic.eq(topic)].scope_net.notna().sum())))
        for question in SPEC['questions']:
            scope=question['scope'];topic=question['topic'];outcome=question['outcome']
            name=f'scope_{scope}_{topic}_{outcome}'
            if scope not in panels:
                row=dict(test=name,batch='scope_indicators',scope=scope,topic=topic,outcome=outcome,
                    effect=np.nan,p_value=1.,n=0,n_blocks=0,status='no_source_support')
            else:
                d=panels[scope][panels[scope].topic.eq(topic)].merge(n,on='origin',validate='one_to_one')
                d=d.merge(truth,on='origin',validate='one_to_one')
                d=d.merge(macro[['origin']+list(CORE_FEATURES)],on='origin',how='left',validate='one_to_one')
                controls=['scope_flat','scope_log_articles','scope_papers']
                for nt in question['national_controls']:
                    level=f'national_{nt}_net_direction';d[level+'_squared']=d[level]**2
                    controls += [level,level+'_squared',f'national_{nt}_flat_share',
                        f'national_{nt}_log_articles',f'national_{nt}_n_papers']
                if outcome=='general_business_growth':d=d[d.origin>=pd.Period('1919-02','M')]
                r,fit,used=estimate(d,'scope_net',outcome,controls,wild=True)
                row=dict(test=name,batch='scope_indicators',scope=scope,topic=topic,outcome=outcome,block_years=5,**r)
                if source=='verified':
                    samples.append(used.assign(test=name))
                    for span in [2,10]:
                        rr,_,_=estimate(d,'scope_net',outcome,controls,span=span,wild=True)
                        sensitivity.append(dict(test=name,variant=f'blocks_{span}',**rr))
                    for variant,mask in [('exclude_2007_2009',~d.year.between(2007,2009)),
                        ('pre_1980',d.year<1980),('1980_onward',d.year>=1980)]:
                        rr,_,_=estimate(d[mask],'scope_net',outcome,controls,wild=False)
                        sensitivity.append(dict(test=name,variant=variant,**rr))
                    rr,_,_=estimate(d,'scope_net',outcome,controls+list(CORE_FEATURES),wild=True)
                    sensitivity.append(dict(test=name,variant='vintage_macro_controls',**rr))
            if source=='verified':rows.append(row)
            else:sensitivity.append(dict(variant='raw',**row))
            print(source,name,row['effect'],row['p_value'],row['n'],flush=True)
    result=adjust(pd.DataFrame(rows),100);assert len(result)==6
    result.to_csv(OUT/'scope_tests.csv',index=False)
    pd.DataFrame(sensitivity).to_csv(OUT/'scope_sensitivities.csv',index=False)
    pd.DataFrame(supports).to_csv(OUT/'audits/scope_feature_support.csv',index=False)
    pd.concat(samples,ignore_index=True).to_csv(OUT/'audits/scope_analysis_rows.csv.gz',index=False,
        compression={'method':'gzip','mtime':0})
    save_json(OUT/'audits/scope_manifest.json',dict(status='complete',n_tests=6,code_sha256=digest(__file__),
        source_count=check_sources(),interpretation='Separate nonnational outlook indicators; no claim-level national accuracy or representative coverage.'))
    journal('scope_indicators','Completed six industry/regional/foreign indicator questions')
    print(result.sort_values('p_value')[['test','effect','low','high','p_value','holm_p','n','n_blocks']].to_string(index=False))

if __name__=='__main__':run()
