"""Separate sample changes, feature units and additional control attenuation."""
from cross_topic_audit import wide_features
from survey_controls import survey_panel
from associations import *
from proquest_vintages import CORE_FEATURES

def run():
    d=wide_features('verified')
    tone=pd.read_csv(PRIOR/'external_tone_monthly.csv');tone.columns=['month','sentiment']
    tone.month=pd.PeriodIndex(tone.month,freq='M');s=tone.set_index('month').sentiment
    def earlier(origin):
        values=s.reindex(pd.period_range(origin-3,origin-1,freq='M'))
        return values.mean() if values.notna().all() else np.nan
    d['prior_tone']=d.origin.map(earlier)
    d=d.merge(survey_panel(),on='origin',validate='one_to_one')
    base=['net_direction','net_squared','flat_share','log_articles','n_papers']
    macro=list(CORE_FEATURES);survey=['ICC','ICE','ICC_change_6m','ICE_change_6m','ICC_age','ICE_age']
    original,_,used=estimate(d,'cross_topic_gap','employment_growth',base,wild=False)
    sigma=original['feature_sd'];other_sd=json.loads((OUT/'audits/economic_scale.json').read_text())['other_direction_sd']
    # Base sample already has all required primary fields and deterministic Y.
    common=d[d.origin.isin(used.origin)].copy();rows=[];samples=[]
    variants=[('full_primary','base',common,base)]
    for name,fields,models in [
        ('macro',macro,[('base',base),('macro',base+macro)]),
        ('tone_and_macro',['prior_tone']+macro,[('base',base),('macro',base+macro),
            ('tone',base+['prior_tone']),('tone_and_macro',base+['prior_tone']+macro)]),
        ('survey',survey,[('base',base),('survey',base+survey)]),
        ('survey_and_macro',survey+macro,[('base',base),('macro',base+macro),
            ('survey',base+survey),('survey_and_macro',base+survey+macro)])]:
        supported=common.dropna(subset=fields)
        for model,columns in models:variants.append((name,model,supported,columns))
    for population,model,frame,columns in variants:
        r,fit,used=estimate(frame,'cross_topic_gap','employment_growth',columns,wild=True)
        row=dict(population=population,model=model,**r)
        if r['status']=='estimated':
            for field in ['effect','low','high']:
                row[field+'_per_primary_gap_sd']=r[field]/r['feature_sd']*sigma
            row['effect_per_primary_other_sd']=-r['effect']/r['feature_sd']*other_sd
            row['low_per_primary_other_sd']=-r['high']/r['feature_sd']*other_sd
            row['high_per_primary_other_sd']=-r['low']/r['feature_sd']*other_sd
        rows.append(row);samples.append(used.assign(population=population,model=model))
        print(population,model,row.get('effect_per_primary_other_sd'),r['p_value'],r['n'],flush=True)
    result=pd.DataFrame(rows);result.to_csv(OUT/'common_sample_controls.csv',index=False)
    for population,g in result.groupby('population'):
        if g.n.nunique()!=1:raise ValueError('Unequal control-comparison sample '+population)
    pd.concat(samples,ignore_index=True).to_csv(OUT/'audits/common_sample_control_rows.csv.gz',index=False,
        compression={'method':'gzip','mtime':0})
    save_json(OUT/'audits/common_sample_controls.json',dict(status='complete',
        role='Common-sample interpretation of already-inspected control robustness. No new hypothesis, replacement primary result or independent discovery.',
        primary_gap_sd=sigma,primary_other_index_sd=other_sd,
        limits='Tone and survey series are retrospective historical descriptors, not established real-time feature vintages. Conditional associations are not causal identification.',
        code_sha256=digest(__file__),source_check=check_sources()))
    journal('common_sample_controls','Separated support shifts and additional controls in common effect units')

if __name__=='__main__':run()
