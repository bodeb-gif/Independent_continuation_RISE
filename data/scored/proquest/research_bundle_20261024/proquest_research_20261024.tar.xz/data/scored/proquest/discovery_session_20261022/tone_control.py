"""Does the printed-claim signal differ from existing broad news sentiment?"""
from common import *
from proquest_vintages import CORE_FEATURES


def main():
    raw=pd.read_excel(OUT/'reference/news_sentiment_data.xlsx',sheet_name='Data')
    raw['date']=pd.to_datetime(raw.date)
    raw=raw[raw.date.dt.year.between(1980,2010)].copy()
    raw['month']=raw.date.dt.to_period('M')
    tone=raw.groupby('month')['News Sentiment'].mean()
    assert tone.index.is_unique
    signal=pd.read_csv(OUT/'lagged_topic_signals.csv');signal['origin']=pd.PeriodIndex(signal.origin,freq='M')
    truth=pd.read_csv(OUT/'continuous_targets.csv');truth['origin']=pd.PeriodIndex(truth.origin,freq='M')
    macro=pd.read_csv(BASE/'macro_information/macro_feature_audit.csv');macro['origin']=pd.PeriodIndex(macro.origin,freq='M')
    rows=[];sensitivity=[];samples=[]
    for topic,outcome in [('employment','employment_growth'),('general_business','general_business_growth')]:
        d=signal[signal.topic.eq(topic)].copy()
        d['tested_predictor']=(d.net_direction-d.net_direction.mean())/d.net_direction.std()
        def earlier_tone(origin):
            window=tone.reindex(pd.period_range(origin-3,origin-1,freq='M'))
            return window.mean() if window.notna().all() else np.nan
        d['prior_tone']=d.origin.map(earlier_tone)
        d['log_articles']=np.log1p(d.articles)
        d=d.merge(truth[['origin',outcome]],on='origin',validate='one_to_one').merge(macro[['origin']+list(CORE_FEATURES)],on='origin',validate='one_to_one')
        controls=['prior_tone','log_articles','papers','flat_share']+list(CORE_FEATURES)
        for span in [2,5,10]:
            rr,fit,used=regression(d,outcome,['tested_predictor'],controls,span)
            row=dict(test=f'{topic}_net_controlling_broad_tone',batch='tone_control',block_years=span,**rr[0])
            if span==5:
                rows.append(row);samples.append(used.assign(topic=topic))
            else:sensitivity.append(row)
    result=adjust(pd.DataFrame(rows),2);result.to_csv(OUT/'tone_control_tests.csv',index=False)
    pd.DataFrame(sensitivity).to_csv(OUT/'tone_control_sensitivities.csv',index=False)
    pd.concat(samples).to_csv(OUT/'tone_control_analysis_data.csv',index=False)
    tone.rename('sentiment').to_csv(OUT/'external_tone_monthly.csv')
    session=adjust(pd.concat([pd.read_csv(OUT/'session_wide_52_tests.csv'),result],ignore_index=True),54)
    session.to_csv(OUT/'session_wide_54_tests.csv',index=False)
    print(result.to_string(index=False))
    print(session[session.holm_p<.05][['test','effect','holm_p']].to_string(index=False))
    write_json('tone_control_manifest.json',dict(input_sha256=digest(OUT/'reference/news_sentiment_data.xlsx'),
               index_source='https://www.frbsf.org/research-and-insights/data-and-indicators/daily-news-sentiment-index/',
               input_role='retrospective association covariate only',first_month=str(tone.index.min()),last_month=str(tone.index.max())))


if __name__=='__main__':main()
