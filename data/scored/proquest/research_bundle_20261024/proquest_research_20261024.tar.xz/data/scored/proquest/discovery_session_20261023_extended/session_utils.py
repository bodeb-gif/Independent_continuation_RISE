"""Provenance, progress, and dependence-aware inference for the extension."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import sys
import numpy as np
import pandas as pd
import scipy.stats as st
from statsmodels.stats.multitest import multipletests

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
BASE = ROOT/'data/scored/proquest'
PRIOR = BASE/'discovery_session_20261022'
sys.path.insert(0, str(ROOT/'src'))
SEED = 20261023
TOPICS = ['general_business', 'employment', 'markets', 'prices']

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def json_default(x):
    if isinstance(x, np.ndarray): return x.tolist()
    if isinstance(x, (np.integer, np.floating, np.bool_)): return x.item()
    if isinstance(x, (pd.Timestamp, pd.Period, Path, dt.datetime)): return str(x)
    raise TypeError(type(x))

def save_json(path, obj):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name+'.tmp')
    temp.write_text(json.dumps(obj, indent=2, default=json_default)+'\n')
    temp.replace(path)

def journal(phase, event, **details):
    item = dict(utc=dt.datetime.now(dt.timezone.utc).isoformat(), phase=phase,
                event=event, **details)
    with (OUT/'progress.jsonl').open('a') as f:
        f.write(json.dumps(item, default=json_default)+'\n')

def adjust(frame, n=None):
    frame = frame.copy(); size = max(len(frame), n or 0)
    values = list(frame.p_value.fillna(1).clip(0,1)) + [1.]*(size-len(frame))
    frame['holm_p'] = multipletests(values, method='holm')[1][:len(frame)]
    frame['bh_q'] = multipletests(values, method='fdr_bh')[1][:len(frame)]
    return frame

def mean_inference(values, years, span=5, anchor=1977, wild_draws=99999):
    """Equal-month mean, calendar-cluster sandwich and restricted wild t test.

    The null model is an intercept constrained to zero. Every wild sample
    recomputes its intercept and cluster sandwich; enumerate when <=18 blocks.
    This does not provide unconditional model-selection or semantic inference.
    """
    y = np.asarray(values, float); years = np.asarray(years, int)
    ok = np.isfinite(y); y = y[ok]; years = years[ok]
    if not len(y): return dict(effect=np.nan,p_value=1.,n=0,n_blocks=0,status='empty')
    codes, inv = np.unique((years-anchor)//span, return_inverse=True)
    g = len(codes); n = len(y); effect = y.mean()
    if g < 3: return dict(effect=effect,p_value=1.,n=n,n_blocks=g,status='too_few_blocks')
    sums = np.bincount(inv,weights=y,minlength=g)
    mass = np.bincount(inv,minlength=g).astype(float)
    score = sums-effect*mass
    se = np.sqrt(g/(g-1)*np.square(score).sum())/n
    statistic = effect/se if se>0 else np.inf if effect else 0.
    p_t = float(2*st.t.sf(abs(statistic),g-1))
    q = st.t.ppf(.975,g-1)
    if g<=18:
        signs = 2*((np.arange(1<<g,dtype=np.uint64)[:,None] >> np.arange(g,dtype=np.uint64))&1).astype(float)-1
        exact = True
    else:
        signs = np.random.default_rng(SEED+g+span).choice([-1.,1.],(wild_draws,g)); exact=False
    means = signs@sums/n
    scores = signs*sums-means[:,None]*mass
    ses = np.sqrt(g/(g-1)*np.square(scores).sum(1))/n
    ts = np.divide(means,ses,out=np.zeros_like(means),where=ses>0)
    exceed = int((np.abs(ts)>=abs(statistic)-1e-12).sum())
    p_wild = exceed/len(signs) if exact else (exceed+1)/(len(signs)+1)
    return dict(effect=effect,se=se,low=effect-q*se,high=effect+q*se,
                p_value=max(p_t,p_wild),p_cluster_t=p_t,p_wild=p_wild,
                wild_exact=exact,wild_draws=len(signs),n=n,n_blocks=g,
                positive_blocks=int((sums>0).sum()),status='estimated')

def check_sources():
    hashes=json.loads((OUT/'audits/initial_source_hashes.json').read_text())
    mismatched=[p for p,h in hashes.items() if digest(ROOT/p)!=h]
    if mismatched: raise ValueError('Changed source inputs: '+repr(mismatched))
    return len(hashes)
