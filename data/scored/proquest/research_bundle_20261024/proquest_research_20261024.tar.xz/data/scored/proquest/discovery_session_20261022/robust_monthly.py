"""Coverage, source, horizon and benchmark challenges to monthly associations."""
from common import *
from proquest_panel import build_panels


def readable(frame):
    f=frame[frame.scope.eq('national') & frame.topic.isin(['general_business','markets','prices','employment'])].copy()
    f['sign']=f.predicted_norm.map({'improve':'positive','up':'positive','worsen':'negative','down':'negative','flat':'flat'})
    emp=f.topic.eq('employment')
    f.loc[emp,'sign']=f.loc[emp,'predicted_norm'].map({'down':'positive','up':'negative','flat':'flat'})
    f=f[f.sign.notna()]
    f['month']=pd.PeriodIndex(pd.to_datetime(f.date),freq='M')
    return f[['page_id','date','month','topic','sign','paper','horizon_basis','horizon_used']]


def topic_signals(claims,topic):
    f=claims[claims.topic.eq(topic)]
    _,paper,national=build_panels(f)
    n=national[national.topic.eq(topic)].copy()
    result=make_signals(n)
    return result[result.topic.eq(topic)]


def main():
    verified=pd.read_csv(BASE/'descriptive/scored_claims.csv.gz',dtype={'page_id':str})
    raw=pd.read_csv(BASE/'robustness/scored_claims.csv.gz',dtype={'page_id':str})
    raw=raw[raw.source_set.eq('raw')]
    v=readable(verified);r=readable(raw)
    assert len(v)==182817,len(v)
    _,_,reconstructed=build_panels(v)
    old=national_panel().sort_values(['topic','month']).reset_index(drop=True)
    check=reconstructed.sort_values(['topic','month']).reset_index(drop=True)
    for col in ['positive_share','flat_share','negative_share','net_direction','paper_dispersion','disagreement']:
        assert np.allclose(check[col],old[col],equal_nan=True),col
    print('Reconstructed verified direction panel matches all saved values.',flush=True)
    truth=pd.read_csv(OUT/'continuous_targets.csv');truth['origin']=pd.PeriodIndex(truth.origin,freq='M')
    saved=pd.read_csv(OUT/'lagged_topic_signals.csv');saved['origin']=pd.PeriodIndex(saved.origin,freq='M')
    variants=[('verified',v),('raw',r),('stated_only',v[v.horizon_basis.eq('stated')]),
              ('stated_4_8m',v[v.horizon_basis.eq('stated') & v.horizon_used.between(4,8)])]
    fixed=['New York Times','Los Angeles Times','Washington Post','Boston Globe','Chicago Tribune']
    variants += [('fixed_five_papers_through_2001',v[v.paper.isin(fixed)&(v.month<=pd.Period('2001-12','M'))])]
    variants += [('omit_'+p,v[v.paper.ne(p)]) for p in sorted(v.paper.unique())]
    # PAYEMS is an outcome sensitivity only; never used as a historical input.
    payroll=pd.read_csv(BASE/'alternative_target_inputs_v1/PAYEMS.csv')
    pay=pd.Series(pd.to_numeric(payroll.iloc[:,1]).to_numpy(),index=pd.PeriodIndex(payroll.iloc[:,0],freq='M'))
    paygrowth={o:100*np.log(pay.get(o+5,np.nan)/pay.get(o-1,np.nan)) for o in truth.origin}
    macro=pd.read_csv(BASE/'macro_information/macro_feature_audit.csv');macro['origin']=pd.PeriodIndex(macro.origin,freq='M')
    from proquest_vintages import CORE_FEATURES
    rows=[];support=[];all_data=[]
    for topic in ['employment','general_business']:
        for name,claims in variants:
            print(topic,name,flush=True)
            signals=saved[saved.topic.eq(topic)] if name=='verified' else topic_signals(claims,topic)
            d=signals.merge(truth.drop(columns='year'),on='origin',validate='one_to_one')
            if name=='fixed_five_papers_through_2001':d=d[d.year<=2001]
            d['log_articles']=np.log1p(d.articles)
            d['payroll_growth']=d.origin.map(paygrowth)
            d['tested_predictor']=(d.net_direction-d.net_direction.mean())/d.net_direction.std()
            d['variant']=name
            all_data.append(d)
            outcome='employment_growth' if topic=='employment' else 'general_business_growth'
            for span in [2,5,10]:
                result,_,used=regression(d,outcome,['tested_predictor'],['log_articles','papers','flat_share'],span)
                rows.append(dict(topic=topic,variant=name,outcome=outcome,block_years=span,**result[0]))
            support.append(dict(topic=topic,variant=name,months=d.net_direction.notna().sum(),n_articles=claims[claims.topic.eq(topic)].page_id.nunique(),n_claims=len(claims[claims.topic.eq(topic)])))
            if topic=='employment':
                result,_,_=regression(d,'payroll_growth',['tested_predictor'],['log_articles','papers','flat_share'])
                rows.append(dict(topic=topic,variant=name,outcome='payroll_growth',block_years=5,**result[0]))
            if name=='verified':
                for subname,mask in [('exclude_2007_2009',~d.year.between(2007,2009)),('1948_1979',d.year.between(1948,1979)),('1980_2010',d.year.between(1980,2010))]:
                    result,_,_=regression(d[mask],outcome,['tested_predictor'],['log_articles','papers','flat_share'])
                    rows.append(dict(topic=topic,variant=subname,outcome=outcome,block_years=5,**result[0]))
                for anchor in [1901,1902,1903,1904]:
                    result,_,_=regression(d,outcome,['tested_predictor'],['log_articles','papers','flat_share'],anchor=anchor)
                    rows.append(dict(topic=topic,variant=f'anchor_{anchor}',outcome=outcome,block_years=5,**result[0]))
                vintage=d.merge(macro[['origin']+list(CORE_FEATURES)],on='origin',validate='one_to_one')
                result,_,_=regression(vintage,outcome,['tested_predictor'],['log_articles','papers','flat_share']+list(CORE_FEATURES))
                rows.append(dict(topic=topic,variant='vintage_macro_controls',outcome=outcome,block_years=5,**result[0]))
    pd.DataFrame(rows).to_csv(OUT/'monthly_robustness.csv',index=False)
    pd.DataFrame(support).to_csv(OUT/'monthly_robustness_support.csv',index=False)
    pd.concat(all_data).to_csv(OUT/'monthly_robustness_panels.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    print(pd.DataFrame(rows).query('block_years==5')[['topic','variant','outcome','effect','low','high','p_value','n']].to_string(index=False),flush=True)


if __name__=='__main__':main()
