"""Chronological labor-outcome probabilities, not claim correctness scores."""
from common import *
from backtest import archives, labels_for_refit, frame_for_fitting
from proquest_vintages import CORE_FEATURES
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import log_loss

CLASSES=['worsen','flat','improve']


def category(y):
    return np.where(y < -.5-1e-10,0,np.where(y>.5+1e-10,2,1))


def fit_prob(train,test,features):
    x=train[features].astype(float);z=test[features].astype(float)
    median=x.median().fillna(0);scaler=StandardScaler().fit(x.fillna(median))
    a=np.column_stack([scaler.transform(x.fillna(median)),x.isna().to_numpy(float)])
    b=np.column_stack([scaler.transform(z.fillna(median)),z.isna().to_numpy(float)])
    model=LogisticRegression(C=.1,max_iter=2000,solver='lbfgs').fit(a,category(train.training_target))
    assert np.array_equal(model.classes_,np.arange(3))
    return model.predict_proba(b)


def press_frame():
    s=pd.read_csv(OUT/'lagged_topic_signals.csv');s['origin']=pd.PeriodIndex(s.origin,freq='M')
    d=pd.DataFrame({'origin':pd.period_range('1948-01','2010-12',freq='M')})
    for topic,prefix in [('employment','jobs'),('general_business','business')]:
        g=s[s.topic.eq(topic)][['origin','net_direction','articles','papers']].rename(columns={'net_direction':prefix+'_net','articles':prefix+'_articles','papers':prefix+'_papers'})
        d=d.merge(g,on='origin',validate='one_to_one')
        d[prefix+'_log_articles']=np.log1p(d[prefix+'_articles'])
    return d


def run_study(name,frame,first,models):
    archive=archives()['RUC'];pred=[];audit=[]
    for year in range(first,2011):
        refit=pd.Period(f'{year}-01','M');labels=labels_for_refit(frame,refit,archive,'unemployment')
        train=frame.merge(labels[['origin','training_target']],on='origin',validate='one_to_one').dropna(subset=['training_target']).sort_values('origin')
        test=frame[frame.origin.dt.year.eq(year)].copy()
        assert len(test)==12 and len(train)>=120
        y=category(train.training_target.tail(120))
        prior=(np.bincount(y,minlength=3)+1)/(len(y)+3)
        for k,c in enumerate(CLASSES):test['recent_base_'+c]=prior[k]
        for model,features in models.items():
            p=fit_prob(train,test,features)
            for k,c in enumerate(CLASSES):test[model+'_'+c]=p[:,k]
        pred.append(test[['origin']+[c for c in test if any(c.startswith(m+'_') for m in ['recent_base']+list(models))]])
        audit.append(dict(study=name,year=year,n_training=len(train),last_training_origin=train.origin.max(),label_vintage=labels.label_vintage.iloc[0],label_available_by=labels.label_available_by.iloc[0]))
    result=pd.concat(pred,ignore_index=True);result['study']=name
    pd.DataFrame(audit).to_csv(OUT/f'labor_classification_refits_{name}.csv',index=False)
    return result


def main():
    press_models={
        'jobs':['jobs_net','jobs_log_articles','jobs_papers'],
        'business':['business_net','business_log_articles','business_papers'],
        'both':['jobs_net','business_net','jobs_log_articles','jobs_papers','business_log_articles','business_papers'],
        'coverage':['jobs_log_articles','jobs_papers','business_log_articles','business_papers']}
    macro_models={'macro':list(CORE_FEATURES),'macro_jobs':list(CORE_FEATURES)+['jobs_net']}
    predicted=pd.concat([run_study('press',press_frame(),1966,press_models),run_study('macro',frame_for_fitting(),1977,macro_models)],ignore_index=True)
    # Evaluation truth is introduced after all chronological fits.
    truth=pd.read_csv(OUT/'continuous_targets.csv');truth['origin']=pd.PeriodIndex(truth.origin,freq='M')
    predicted=predicted.merge(truth[['origin','employment_growth']],on='origin',validate='many_to_one')
    assert predicted.employment_growth.notna().all()
    predicted['target']=category(predicted.employment_growth)
    predicted.to_csv(OUT/'labor_classification_predictions.csv',index=False)
    metrics=[];tests=[];sens=[];cal=[];block=[]
    for study,g in predicted.groupby('study'):
        models=['recent_base']+list(press_models if study=='press' else macro_models)
        y=g.target.to_numpy(int);onehot=np.eye(3)[y];loss={}
        for model in models:
            p=g[[model+'_'+c for c in CLASSES]].to_numpy()
            assert np.allclose(p.sum(axis=1),1)
            loss[model]=((p-onehot)**2).sum(axis=1)
            metrics.append(dict(study=study,model=model,n=len(g),brier=loss[model].mean(),log_loss=log_loss(y,p,labels=[0,1,2]),accuracy=(p.argmax(axis=1)==y).mean(),n_worsen=(y==0).sum(),n_flat=(y==1).sum(),n_improve=(y==2).sum()))
            for k,c in enumerate(CLASSES):
                bins=np.minimum((p[:,k]*5).astype(int),4)
                for b in np.unique(bins):
                    mask=bins==b
                    cal.append(dict(study=study,model=model,category=c,bin=int(b),n=mask.sum(),probability=p[mask,k].mean(),observed=(y[mask]==k).mean()))
        pairs=[('jobs','recent_base'),('business','recent_base'),('both','recent_base')] if study=='press' else [('macro_jobs','macro')]
        for model,baseline in pairs:
            gain=loss[baseline]-loss[model];years=g.origin.dt.year
            anchor=1966 if study=='press' else 1977
            for span in [2,5,10]:
                r=clustered_mean(gain,np.ones(len(gain)),years,span,anchor=anchor)
                rec=dict(test=f'labor_{study}_{model}_vs_{baseline}',batch='labor_classification',study=study,model=model,baseline=baseline,block_years=span,**r)
                if span==5:tests.append(rec)
                else:sens.append(rec)
            for omit in [False,True]:
                mask=~years.between(2007,2009) if omit else years.notna()
                r=clustered_mean(gain[mask],np.ones(mask.sum()),years[mask],5,anchor=anchor)
                sens.append(dict(study=study,model=model,baseline=baseline,exclude_2007_2009=omit,**r))
            for b in sorted(((years-anchor)//5).unique()):
                mask=(years-anchor)//5==b
                block.append(dict(study=study,model=model,baseline=baseline,block=int(b),n=mask.sum(),gain=gain[mask].mean()))
    tests=adjust(pd.DataFrame(tests),4)
    tests.to_csv(OUT/'labor_classification_tests.csv',index=False)
    pd.DataFrame(metrics).to_csv(OUT/'labor_classification_metrics.csv',index=False)
    pd.DataFrame(sens).to_csv(OUT/'labor_classification_sensitivities.csv',index=False)
    pd.DataFrame(cal).to_csv(OUT/'labor_classification_calibration.csv',index=False)
    pd.DataFrame(block).to_csv(OUT/'labor_classification_blocks.csv',index=False)
    session=adjust(pd.concat([pd.read_csv(OUT/'session_wide_48_tests.csv'),tests],ignore_index=True),52)
    session.to_csv(OUT/'session_wide_52_tests.csv',index=False)
    print(pd.DataFrame(metrics).to_string(index=False));print(tests.to_string(index=False))
    print('Session-wide survivors:',session[session.holm_p<.05][['test','effect','holm_p']].to_string(index=False))


if __name__=='__main__':main()
