"""Matched lead/lag diagnostics and four retained future-minus-recent tests."""
from associations import *
from proquest_descriptive import load_reference

LAGS=[-12,-6,0,6,12,18]

def run():
    data=inputs();series,metadata=load_reference();profiles=[];tests=[];sensitivity=[];scores=[];sample_rows=[]
    block_calendar=np.arange(0,23)
    for topic in TOPICS:
        d=data[data.topic.eq(topic)].copy()
        s=series[topic]
        for lag in LAGS:
            def change(o):
                a=s.get(o-1+lag,np.nan);b=s.get(o+5+lag,np.nan)
                if not np.isfinite(a) or not np.isfinite(b) or a<=0:return np.nan
                return -(b-a) if topic=='employment' else 100*np.log(b/a)
            d[f'lag_{lag}']=d.origin.map(change)
        controls=['net_direction','net_squared','flat_share','log_articles','n_papers']
        if topic=='markets':controls+=['stock_past_return','stock_past_volatility']
        required=['cross_topic_gap']+controls+[f'lag_{lag}' for lag in LAGS]
        d=d.replace([np.inf,-np.inf],np.nan).dropna(subset=required).copy()
        d['future_minus_recent']=d['lag_0']-d['lag_-6']
        for lag in LAGS:
            r,fit,used=estimate(d,'cross_topic_gap',f'lag_{lag}',controls,wild=False)
            profiles.append(dict(topic=topic,lag_months=lag,**r))
            if fit is not None:
                X=select_design(used,controls).to_numpy(float);j=list(select_design(used,controls)).index('tested_predictor')
                bread=np.linalg.inv(X.T@X);res=fit.resid.to_numpy(float)
                groups=(used.year.to_numpy()-1900)//5;g=len(np.unique(groups));n,k=X.shape
                factor=g/(g-1)*(n-1)/(n-k)
                vector=np.array([np.sqrt(factor)*bread[j]@(X[groups==b].T@res[groups==b])
                    if (groups==b).any() else 0. for b in block_calendar])
                np.testing.assert_allclose(np.linalg.norm(vector),r['se'],rtol=1e-7)
                scores.append(vector/r['se'])
        r,_,used=estimate(d,'cross_topic_gap','future_minus_recent',controls,wild=True)
        tests.append(dict(test=f'timing_{topic}_cross_gap_future_minus_recent',batch='cross_timing',topic=topic,block_years=5,**r))
        sample_rows.append(used.assign(topic=topic))
        for span in [2,10]:
            rr,_,_=estimate(d,'cross_topic_gap','future_minus_recent',controls,span=span,wild=True)
            sensitivity.append(dict(test=tests[-1]['test'],variant=f'blocks_{span}',**rr))
        print(topic,r['effect'],r['p_value'],r['n'],flush=True)
    profile=pd.DataFrame(profiles)
    # Shared calendar sign multipliers preserve cross-topic/time dependence in
    # this descriptive family of 24 profile bands, conditional on fitted X.
    q=np.column_stack(scores);rng=np.random.default_rng(SEED+912);maxima=[]
    for _ in range(20):
        signs=rng.choice([-1.,1.],(5000,len(block_calendar)))
        maxima.extend(abs(signs@q).max(axis=1))
    critical=float(np.quantile(maxima,.95))
    profile['simultaneous_low']=profile.effect-critical*profile.se
    profile['simultaneous_high']=profile.effect+critical*profile.se
    profile.to_csv(OUT/'timing_profiles.csv',index=False)
    result=adjust(pd.DataFrame(tests),83);result.to_csv(OUT/'timing_tests.csv',index=False)
    pd.DataFrame(sensitivity).to_csv(OUT/'timing_sensitivities.csv',index=False)
    pd.concat(sample_rows,ignore_index=True).to_csv(OUT/'audits/timing_analysis_rows.csv.gz',index=False,
        compression={'method':'gzip','mtime':0})
    save_json(OUT/'audits/timing_manifest.json',dict(n_tests=4,profile_slopes=24,
        simultaneous_band_critical=critical,multiplier_draws=100000,
        profile_inference='Conditional cluster-score multiplier bands, not family-wide discovery p-values or causal identification.',
        reference_hashes={k:v['sha256'] for k,v in metadata.items()},source_count=check_sources(),code_sha256=digest(__file__)))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(2,2,figsize=(11,8),layout='constrained')
    for ax,topic in zip(axes.flat,TOPICS):
        g=profile[profile.topic.eq(topic)].sort_values('lag_months')
        ax.fill_between(g.lag_months,g.simultaneous_low,g.simultaneous_high,color='#d9e8ec',label='24-slope simultaneous band')
        ax.errorbar(g.lag_months,g.effect,yerr=1.96*g.se,fmt='o-',color='#14576b',capsize=3)
        ax.axhline(0,color='#888',lw=.8);ax.axvline(0,color='#aaa',lw=.8,ls='--')
        ax.set_title(topic.replace('_',' ').title());ax.set_xlabel('Six-month window offset; 0 = following six months')
        ax.set_ylabel('Outcome change per SD of own-minus-other gap')
        ax.grid(alpha=.15)
    fig.suptitle('Cross-topic expectations: timing is a diagnostic, not a selected target')
    fig.savefig(OUT/'figures/cross_topic_timing.png',dpi=170);fig.savefig(OUT/'figures/cross_topic_timing.svg');plt.close(fig)
    journal('timing','Completed four matched future-versus-recent contrasts and 24 diagnostic profile slopes')
    print(result[['test','effect','low','high','p_value','holm_p','n','n_blocks']].to_string(index=False))

if __name__=='__main__':run()
