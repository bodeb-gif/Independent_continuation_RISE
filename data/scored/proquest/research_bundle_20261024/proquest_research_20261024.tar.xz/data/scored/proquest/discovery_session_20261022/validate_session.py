"""Independent source, chronology, arithmetic and statistical-library checks."""
from common import *
import py_compile
import itertools
from bs4 import BeautifulSoup
sys.path.insert(0,str(OUT/'phase2'))
from inference_audit import regression_bootstrap,mean_bootstrap


def main():
    checks=[]
    def check(name,condition,detail=None):
        if not bool(condition):raise AssertionError(name)
        checks.append(dict(check=name,passed=True,detail=detail))
    frozen=json.loads((BASE/'robustness/summary.json').read_text())
    check('all 222 original annual export hashes unchanged',all(digest(ROOT/p)==h for p,h in frozen['sources'].items()),len(frozen['sources']))
    references=json.loads((BASE/'descriptive/summary.json').read_text())['reference']
    check('all original deterministic references unchanged',all(digest(ROOT/r['file'])==r['sha256'] for r in references.values()),len(references))
    for path in sorted(OUT.rglob('*.py')):py_compile.compile(str(path),doraise=True)
    check('every session Python script compiles',True,len(list(OUT.rglob('*.py'))))
    signal=pd.read_csv(OUT/'lagged_topic_signals.csv')
    check('all signal print dates precede forecast origins',(pd.PeriodIndex(signal.latest_print_month,freq='M')<pd.PeriodIndex(signal.origin,freq='M')).all(),len(signal))
    cells=pd.read_csv(OUT/'cells_confidence_general_business.csv')
    primary=pd.read_csv(OUT/'primary_results.csv').set_index('test')
    check('matched contrast independently reproduces weighted cell mean',np.isclose(np.sum(cells.weight*(cells.hit_left-cells.hit_right))/cells.weight.sum(),primary.loc['confidence_general_business','effect'],atol=1e-12))
    human=pd.read_csv(OUT/'historical_human_measurement.csv')
    old=pd.read_csv(BASE/'human_rescore_v1/reviewed_rescored.csv');old=old[old.frame.eq('historical')]
    h=human[human.reviewer.eq('reviewer1')].merge(old,on='record_id',validate='one_to_one',suffixes=('_new','_saved'))
    check('Reviewer 1 eligibility reproduces prior independent human rescoring',h.human_scorable_new.eq(h.human_scorable_saved).all(),len(h))
    mask=h.human_scorable_new.eq(1)
    check('Reviewer 1 correctness reproduces prior human rescoring',h.loc[mask,'human_hit'].eq(h.loc[mask,'human_correct']).all(),int(mask.sum()))
    weights=pd.read_csv(OUT/'measurement_fixed_support_weights.csv.gz')
    check('fixed measurement support arm weights each sum to one',np.allclose(weights.groupby('confidence').weight_claim.sum(),1))
    for file in [OUT/'backtest_training_labels_alpha10.csv.gz',OUT/'phase2/fresh_vintage_training_labels.csv.gz',OUT/'phase2/gdp_training_labels.csv.gz']:
        d=pd.read_csv(file);used=d[d.training_target.notna()].copy()
        year=used.refit_year.astype(str)+'-01'
        check(file.stem+' vintage labels were available before refit',(pd.to_datetime(used.label_available_by)<pd.to_datetime(year)).all(),len(used))
        check(file.stem+' target windows mature before refit',(pd.PeriodIndex(used.origin,freq='M')+8<pd.PeriodIndex(year,freq='M')).all())
    validation=json.loads((OUT/'phase2/alfred_bulk_validation.json').read_text())
    check('all 609 ALFRED dates validate with 225 independent graph crosschecks',validation['n_validated_dates']==609 and validation['graph_snapshots_crosschecked']==225 and validation['maximum_crosscheck_difference']==0)
    dates=pd.read_csv(OUT/'spf_availability_audit.csv')
    check('SPF unavailable dates excluded before comparison',int((~dates.available).sum())==3 and len(pd.read_csv(OUT/'spf_predictions.csv'))==77)
    gdp=pd.read_csv(OUT/'phase2/gdp_predictions.csv')
    check('GDP common support excludes known source hole',len(gdp)==143 and '2004-01' not in set(gdp.origin))
    f=pd.read_csv(OUT/'session_wide_68_tests.csv')
    check('all 68 hypotheses retained with unique names and bounded p values',len(f)==68 and f.test.is_unique and f.p_value.between(0,1).all())
    adjusted=adjust(f,68)
    check('cumulative Holm values reproduce independently',np.allclose(adjusted.holm_p,f.holm_p))
    # Compare the fast exact-wild algebra to full statsmodels refits on a tiny
    # independent fixture, including recalculation of cluster standard errors.
    rng=np.random.default_rng(47013);n=32;groups=np.repeat(np.arange(4),8)
    d=pd.DataFrame(dict(year=1960+groups*5,tested_predictor=rng.normal(size=n),control=rng.normal(size=n)))
    d['y']=.2*d.tested_predictor+.4*d.control+np.repeat(rng.normal(size=4),8)+rng.normal(size=n)
    cols=['const','tested_predictor','control'];d['const']=1.
    X=d[cols];y=d.y
    fit=sm.OLS(y,X).fit(cov_type='cluster',cov_kwds={'groups':groups,'use_correction':True,'df_correction':True},use_t=True)
    null=sm.OLS(y,X[['const','control']]).fit();statistics=[]
    for sign in itertools.product([-1.,1.],repeat=4):
        star=null.fittedvalues+null.resid*np.asarray(sign)[groups]
        model=sm.OLS(star,X).fit(cov_type='cluster',cov_kwds={'groups':groups,'use_correction':True,'df_correction':True},use_t=True)
        statistics.append(model.tvalues['tested_predictor'])
    brute=np.mean(np.abs(statistics)>=abs(fit.tvalues['tested_predictor'])-1e-10)
    fast,_,_=regression_bootstrap(d,'y',cols,5)
    check('exact wild bootstrap agrees with independent statsmodels refits',np.isclose(brute,fast['wild_p']) and np.isclose(fit.bse['tested_predictor'],fast['se'],atol=1e-10))
    weights=rng.uniform(.3,3,n);values=rng.normal(size=n)+np.repeat(rng.normal(size=4),8)
    fixture=pd.DataFrame(dict(year=d.year,weight=weights,difference=values))
    fit=sm.WLS(values,np.ones((n,1)),weights=weights).fit(cov_type='cluster',cov_kwds={'groups':groups,'use_correction':True,'df_correction':True},use_t=True)
    fast,_,_=mean_bootstrap(fixture,5)
    check('weighted cluster mean agrees with independent WLS covariance',np.isclose(fit.params[0],fast['effect']) and np.isclose(fit.bse[0],fast['se'],atol=1e-10))
    for name,required in [('test_offline.txt','ALL 97 CHECKS PASSED'),('test_scoring.txt','33 passed, 0 failed'),('test_forecasts.txt','33 passed, 0 failed')]:
        check(name+' required suite passed',required in (OUT/name).read_text())
    result=dict(status='passed',n_checks=len(checks),checks=checks,
                caution='Computational and chronology validation is not semantic source validation or independent economic confirmation.')
    write_json('validation.json',result)
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
