"""Run the three remaining market models sequentially to bound CPU use."""
from pathlib import Path
import os
import subprocess
import sys
folder=Path(__file__).resolve().parent
for algorithm in ['hist_gradient_boosting','extra_trees','gru']:
 print('Starting',algorithm,flush=True)
 with (folder/'logs'/('market_tail_'+algorithm+'.log')).open('a') as log:
  result=subprocess.run([sys.executable,str(folder/'market_tail.py'),'--algorithm',algorithm],stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'))
 if result.returncode:raise SystemExit('Model failed: '+algorithm)
 print('Completed',algorithm,flush=True)
