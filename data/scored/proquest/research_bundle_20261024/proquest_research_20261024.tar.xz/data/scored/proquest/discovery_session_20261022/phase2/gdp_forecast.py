"""Chronological native-national-output fits, final GDP evaluation only afterwards."""
from vintage_data import *
from common import clustered_mean,adjust
from backtest import frame_for_fitting,ridge_predict
from proquest_vintages import CORE_FEATURES
from inference_audit import mean_bootstrap


def main():
    archive=RealOutputArchive();fresh=AlfredUnemployment();f=frame_for_fitting()
    cols=['unemployment_level','unemployment_change_3m','unemployment_change_12m','unemployment_age_months']
    u=fresh.features(f.origin)
    f=f.drop(columns=cols).merge(u[['origin']+cols],on='origin',validate='one_to_one')
    f=f[f.origin.dt.month.isin([1,4,7,10])].copy()
    f=f.merge(archive.features(f.origin),on='origin',validate='one_to_one')
    signal=pd.read_csv(SESSION/'lagged_topic_signals.csv');signal['origin']=pd.PeriodIndex(signal.origin,freq='M')
    f=f.merge(signal[signal.topic.eq('markets')][['origin','net_direction']].rename(columns={'net_direction':'markets_net'}),on='origin',validate='one_to_one')
    extra=['real_output_growth_1q','real_output_growth_2q','real_output_growth_4q','real_output_age_months']
    macro=list(CORE_FEATURES)+extra
    f['input_supported']=np.isfinite(f[macro]).all(axis=1)&(f.real_output_age_months<=6)
    f[['origin','input_supported','real_output_vintage','real_output_age_months']].to_csv(OUT/'gdp_input_support.csv',index=False)
    f=f[f.input_supported].copy()
    models={'macro':macro,'macro_jobs':macro+['jobs_net'],'macro_business':macro+['business_net'],
            'macro_markets':macro+['markets_net'],'macro_all':macro+['jobs_net','business_net','markets_net']}
    predicted=[];audits=[];label_audits=[];parameters=[]
    for year in range(1975,2011):
        refit=pd.Period(f'{year}-01','M');key,snapshot=archive.snapshot(refit)
        labels=[]
        for origin in f.loc[f.origin<refit,'origin']:
            start,end=(origin-1).asfreq('Q'),(origin+5).asfreq('Q')
            first,last=snapshot.get(start,np.nan),snapshot.get(end,np.nan)
            mature=origin+8<refit
            y=100*np.log(last/first) if mature and np.isfinite(first) and np.isfinite(last) and first>0 else np.nan
            labels.append(dict(origin=origin,training_target=y,label_vintage=key,label_available_by=archive.dates[key],mature=mature,target_start=start,target_end=end))
        labels=pd.DataFrame(labels);label_audits.append(labels.assign(refit_year=year))
        train=f.merge(labels[['origin','training_target']],on='origin',validate='one_to_one').dropna(subset=['training_target']).sort_values('origin')
        test=f[f.origin.dt.year.eq(year)].copy()
        if len(train)<32:raise ValueError((year,len(train)))
        for model,features in models.items():
            test[model],p=ridge_predict(train,test,features,10.)
            parameters.append(p.assign(refit_year=year,model=model))
        test['recent_mean']=train.training_target.tail(40).mean()
        test['zero_growth']=0.;test['twice_last_quarter_growth']=2*test.real_output_growth_1q
        predicted.append(test[['origin']+list(models)+['recent_mean','zero_growth','twice_last_quarter_growth']])
        audits.append(dict(year=year,n_training=len(train),n_test=len(test),last_training_origin=train.origin.max(),
                           label_vintage=key,label_available_by=archive.dates[key],native_quantity='GNP' if archive.dates[key]<pd.Timestamp('1991-12-01') else 'GDP'))
    p=pd.concat(predicted,ignore_index=True)
    raw=pd.read_csv(BASE/'alternative_target_inputs_v1/GDPC1.csv')
    gdp=pd.Series(pd.to_numeric(raw.iloc[:,1]).to_numpy(),index=pd.PeriodIndex(raw.iloc[:,0],freq='Q'))
    p['truth']=[100*np.log(gdp.loc[(o+5).asfreq('Q')]/gdp.loc[(o-1).asfreq('Q')]) for o in p.origin]
    assert len(p)==143 and p.truth.notna().all()
    p.to_csv(OUT/'gdp_predictions.csv',index=False)
    pd.DataFrame(audits).to_csv(OUT/'gdp_refit_audit.csv',index=False)
    pd.concat(label_audits).to_csv(OUT/'gdp_training_labels.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    pd.concat(parameters).to_csv(OUT/'gdp_parameters.csv',index=False)
    metrics=[]
    for model in list(models)+['recent_mean','zero_growth','twice_last_quarter_growth']:
        e=p[model]-p.truth
        metrics.append(dict(model=model,n=len(p),mse=np.square(e).mean(),rmse=np.sqrt(np.square(e).mean()),mae=abs(e).mean()))
    tests=[];sens=[]
    pairs=[(m,'macro') for m in ['macro_jobs','macro_business','macro_markets','macro_all']]+[('macro_all','recent_mean'),('macro','recent_mean')]
    for model,baseline in pairs:
        gain=(p[baseline]-p.truth)**2-(p[model]-p.truth)**2
        c=pd.DataFrame(dict(year=p.origin.dt.year,weight=1.,difference=gain))
        for span in [2,5,10]:
            r=clustered_mean(gain,np.ones(len(gain)),p.origin.dt.year,span,anchor=1975)
            row=dict(test=f'gdp_{model}_vs_{baseline}',batch='gdp_forecast',model=model,baseline=baseline,block_years=span,**r)
            if span==5:
                wild,_,_=mean_bootstrap(c,5)
                row['cluster_t_p']=row['p_value'];row['exact_studentized_p']=wild['wild_p']
                row['p_value']=max(row['p_value'],wild['wild_p']);tests.append(row)
            else:sens.append(row)
    tests=adjust(pd.DataFrame(tests),6)
    tests.to_csv(OUT/'gdp_tests.csv',index=False)
    pd.DataFrame(metrics).to_csv(OUT/'gdp_metrics.csv',index=False)
    pd.DataFrame(sens).to_csv(OUT/'gdp_sensitivities.csv',index=False)
    session=adjust(pd.concat([pd.read_csv(SESSION/'session_wide_62_tests.csv'),tests],ignore_index=True),68)
    session.to_csv(SESSION/'session_wide_68_tests.csv',index=False)
    (OUT/'gdp_manifest.json').write_text(json.dumps(dict(n_evaluation=len(p),excluded_input_origin='2004-01',n_tests=6,
        source_sha256=archive.source_hash,code_sha256=digest(Path(__file__)),
        target='Two-quarter real GDP log growth; native historical GNP/GDP training labels'),indent=2)+'\n')
    print(pd.DataFrame(metrics).to_string(index=False));print(tests[['test','effect','low','high','p_value','holm_p','n_blocks']].to_string(index=False))


if __name__=='__main__':main()
