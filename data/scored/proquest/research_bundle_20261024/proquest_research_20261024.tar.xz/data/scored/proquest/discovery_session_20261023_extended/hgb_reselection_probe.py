"""Small, fully nested HGB multiplier probe; no tail-interval claim."""
import time
from refit_multiplier_corrected import *

def run():
    started=time.monotonic();algorithm='hist_gradient_boosting';maximum=12
    frame,valid=feature_frame();targets=HistoricalTargets()
    folder=OUT/'models_boundary_corrected'/algorithm;out=folder/'reselection_probe';out.mkdir(exist_ok=True)
    spec=dict(created_utc=dt.datetime.now(dt.timezone.utc),code_sha256=digest(__file__),
        canonical_sampler_sha256=digest(OUT/'refit_multiplier_corrected.py'),
        session_utils_sha256=digest(OUT/'session_utils.py'),boundary_rules_sha256=digest(OUT/'boundary_rules.py'),
        predictions_sha256=digest(folder/'predictions_without_truth.csv'),maximum_nonuniform_draws=maximum,
        seed_sequence=[SEED,822,0],stop_new_draws_utc='2026-10-24T12:20:00+00:00',
        role='Fully repeats chronological inner model selection and historical-vintage training in each reweighting. A small procedural sensitivity probe, not enough draws for reliable tail quantiles or a new p-value.')
    receipt=out/'implementation.json'
    if receipt.exists():
        prior=json.loads(receipt.read_text());spec['created_utc']=prior['created_utc']
        if prior!=spec:raise ValueError('Changed reselection probe implementation')
    else:save_json(receipt,spec)
    original=pd.read_csv(folder/'predictions_without_truth.csv');original.origin=pd.PeriodIndex(original.origin,freq='M')
    originals={(t,a):g.set_index('origin').prediction for (t,a),g in original.groupby(['task','arm'])}
    audits={}
    for path in (folder/'annual').glob('*.json'):
        d=json.loads(path.read_text());audits[(d['task'],d['arm'],d['refit_year'])]=d
    groups=(valid.year-1977)//5;codes=np.unique(groups);rng=np.random.default_rng(np.random.SeedSequence([SEED,822,0]))
    all_rows=[];stop=dt.datetime.fromisoformat(spec['stop_new_draws_utc'])
    for draw in range(-1,maximum):
        if draw>=0 and dt.datetime.now(dt.timezone.utc)>=stop:break
        exp=np.ones(len(codes)) if draw<0 else rng.exponential(1.,len(codes))
        weights=pd.Series(exp[np.searchsorted(codes,groups)],index=valid)
        checkpoint=out/f'draw_{draw:04}.json'
        if checkpoint.exists():
            if draw>=0:all_rows+=json.loads(checkpoint.read_text())['results']
            continue
        rows=[];errors=[];changes=[]
        for task in TASKS:
            predictions={arm:[] for arm in ARMS}
            for year in range(1977,2011):
                outer=pd.Period(f'{year}-01','M');test=valid[valid.year==year]
                for arm in ARMS:
                    config=select_weighted(algorithm,task,arm,frame,valid,targets,outer,weights)
                    previous=audits[(task,arm,year)]['configuration']
                    changes.append(dict(task=task,year=year,arm=arm,changed=config!=previous,
                        configuration=config,original_configuration=previous))
                    train,y,_=eligible(frame,valid,targets,outer,task,config['window'])
                    p=predict_weighted(algorithm,task,config,frame,train,y,test,ARMS[arm],weights,113+year)
                    predictions[arm].append(pd.Series(p,index=test))
                if year%5==0:
                    save_json(out/'current_fit.json',dict(draw=draw,task=task,year=year,
                        elapsed_seconds=time.monotonic()-started,updated_utc=dt.datetime.now(dt.timezone.utc)))
            truth=evaluation_truth(pd.period_range('1977-01','2010-12',freq='M'),task);losses={}
            for arm,parts in predictions.items():
                values=pd.concat(parts).sort_index();w=weights.reindex(values.index).to_numpy(float)
                losses[arm]=(values.to_numpy()-truth)**2
                if draw<0:
                    error=float(abs(values-originals[(task,arm)]).max());errors.append(dict(task=task,arm=arm,max_error=error))
                    if error>1e-8:raise ValueError('Uniform fully nested probe differs from canonical forecasts')
            for newer,older,label in [('macro_coverage_net','macro_coverage','net_minus_macro_coverage'),
                ('macro_coverage_net_structure','macro_coverage_net','structure_minus_net')]:
                rows.append(dict(draw=draw,algorithm=algorithm,task=task,comparison=label,
                    gain=float(np.average(losses[older]-losses[newer],weights=w)),
                    configurations_changed=sum(r['changed'] for r in changes),configurations_so_far=len(changes)))
        save_json(checkpoint,dict(draw=draw,block_codes=codes,block_weights=exp,results=rows,
            selections=changes,elapsed_seconds=time.monotonic()-started))
        if draw<0:
            save_json(out/'uniform_reproduction.json',dict(status='passed',errors=errors,
                selected_configurations_changed=sum(r['changed'] for r in changes),n_configurations=len(changes)))
            journal('hgb_reselection_probe','Uniform full inner selection reproduces canonical forecasts')
        else:all_rows+=rows
        save_json(out/'status.json',dict(status='running',last_completed_draw=draw,completed_draws=len(all_rows)//8,
            maximum_draws=maximum,elapsed_seconds=time.monotonic()-started,updated_utc=dt.datetime.now(dt.timezone.utc)))
        print('HGB fully nested draw',draw,'complete',round(time.monotonic()-started,1),'seconds',flush=True)
        journal('hgb_reselection_probe','Completed fully nested reweighting probe draw',draw=draw,
            configurations_changed=sum(r['changed'] for r in changes),n_configurations=len(changes))
    pd.DataFrame(all_rows).to_csv(out/'draws.csv',index=False)
    save_json(out/'status.json',dict(status='complete' if len(all_rows)//8==maximum else 'time_limited',
        completed_draws=len(all_rows)//8,maximum_draws=maximum,elapsed_seconds=time.monotonic()-started,
        updated_utc=dt.datetime.now(dt.timezone.utc),source_check=check_sources()))

if __name__=='__main__':
    with threadpool_limits(limits=1):run()
