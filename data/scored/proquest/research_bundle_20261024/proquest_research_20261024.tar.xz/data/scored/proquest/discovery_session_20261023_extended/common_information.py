"""Article splits and past-only PCA: shared information versus specialization."""
import hashlib
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from associations import *
from paper_timing_robustness import basic_features,analysis_frame

NAMES=['common_information_peer_employment','common_information_other_after_halves',
       'common_information_pca_factor','common_information_employment_residual']

def print_wide(source):
    f=pd.read_csv(OUT/'cache'/f'features_{source}.csv.gz');f['origin']=pd.PeriodIndex(f.origin,freq='M')
    return f.pivot(index='origin',columns='topic',values='net_direction').sort_index()

def pca_features(source):
    wide=print_wide(source);others=['general_business','markets','prices'];rows=[];weights=[]
    for origin in wide.index:
        past=wide.loc[wide.index<origin,others].dropna()
        rec=dict(origin=origin,pca_factor=np.nan,employment_residual=np.nan)
        current=wide.loc[origin,others]
        if len(past)>=36 and current.notna().all():
            scaler=StandardScaler().fit(past.to_numpy(float))
            if (scaler.scale_<=1e-10).any():raise ValueError('Constant source topic')
            z=scaler.transform(past.to_numpy(float));fit=PCA(n_components=1,svd_solver='full').fit(z)
            sign=1. if fit.components_[0,0]>=0 else -1.
            previous_factor=fit.transform(z).ravel()*sign
            rec['pca_factor']=float(fit.transform(scaler.transform(current.to_numpy(float)[None,:]))[0,0]*sign)
            employment=wide.loc[past.index,'employment'];ok=employment.notna().to_numpy()
            if ok.sum()>=36 and np.isfinite(wide.loc[origin,'employment']):
                X=np.column_stack([np.ones(ok.sum()),previous_factor[ok]])
                coef=np.linalg.lstsq(X,employment.to_numpy(float)[ok],rcond=None)[0]
                rec['employment_residual']=float(wide.loc[origin,'employment']-coef@[1.,rec['pca_factor']])
            weights.append(dict(origin=origin,n_past_complete=len(past),latest_training_origin=past.index.max(),
                explained_variance=float(fit.explained_variance_ratio_[0]),
                **{t:float(v*sign) for t,v in zip(others,fit.components_[0])}))
        rows.append(rec)
    result=pd.DataFrame(rows)
    pd.DataFrame(weights).to_csv(OUT/'audits'/f'pca_loadings_{source}.csv',index=False)
    return result

def split_features(source):
    c=pd.read_csv(OUT/'cache'/f'print_claims_{source}.csv.gz',dtype={'page_id':str})
    c['month']=pd.PeriodIndex(c.month,freq='M')
    keys={p:hashlib.sha256(('20261024:'+p).encode()).digest()[0]%2 for p in c.page_id.unique()}
    c['half']=c.page_id.map(keys)
    parts=[]
    for half in [0,1]:
        f=basic_features(c[c.half.eq(half)])
        f=f[f.topic.eq('employment')][['origin','net_direction','n_articles','n_papers']]
        f=f.rename(columns={key:f'half{half}_{key}' for key in ['net_direction','n_articles','n_papers']})
        parts.append(f)
    return parts[0].merge(parts[1],on='origin',validate='one_to_one')

def run():
    rows=[];sensitivity=[];samples=[];diagnostics=[]
    for source in ['verified','raw']:
        f=inputs(source);d=f[f.topic.eq('employment')].copy()
        wide=print_wide(source)
        other=wide.drop(columns='employment')
        other_mean=other.mean(axis=1).where(other.notna().sum(axis=1)>=2)
        d['other_topic_mean']=d.origin.map(other_mean)
        d=d.merge(split_features(source),on='origin',validate='one_to_one')
        split=d.dropna(subset=['half0_net_direction','half1_net_direction','other_topic_mean']).copy()
        base=['flat_share','log_articles','n_papers']
        models=[(NAMES[0],split,'half1_net_direction',base+['half0_net_direction']),
            (NAMES[1],split,'other_topic_mean',base+['half0_net_direction','half1_net_direction'])]
        pca=pca_features(source)
        p=d.merge(pca,on='origin',validate='one_to_one')
        p=p.dropna(subset=['pca_factor','employment_residual']).copy()
        models += [(NAMES[2],p,'pca_factor',base+['employment_residual']),
            (NAMES[3],p,'employment_residual',base+['pca_factor'])]
        for test,frame,feature,controls in models:
            r,fit,used=estimate(frame,feature,'employment_growth',controls,wild=True)
            row=dict(test=test,batch='common_information',feature=feature,outcome='employment_growth',block_years=5,**r)
            if source=='verified':rows.append(row);samples.append(used.assign(test=test))
            else:sensitivity.append(dict(variant='raw',**row))
            if source=='verified' and fit is not None:
                for span in [2,10]:
                    rr,_,_=estimate(frame,feature,'employment_growth',controls,span=span,wild=True)
                    sensitivity.append(dict(test=test,variant=f'blocks_{span}',**rr))
                for label,mask in [('exclude_2007_2009',~frame.year.between(2007,2009)),
                    ('pre_1980',frame.year<1980),('1980_onward',frame.year>=1980)]:
                    rr,_,_=estimate(frame[mask],feature,'employment_growth',controls,wild=False)
                    sensitivity.append(dict(test=test,variant=label,**rr))
                from proquest_vintages import CORE_FEATURES
                rr,_,_=estimate(frame,feature,'employment_growth',controls+list(CORE_FEATURES),wild=True)
                sensitivity.append(dict(test=test,variant='vintage_macro_controls',**rr))
            print(source,test,r['effect'],r['p_value'],r['n'],flush=True)
        diagnostics.append(dict(source_set=source,common_split_origins=len(split),
            half_correlation=split[['half0_net_direction','half1_net_direction']].corr().iloc[0,1],
            n_pca_employment_origins=int(p.employment_growth.notna().sum())))
        p.to_csv(OUT/'cache'/f'common_information_panel_{source}.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    result=adjust(pd.DataFrame(rows),116);assert len(result)==4
    result.to_csv(OUT/'common_information_tests.csv',index=False)
    pd.DataFrame(sensitivity).to_csv(OUT/'common_information_sensitivities.csv',index=False)
    pd.DataFrame(diagnostics).to_csv(OUT/'common_information_diagnostics.csv',index=False)
    pd.concat(samples,ignore_index=True).to_csv(OUT/'audits/common_information_analysis_rows.csv.gz',index=False,
        compression={'method':'gzip','mtime':0})
    save_json(OUT/'audits/common_information_manifest.json',dict(status='complete',n_tests=4,
        code_sha256=digest(__file__),source_count=check_sources(),
        limits='The PCA is a statistical source component, not an identified economic shock. Split-sample correlation is not human validation or proof of classical independent measurement errors.'))
    journal('common_information','Completed four article-split and past-only component questions')
    print(result[['test','effect','low','high','p_value','holm_p','n','n_blocks']].to_string(index=False))

if __name__=='__main__':run()
