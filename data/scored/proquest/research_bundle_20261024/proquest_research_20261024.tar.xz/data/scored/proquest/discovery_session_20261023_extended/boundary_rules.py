"""Numerically stable strict downturn boundaries, preserving initial outputs."""
from model_data import *
from model_data import evaluation_truth as original_evaluation_truth

def below_boundary(values,threshold):
    values=np.asarray(values,float)
    return (values<threshold)&~np.isclose(values,threshold,rtol=1e-10,atol=1e-10)

class CorrectedHistoricalTargets(HistoricalTargets):
    def labels(self,origins,refit,task):
        if not task.endswith('downturn'):return super().labels(origins,refit,task)
        continuous=task.replace('_downturn','_continuous')
        data=super().labels(origins,refit,continuous).copy()
        values=data.training_target.to_numpy(float);good=np.isfinite(values)
        threshold=-2. if task.startswith('production') else -.5
        data['training_target']=np.where(good,below_boundary(values,threshold).astype(float),np.nan)
        return data

def corrected_evaluation_truth(origins,task):
    if not task.endswith('downturn'):return original_evaluation_truth(origins,task)
    values=original_evaluation_truth(origins,task.replace('_downturn','_continuous'))
    threshold=-2. if task.startswith('production') else -.5
    return below_boundary(values,threshold).astype(float)
