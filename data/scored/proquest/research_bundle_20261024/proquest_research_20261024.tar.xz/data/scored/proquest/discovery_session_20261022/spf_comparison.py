"""External survey benchmark on exact quarterly unemployment targets."""
from common import *
import re
from backtest import frame_for_fitting, archives, ridge_predict
from proquest_descriptive import load_reference
from proquest_vintages import CORE_FEATURES
from spf_benchmark import read_xlsx_robust


def releases():
    records=[];year=None
    for line in (OUT/'reference/spf-release-dates.txt').read_text().splitlines():
        m=re.match(r'^\s*(?:(\d{4})\s+)?Q([1-4])\s+',line)
        if not m:continue
        if m[1]:year=int(m[1])
        dates=re.findall(r'\d{1,2}/\d{1,2}/\d{2,4}',line)
        if len(dates)!=2:continue
        if 1991<=year<=2010:
            q=int(m[2]);origin=pd.Period(year=year,month=q*3,freq='M')
            records.append(dict(year=year,quarter=q,origin=origin,
                                deadline=pd.to_datetime(dates[0],format='%m/%d/%y'),
                                released=pd.to_datetime(dates[1],format='%m/%d/%y')))
    result=pd.DataFrame(records)
    assert len(result)==80 and result.origin.is_unique
    result['available']=result.released<result.origin.dt.to_timestamp()
    return result


def quarterly_target(snapshot,origin):
    # Origin is the last month of survey quarter; +2Q covers months +4,+5,+6.
    months=pd.period_range(origin+4,origin+6,freq='M')
    values=snapshot.reindex(months)
    return values.mean() if values.notna().all() else np.nan


def main():
    ledger=releases();ledger.to_csv(OUT/'spf_availability_audit.csv',index=False)
    print('Excluded unavailable SPF origins:',ledger[~ledger.available].to_string(index=False),flush=True)
    f=frame_for_fitting();f=f[f.origin.dt.month.isin([3,6,9,12])].copy()
    archive=archives()['RUC'];rows=[];audit=[];params=[]
    for year in range(1991,2011):
        refit=pd.Period(f'{year}-01','M');name,snapshot=archive.snapshot(refit)
        train=f[(f.origin+9<refit)].copy()
        train['training_target']=[quarterly_target(snapshot,o)-u for o,u in zip(train.origin,train.unemployment_level)]
        train=train.dropna(subset=['training_target'])
        test=f[f.origin.dt.year.eq(year)].copy()
        assert len(train)>=60
        prediction,p=ridge_predict(train,test,list(CORE_FEATURES)+['jobs_net'],10.)
        test['macro_jobs']=test.unemployment_level+prediction
        rows.append(test[['origin','macro_jobs','unemployment_level','jobs_net']])
        params.append(p.assign(refit_year=year))
        audit.append(dict(refit_year=year,n_training=len(train),last_training_origin=train.origin.max(),
                          label_vintage=name,label_available_by=archive.dates[name],n_evaluation=len(test)))
    predicted=pd.concat(rows)
    # Historical survey forecasts and final outcomes enter only after fitting.
    spf=read_xlsx_robust(OUT/'reference/Median_UNEMP_Level.xlsx')
    spf=spf[spf.YEAR.between(1991,2010)].copy()
    spf['origin']=pd.PeriodIndex(year=spf.YEAR.astype(int),month=spf.QUARTER.astype(int)*3,freq='M')
    spf=spf[['origin','UNEMP2','UNEMP4']].rename(columns={'UNEMP4':'spf','UNEMP2':'spf_nowcast'})
    predicted=predicted.merge(spf,on='origin',validate='one_to_one').merge(ledger,on='origin',validate='one_to_one')
    predicted=predicted[predicted.available].copy()
    series,_=load_reference();predicted['truth']=[quarterly_target(series['employment'],o) for o in predicted.origin]
    predicted['equal_combination']=(predicted.spf+predicted.macro_jobs)/2
    predicted.to_csv(OUT/'spf_predictions.csv',index=False)
    pd.DataFrame(audit).to_csv(OUT/'spf_model_refits.csv',index=False)
    pd.concat(params).to_csv(OUT/'spf_model_parameters.csv',index=False)
    metrics=[]
    for model in ['spf','macro_jobs','equal_combination','unemployment_level']:
        error=predicted[model]-predicted.truth
        metrics.append(dict(model=model,n=len(predicted),mse=np.square(error).mean(),rmse=np.sqrt(np.square(error).mean()),mae=abs(error).mean(),bias=error.mean()))
    tests=[]
    for model in ['macro_jobs','equal_combination']:
        gain=(predicted.spf-predicted.truth)**2-(predicted[model]-predicted.truth)**2
        tests.append(dict(test=f'{model}_vs_spf',batch='external_spf',model=model,baseline='spf',
                          **clustered_mean(gain,np.ones(len(gain)),predicted.year,5,anchor=1991)))
    tests=adjust(pd.DataFrame(tests),2)
    tests.to_csv(OUT/'spf_tests.csv',index=False)
    pd.DataFrame(metrics).to_csv(OUT/'spf_metrics.csv',index=False)
    session=pd.read_csv(OUT/'session_wide_44_tests.csv')
    session=adjust(pd.concat([session,tests],ignore_index=True),46)
    session.to_csv(OUT/'session_wide_46_tests.csv',index=False)
    print(pd.DataFrame(metrics).to_string(index=False),flush=True)
    print(tests.to_string(index=False),flush=True)
    write_json('spf_manifest.json',dict(evaluation_n=len(predicted),excluded_unavailable=ledger[~ledger.available].origin.astype(str).tolist(),
               comparison_timing='First day of third month, SPF published strictly earlier; newspapers may contain later information than survey deadline.',
               input_sha256={str(p.relative_to(ROOT)):digest(p) for p in [OUT/'reference/Median_UNEMP_Level.xlsx',OUT/'reference/spf-release-dates.txt',OUT/'spf_specification.json',Path(__file__)]}))


if __name__=='__main__':main()
