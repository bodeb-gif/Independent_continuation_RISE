"""Read-only public ALFRED form downloads, preserving original ZIP responses."""
from pathlib import Path
import argparse
from datetime import datetime,timezone
import hashlib
import json
import urllib.parse
import urllib.request
from zipfile import ZipFile
import io

OUT=Path(__file__).resolve().parent/'reference'
URL='https://alfred.stlouisfed.org/series/downloaddata?seid=UNRATE'


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--full',action='store_true');args=parser.parse_args()
    if args.full:
        import pandas as pd
        months=pd.period_range('1960-03','2010-11',freq='M')
        dates=[str(m.end_time.date()) for m in months]
        name='alfred_UNRATE_month_end_1960_2010.zip'
    else:
        dates=['1965-11-30','1965-12-31','1976-12-31','2010-11-30'];name='alfred_UNRATE_bulk_test.zip'
    path=OUT/name
    if path.exists():raise ValueError('Preserve existing source download: '+str(path))
    payload={'form[units]':'lin','form[obs_start_date]':'1948-01-01','form[obs_end_date]':'2010-12-31',
             'form[entered_vintage_dates]':' '.join(dates),'form[file_type]':'2','form[file_format]':'csv',
             'form[download_data]':''}
    request=urllib.request.Request(URL,data=urllib.parse.urlencode(payload).encode(),headers={'User-Agent':'Economic-research-data-download/1.0'})
    with urllib.request.urlopen(request,timeout=120) as response:
        content=response.read();mime=response.headers.get('Content-Type');status=response.status
    if not content.startswith(b'PK'):
        failure=path.with_suffix('.response.html');failure.write_bytes(content)
        raise ValueError(f'Expected ZIP, received {mime}; saved diagnostic HTML')
    archive=ZipFile(io.BytesIO(content));names=archive.namelist()
    path.write_bytes(content)
    manifest={'requested_utc':datetime.now(timezone.utc).isoformat(),'url':URL,'method':'POST read-only download form',
              'payload':payload,'date_count':len(dates),'status':status,'content_type':mime,
              'sha256':hashlib.sha256(content).hexdigest(),'bytes':len(content),'members':names}
    path.with_suffix('.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({k:v for k,v in manifest.items() if k!='payload'},indent=2))


if __name__=='__main__':main()
