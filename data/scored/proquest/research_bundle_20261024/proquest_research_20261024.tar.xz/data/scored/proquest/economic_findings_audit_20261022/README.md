# Exploratory economic findings audit — October 22, 2026

Scope: annual verified ProQuest economy claims, 1900–2010. No LOC, old crisis-window exports, or modern claims enter these calculations. Source exports, human reviews, and saved model predictions are unchanged. These are retrospective exploratory checks after earlier results were inspected, not independent confirmation. All intervals condition on machine labels and outcome mappings; they do not incorporate extraction or human-review uncertainty.

## Results

1. **Average directional accuracy is 40.9%**, with a five-year block-bootstrap 95% interval of **37.4–44.7%**. This averages within article, then across 76,851 scorable articles containing 175,855 claims. The matched fixed-direction baseline is 53.6%. The previously saved paired comparison gives a gap of **−12.7 percentage points [−21.7, −3.5]** (`../target_robustness_v1/comparisons.csv`, verified/all_legacy/all_topics/article/five-year blocks). Its intervals also exclude zero using two- and ten-year blocks. This is conditional underperformance in the scored archive, not a comparison with random guessing or an estimate for every newspaper forecast. The baseline always predicts production, stocks and prices rise, and unemployment falls.

2. **Forecast disagreement slightly worsened the selected macro-plus-press model.** Across 408 held-out monthly origins (1977–2010), adding the existing forecast-polarization feature increased three-class industrial-production Brier loss from 0.62281 to 0.63034: **+0.00753**, or approximately **1.2%**. The previously saved paired bootstrap 95% interval for deterioration is **[0.00462, 0.01156]** (`../polarization/monthly_paired_intervals.csv`). The new exact block sign-flip p-value is 0.015625, or **0.046875 after Holm adjustment across the three polarization additions**. This adjusted result persists when excluding 2007–2009 and changing the block anchor. The effect is small and model-specific. This adjustment does not cover all historical model experiments, and the result is exploratory and close to the threshold.

3. **Political polarization is not a robust substantive finding here.** Adding political polarization alone increases the selected model's Brier loss by 0.03362, and adding both features increases it by 0.04156. Both have adjusted p = 0.046875 under the original seven-block design, but p = 0.078125 under the alternative eight-block design. Direct regressions also fail to establish an association between polarization and newspaper forecast accuracy: political polarization gives **+1.63 percentage points per standard deviation [−1.21, 4.47]**; forecast polarization gives **−1.35 [−3.79, 1.09]**. Neither the accuracy nor baseline-gap regression coefficients pass the five-test adjustment. A model losing accuracy when a feature is added does not show that polarization causes forecasting errors.

4. **Worsening expectations rise as recessions approach, but the adjusted evidence is insufficient.** Across the same 16 matched recessions, the average worsening-forecast share rises from **45.5%** seven to twelve months before onset to **53.1%** one to six months before onset: **+7.61 percentage points [1.99, 12.40]**. Nominal block sign-flip p = 0.02686; Holm-adjusted p = **0.13428** across the five direct-association/timing tests. Treat as suggestive, not a confirmed finding. These forecasts concern worsening conditions, not necessarily explicit recession predictions.

5. **Economic coverage frequency cannot be inferred from these exports.** There is no complete denominator of all newspaper articles or a complete retrieval/processing ledger. Raw exports represent 156,435 distinct articles versus 146,720 in verified exports, and publisher coverage changes over time. Counts of surviving economic claims cannot establish that newspapers devoted more attention to the economy in a particular period.

## Methods and reproducibility

`specification.json` records the questions, populations, weights, controls and test families. The separate saved-model checks were specified after the direct-association audit and after existing model losses were inspected. Both scripts retain null results.

Run from the repository root with Python, NumPy, pandas, SciPy and statsmodels installed:

```sh
python data/scored/proquest/economic_findings_audit_20261022/run_audit.py
python data/scored/proquest/economic_findings_audit_20261022/summarize_saved.py
```

The direct regressions use 1,068 qualifying months during 1919–2010. Claims are averaged within article and then within month; each month receives equal regression weight. Controls include topic shares, publisher shares, horizon, default-horizon share and decade effects. Both polarization features are lagged and their availability dates are checked. Primary uncertainty uses five-year calendar clusters, finite-sample corrections and a cluster-based t distribution. Two- and ten-year cluster results are also saved. Four polarization coefficients plus the warning-timing contrast form a five-test Holm family.

The saved-model check uses paired losses from existing predictions, without refitting or selecting another model. Sign-flip tests enumerate all block sign assignments, assuming independent, sign-symmetric block differences under the null. The original bootstrap code anchors its five-year blocks at 1977 (seven blocks). An initial audit implementation used a 1900 anchor (eight blocks); this was corrected to match the saved design, and the initial calculation remains in the outputs as sensitivity evidence. Results must not be generalized to every model specification or treated as a global correction for prior experimentation.

`summary.json` and `saved_checks_summary.json` record input and script SHA-256 hashes. CSVs retain the analysis data, estimates and sensitivity results. Main repository suites passed: 97 offline checks, 33 scoring checks and 33 forecast checks.
