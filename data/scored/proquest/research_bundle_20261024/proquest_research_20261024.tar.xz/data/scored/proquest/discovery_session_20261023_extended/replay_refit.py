"""Replay one saved multiplier draw without changing any sampler checkpoint."""
import argparse
from refit_multiplier_corrected import *

def run(checkpoint):
    checkpoint=Path(checkpoint).resolve()
    if not checkpoint.is_relative_to(OUT):raise ValueError('Choose a checkpoint within this research session')
    saved=json.loads(checkpoint.read_text());receipt=json.loads((checkpoint.parent/'implementation.json').read_text())
    if 'refit_multiplier_shards' in checkpoint.parts:algorithm='gru';reselect=False
    else:
        algorithm=checkpoint.parent.parent.name
        reselect=checkpoint.parent.name=='reselection_probe' or bool(receipt.get('reselect',False))
    if algorithm not in ['linear','hist_gradient_boosting','extra_trees','gru']:raise ValueError('Unknown checkpoint algorithm')
    frame,valid=feature_frame();targets=HistoricalTargets();groups=(valid.year-1977)//5
    codes=np.array(saved['block_codes'],int)
    if not np.array_equal(codes,np.unique(groups)):raise ValueError('Changed calendar')
    weights=pd.Series(np.array(saved['block_weights'],float)[np.searchsorted(codes,groups)],index=valid)
    folder=OUT/'models_boundary_corrected'/algorithm;audits={}
    for path in (folder/'annual').glob('*.json'):
        d=json.loads(path.read_text());audits[(d['task'],d['arm'],d['refit_year'])]=d
    results=[]
    for task in TASKS:
        forecasts={arm:[] for arm in ARMS}
        for year in range(1977,2011):
            cutoff=pd.Period(f'{year}-01','M');test=valid[valid.year==year]
            for arm in ARMS:
                config=select_weighted(algorithm,task,arm,frame,valid,targets,cutoff,weights) if reselect else audits[(task,arm,year)]['configuration']
                train,y,_=eligible(frame,valid,targets,cutoff,task,config['window'])
                seeds=GRID['gru']['seeds'] if algorithm=='gru' else [113]
                prediction=np.mean([predict_weighted(algorithm,task,config,frame,train,y,test,ARMS[arm],weights,seed+year)
                    for seed in seeds],axis=0)
                forecasts[arm].append(pd.Series(prediction,index=test))
        truth=evaluation_truth(pd.period_range('1977-01','2010-12',freq='M'),task);loss={}
        for arm,parts in forecasts.items():
            prediction=pd.concat(parts).sort_index();loss[arm]=(prediction.to_numpy()-truth)**2
        w=weights.reindex(pd.period_range('1977-01','2010-12',freq='M')).to_numpy(float)
        for newer,older,label in [('macro_coverage_net','macro_coverage','net_minus_macro_coverage'),
            ('macro_coverage_net_structure','macro_coverage_net','structure_minus_net')]:
            gain=float(np.average(loss[older]-loss[newer],weights=w))
            original=next(r['gain'] for r in saved['results'] if r['task']==task and r['comparison']==label)
            tolerance=2e-5 if algorithm=='gru' else 1e-8
            np.testing.assert_allclose(gain,original,rtol=tolerance,atol=tolerance)
            results.append(dict(task=task,comparison=label,replayed_gain=gain,saved_gain=original,
                absolute_error=abs(gain-original)))
    result=dict(status='passed',checkpoint=str(checkpoint.relative_to(OUT)),checkpoint_sha256=digest(checkpoint),
        algorithm=algorithm,reselection_repeated=reselect,results=results,source_check=check_sources(),
        code_sha256=digest(__file__))
    print(json.dumps(result,indent=2,default=json_default))
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('checkpoint');parser.add_argument('--audit-output')
    args=parser.parse_args()
    with threadpool_limits(limits=1):result=run(args.checkpoint)
    if args.audit_output:
        path=Path(args.audit_output).resolve()
        if not path.is_relative_to(OUT/'audits'):raise ValueError('Replay audit output must stay in this session audit folder')
        save_json(path,result)
