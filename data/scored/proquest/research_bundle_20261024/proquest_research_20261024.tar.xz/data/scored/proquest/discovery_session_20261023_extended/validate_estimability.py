"""Confirm tested coefficients are identified after every intended nuisance."""
from associations import *

def check(name,d,target,outcome,nuisance,expected,weights=None):
    a=np.asarray(target,float);y=np.asarray(outcome,float)
    z=sm.add_constant(nuisance,has_constant='add').to_numpy(float)
    w=np.ones(len(a)) if weights is None else np.asarray(weights,float)
    root=np.sqrt(w);aw=a*root;yw=y*root;zw=z*root[:,None]
    residual=aw-zw@np.linalg.lstsq(zw,aw,rcond=None)[0]
    ratio=float(np.linalg.norm(residual)/max(np.linalg.norm(aw),1e-30))
    if ratio<=1e-8:raise ValueError('Tested coefficient is not separately identified: '+name)
    coefficient=float(residual@yw/(residual@residual))
    np.testing.assert_allclose(coefficient,expected,rtol=1e-7,atol=1e-8,err_msg=name)
    return dict(test=name,n=len(d),full_nuisance_columns=z.shape[1],full_nuisance_rank=int(np.linalg.matrix_rank(zw)),
        tested_residual_norm_fraction=ratio,independent_fwl_coefficient=coefficient,saved_coefficient=expected,status='passed')

def run():
    rows=[];skipped=[]
    prefixes=['structural','joint','timing','survey','scope','productivity','common_information','term_direction_curve']
    for prefix in prefixes:
        tests=pd.read_csv(OUT/(prefix+'_tests.csv'));sample=pd.read_csv(OUT/'audits'/(prefix+'_analysis_rows.csv.gz'))
        for row in tests.to_dict('records'):
            if row.get('status')!='estimated':skipped.append(dict(test=row['test'],status=row.get('status')));continue
            d=sample[sample.test.eq(row['test'])].copy() if 'test' in sample else sample[sample.topic.eq(row['topic'])].copy()
            feature=row.get('feature');outcome=row.get('outcome')
            if prefix=='timing':feature,outcome='cross_topic_gap','future_minus_recent'
            if prefix=='scope':feature='scope_net'
            if prefix=='productivity':feature,outcome='activity_labor_gap','outcome'
            if len(d)!=row['n']:raise ValueError('Saved analysis support mismatch '+row['test'])
            # estimate() exports only requested raw feature/outcome/controls,
            # year and the standardized tested variable. Union-only fields from
            # other questions are all-missing in this question and excluded.
            controls=[c for c in d if pd.api.types.is_numeric_dtype(d[c]) and d[c].notna().all()
                and c not in [feature,outcome,'year','tested_predictor']]
            nuisance=pd.concat([d[controls].astype(float),pd.get_dummies(d.year//10*10,drop_first=True,dtype=float)],axis=1)
            rows.append(check(row['test'],d,d.tested_predictor,d[outcome],nuisance,row['effect']))
    # Three cross-topic component coefficients were conservatively added to the
    # family, even though they interpret the same original gap relationship.
    sample=pd.read_csv(OUT/'audits/cross_topic_analysis_rows.csv.gz')
    tests=pd.read_csv(OUT/'cross_topic_robustness.csv')
    for topic in ['general_business','markets','prices']:
        variant='conditional_component_'+topic
        row=tests[tests.source_set.eq('verified')&tests.variant.eq(variant)&tests.block_years.eq(5)].iloc[0]
        d=sample[sample.source_set.eq('verified')&sample.variant.eq(variant)].copy()
        controls=['net_direction','net_squared','flat_share','log_articles','n_papers']
        controls += [t+'_net' for t in ['general_business','markets','prices'] if t!=topic]
        nuisance=pd.concat([d[controls],pd.get_dummies(d.year//10*10,drop_first=True,dtype=float)],axis=1)
        rows.append(check('cross_component_'+topic,d,d.tested_predictor,d.employment_growth,nuisance,row.effect))
    tests=pd.read_csv(OUT/'election_tests.csv')
    sample=pd.read_csv(OUT/'audits/election_analysis_rows.csv.gz')
    for row in tests.to_dict('records'):
        if row['status']!='estimated':skipped.append(dict(test=row['test'],status=row['status']));continue
        d=sample[sample.test.eq(row['test'])].copy();parts=[]
        for column in ['paper','year','calendar_month','horizon_used','horizon_basis']:
            parts.append(pd.get_dummies(d[column],prefix=column,drop_first=True,dtype=float))
        nuisance=pd.concat(parts,axis=1)
        rows.append(check(row['test'],d,d.preelection,d.difference,nuisance,row['effect'],d.weight))
    tests=pd.read_csv(OUT/'conditional_credibility_tests.csv')
    sample=pd.read_csv(OUT/'audits/conditional_credibility_analysis_rows.csv.gz')
    conditions=['prior_log_epu','prior_rollcall_polarization']
    for row in tests.to_dict('records'):
        if row['status']!='estimated':skipped.append(dict(test=row['test'],status=row['status']));continue
        d=sample[sample.test.eq(row['test'])].copy();condition=row['condition']
        extra='voice' if row['contrast']=='assertive_minus_hedged' else 'confidence'
        other=next(c for c in conditions if c!=condition)
        parts=[d[[other]].astype(float)]
        for column in ['paper','calendar_month','horizon_used','horizon_basis',extra]:
            parts.append(pd.get_dummies(d[column],prefix=column,drop_first=True,dtype=float))
        parts.append(pd.get_dummies(d.year//10*10,drop_first=True,dtype=float))
        target=(d[condition]-d[condition].mean())/d[condition].std()
        rows.append(check(row['test'],d,target,d.difference,pd.concat(parts,axis=1),row['effect'],d.weight))
    pd.DataFrame(rows).to_csv(OUT/'audits/estimability_checks.csv',index=False)
    save_json(OUT/'audits/estimability_validation.json',dict(status='passed',estimated_association_tests_checked=len(rows),
        unsupported_retained=skipped,checks='Residualize each tested coefficient against the full intended nuisance span before any rank-pruning, including redundant nuisance columns. Independent Frisch-Waugh-Lovell coefficients reproduce reported coefficients. Weighted least squares is whitened for the check.',
        minimum_residual_norm_fraction=min(r['tested_residual_norm_fraction'] for r in rows),
        code_sha256=digest(__file__),source_check=check_sources()))
    journal('validation','Full-nuisance estimability and independentFWL checks passed',tests=len(rows),unsupported=len(skipped))
    print('PASS',len(rows),'estimated association tests;',len(skipped),'unsupported tests retained.')

if __name__=='__main__':run()
