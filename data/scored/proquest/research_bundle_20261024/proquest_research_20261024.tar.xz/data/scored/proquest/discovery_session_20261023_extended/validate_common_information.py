"""Independent SVD reconstruction of the chronologically built source factor."""
from common_information import print_wide
from boundary_rules import *

def run():
    checks=[];records=[]
    for source in ['verified','raw']:
        wide=print_wide(source);other=['general_business','markets','prices']
        load=pd.read_csv(OUT/'audits'/f'pca_loadings_{source}.csv');load['origin']=pd.PeriodIndex(load.origin,freq='M')
        if not (pd.PeriodIndex(load.latest_training_origin,freq='M')<load.origin).all():
            raise ValueError('Future source vector in factor training')
        stored=pd.read_csv(OUT/'cache'/f'common_information_panel_{source}.csv.gz')
        stored['origin']=pd.PeriodIndex(stored.origin,freq='M');stored=stored.set_index('origin')
        for text in ['1955-01','1975-01','1995-01','2010-10']:
            origin=pd.Period(text,'M')
            if origin not in stored.index or not np.isfinite(stored.loc[origin,'pca_factor']):continue
            past=wide.loc[wide.index<origin,other].dropna()
            a=past.to_numpy(float);mean=a.mean(0);scale=a.std(0,ddof=0);scale=np.where(scale>0,scale,1.)
            z=(a-mean)/scale
            _,singular,right=np.linalg.svd(z,full_matrices=False)
            vector=right[0]* (1. if right[0,0]>=0 else -1.)
            factor=float(((wide.loc[origin,other].to_numpy(float)-mean)/scale)@vector)
            np.testing.assert_allclose(factor,stored.loc[origin,'pca_factor'],rtol=0,atol=1e-10)
            y=wide.loc[past.index,'employment'];ok=y.notna().to_numpy()
            training_factor=z@vector;X=np.column_stack([np.ones(ok.sum()),training_factor[ok]])
            coef=np.linalg.lstsq(X,y.to_numpy(float)[ok],rcond=None)[0]
            residual=float(wide.loc[origin,'employment']-coef@[1.,factor])
            np.testing.assert_allclose(residual,stored.loc[origin,'employment_residual'],rtol=0,atol=1e-10)
            records.append(dict(source_set=source,origin=origin,training_months=len(past),
                factor_error=factor-stored.loc[origin,'pca_factor'],residual_error=residual-stored.loc[origin,'employment_residual']))
        checks.append(source+': every factor loading date precedes its origin; independent NumPy SVD and least squares reproduce sampled current factors/residuals.')
    frame,valid=feature_frame();targets=CorrectedHistoricalTargets();audits=[]
    for task in TASKS:
        for year in range(1977,2011):
            cutoff=pd.Period(f'{year}-01','M');train,y,label=eligible(frame,valid,targets,cutoff,task)
            assert (train+8<cutoff).all()
            audits.append(dict(task=task,refit=str(cutoff),n_training=len(train),
                first_training=str(train.min()),last_training=str(train.max()),
                label_vintage=label.label_vintage.iloc[0],label_available_by=label.label_available_by.iloc[0],
                last_endpoint=label.target_end.max(),mean_training_target=y.mean()))
    pd.DataFrame(audits).to_csv(OUT/'audits/model_label_availability_corrected.csv',index=False)
    checks.append('Canonical corrected model-label availability audit rebuilt for all136 task/year refits.')
    save_json(OUT/'audits/common_information_validation.json',dict(status='passed',checks=checks,
        reconstruction=records,source_count=check_sources(),code_sha256=digest(__file__)))
    for item in checks:print('PASS',item)

if __name__=='__main__':run()
