"""Bounded local compute monitor; exits at the requested ten-hour boundary."""
import subprocess
import time
from session_utils import *

def snapshot():
    state=json.loads((OUT/'session.json').read_text());now=dt.datetime.now(dt.timezone.utc)
    samplers=[]
    for algorithm in ['linear','hist_gradient_boosting','extra_trees','gru']:
        paths=[OUT/'models_boundary_corrected'/algorithm/'refit_multiplier']
        if algorithm=='gru':paths+=sorted((OUT/'models_boundary_corrected/gru/refit_multiplier_shards').glob('shard_*'))
        for path in paths:
            status=json.loads((path/'status.json').read_text()) if (path/'status.json').exists() else {}
            files=[p for p in path.glob('draw_*.json') if json.loads(p.read_text())['draw']>=0]
            latest=max((p.stat().st_mtime for p in files),default=(path/'implementation.json').stat().st_mtime)
            age=now.timestamp()-latest
            samplers.append(dict(algorithm=algorithm,sampler=path.name,status=status.get('status','initializing'),
                completed_draws=len(files),minutes_since_checkpoint=age/60,
                inspect_if_no_recent_checkpoint=bool(age>1800 and status.get('status') not in ['complete','time_limited'])))
    result=subprocess.run(['ps','-Ao','pid,etime,time,%cpu,rss,args'],capture_output=True,text=True,timeout=10)
    lines=[]
    for line in result.stdout.splitlines()[1:]:
        parts=line.strip().split(None,5)
        if len(parts)==6 and str(OUT.name) in parts[5] and ('/python ' in parts[5] or '/python3 ' in parts[5]):
            lines.append(dict(pid=parts[0],elapsed=parts[1],cpu_time=parts[2],cpu_percent=parts[3],rss_kb=parts[4],command=parts[5]))
    return dict(updated_utc=now,status='running',
        elapsed_wall_hours=(now-dt.datetime.fromisoformat(state['start_utc'])).total_seconds()/3600,
        minimum_end_utc=state['minimum_end_utc'],samplers=samplers,processes=lines)

def run():
    folder=OUT/'monitor';folder.mkdir(exist_ok=True)
    end=dt.datetime.fromisoformat(json.loads((OUT/'session.json').read_text())['minimum_end_utc'])
    save_json(folder/'implementation.json',dict(code_sha256=digest(__file__),ends_at=end,
        role='Local status/source integrity monitoring during the authorized session. No model settings, results or hypotheses are changed.'))
    last_notice=None;last_source=-1
    while dt.datetime.now(dt.timezone.utc)<end:
        item=snapshot();now=dt.datetime.now(dt.timezone.utc);slot=int(now.timestamp()//900)
        if last_notice!=slot:
            check_sources();item['source_hashes_unchanged']=225
            print(now.isoformat(),'elapsed',round(item['elapsed_wall_hours'],2),'hours',
                [(r['algorithm'],r['sampler'],r['completed_draws'],r['status']) for r in item['samplers']],flush=True)
            journal('compute_monitor','Recorded active scheduled model computations and source integrity',
                elapsed_wall_hours=item['elapsed_wall_hours'],
                samplers=[{k:r[k] for k in ['algorithm','sampler','completed_draws','status']} for r in item['samplers']])
            last_notice=slot
        save_json(folder/'status.json',item)
        remaining=(end-dt.datetime.now(dt.timezone.utc)).total_seconds()
        if remaining>0:time.sleep(min(30,remaining))
    item=snapshot();item['status']='minimum_duration_reached';item['source_hashes_unchanged']=check_sources()
    save_json(folder/'status.json',item)
    journal('compute_monitor','Requested ten-hour boundary reached; final review still required')
    print('Minimum duration reached',dt.datetime.now(dt.timezone.utc).isoformat(),flush=True)

if __name__=='__main__':run()
