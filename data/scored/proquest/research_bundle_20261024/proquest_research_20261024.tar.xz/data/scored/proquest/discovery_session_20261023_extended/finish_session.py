"""Finalize only after the full requested duration and all closing checks."""
import re
import subprocess
from session_utils import *
from validate_saved_inputs import verify_frozen_inputs

SCIENCE_PYTHON='/opt/anaconda3/bin/python3'
ML_PYTHON='/private/tmp/proquest-ml-20261023/bin/python'

def command(script,log,extra=(),timeout=180,python=SCIENCE_PYTHON):
    args=[python,str(script),*extra]
    result=subprocess.run(args,cwd=ROOT,capture_output=True,text=True,timeout=timeout)
    (OUT/'logs'/log).write_text(result.stdout+result.stderr)
    if result.returncode:raise ValueError(f'Closing check failed: {script}; see logs/{log}')
    return result.stdout+result.stderr

def final_checks():
    state=json.loads((OUT/'session.json').read_text());now=dt.datetime.now(dt.timezone.utc)
    end=dt.datetime.fromisoformat(state['minimum_end_utc'])
    if now<end:raise ValueError('Refuse early finalization: full ten-hour minimum not reached')
    monitor=json.loads((OUT/'monitor/status.json').read_text())
    if monitor['status']!='minimum_duration_reached':raise ValueError('Wait for the bounded compute monitor to close')
    check_sources();frozen_dependencies=verify_frozen_inputs(check_runtime=False)
    statuses=[];input_checks={}
    for algorithm in ['linear','hist_gradient_boosting','extra_trees','gru']:
        root=OUT/'models_boundary_corrected'/algorithm
        completion=json.loads((root/'completion.json').read_text())
        if completion['status']!='complete':raise ValueError('Incomplete canonical model')
        for name,expected in completion['input_hashes'].items():
            if digest(ROOT/name)!=expected:raise ValueError('Canonical model input changed: '+name)
            input_checks[name]=expected
        paths=[root/'refit_multiplier']
        if algorithm=='gru':paths+=sorted((root/'refit_multiplier_shards').glob('shard_*'))
        for path in paths:
            status=json.loads((path/'status.json').read_text())
            if status['status'] not in ['complete','time_limited']:raise ValueError('Sampler still active or failed: '+str(path))
            statuses.append(dict(path=str(path.relative_to(OUT)),**status))
    probe=OUT/'models_boundary_corrected/hist_gradient_boosting/reselection_probe'
    if json.loads((probe/'status.json').read_text())['status'] not in ['complete','time_limited']:
        raise ValueError('Fully nested probe still active')
    neural_probe=OUT/'models_boundary_corrected/gru/reselection_probe'
    neural_status=json.loads((neural_probe/'status.json').read_text())
    if neural_status['status'] not in ['complete','time_limited']:
        raise ValueError('Paired neural reselection audit still active or failed')
    if neural_status['completed_draws']:
        if json.loads((neural_probe/'uniform_reproduction.json').read_text())['status']!='passed':
            raise ValueError('Neural reselection uniform check failed')
    command(OUT/'hgb_probe_counterfactual.py','hgb_probe_counterfactual_final.log',timeout=1200,python=ML_PYTHON)
    # The paired counterfactual uses sklearn; use the exact ML environment,
    # rather than silently accepting another installed estimator version.
    target_manifest=json.loads((OUT/'audits/model_input_manifest.json').read_text())
    for name,expected in target_manifest['target_archive_hashes'].items():
        if digest(ROOT/name)!=expected:raise ValueError('Historical target archive changed: '+name)
        input_checks[name]=expected
    return dict(unchanged_canonical_input_hashes=input_checks,sampler_statuses=statuses,
        neural_reselection_probe=neural_status,frozen_model_dependencies=frozen_dependencies)

def run():
    # This guard also protects against accidental use before the deadline.
    state=json.loads((OUT/'session.json').read_text())
    if dt.datetime.now(dt.timezone.utc)<dt.datetime.fromisoformat(state['minimum_end_utc']):
        raise ValueError('Full requested ten-hour duration has not elapsed')
    input_audit=final_checks()
    compile_result=subprocess.run([SCIENCE_PYTHON,'-m','compileall','-q',str(OUT)],capture_output=True,text=True,timeout=120)
    (OUT/'logs/compile_final.log').write_text(compile_result.stdout+compile_result.stderr)
    if compile_result.returncode:raise ValueError('Research code compilation failed')
    tests=[]
    plans=[('test_offline.py','ALL 97 CHECKS PASSED',97),('test_scoring.py','33 passed, 0 failed',33),('test_forecasts.py','33 passed, 0 failed',33)]
    for name,signature,count in plans:
        output=command(ROOT/'tests'/name,name.replace('.py','_final.log'))
        if signature not in output:raise ValueError('Unexpected test summary '+name)
        tests.append(dict(suite='tests/'+name,checks=count,status='passed'))
    command(OUT/'collect_results.py','collect_final.log')
    ledger=json.loads((OUT/'audits/ledger_status.json').read_text())
    closed=json.loads((OUT/'specs/family_closed.json').read_text())
    if ledger['pending_new_tests'] or ledger['pooled_family']!=closed['pooled_tests']:
        raise ValueError('Unfinished or changed discovery family')
    new_questions=pd.read_csv(OUT/'extension_current_tests.csv')
    if set(new_questions.test)!=set(closed['test_names']):
        raise ValueError('Closed discovery-family questions changed')
    command(OUT/'summarize_refits.py','summarize_refits_final.log')
    command(OUT/'refit_range_figure.py','refit_range_figure_final.log')
    audit_names=['validation_initial','boundary_validation','no_leakage_validation',
        'common_information_validation','direct_source_validation','estimability_validation',
        'safe_runner_guard_validation','gru_saved_draw_replay','linear_saved_draw_replay',
        'hgb_saved_draw_replay','extra_trees_saved_draw_replay','leading_tail_validation',
        'gru_seed_reconstruction_validation','saved_model_inputs_validation',
        'election_wls_validation']
    independent_audits={name:json.loads((OUT/'audits'/(name+'.json')).read_text())
        for name in audit_names}
    if any(a.get('status')!='passed' for a in independent_audits.values()):
        raise ValueError('An independent audit has not passed')
    seed_audit=json.loads((OUT/'gru_seed_diagnostics/status.json').read_text())
    if seed_audit.get('status')!='complete':raise ValueError('Neural-seed accounting is incomplete')
    validation=dict(status='passed',completed_utc=dt.datetime.now(dt.timezone.utc),tests=tests,
        required_test_checks=sum(t['checks'] for t in tests),source_hashes_unchanged=check_sources(),
        direct_source_audit=json.loads((OUT/'audits/direct_source_validation.json').read_text()),
        estimability_audit=json.loads((OUT/'audits/estimability_validation.json').read_text()),
        independent_audits=independent_audits,neural_seed_accounting=seed_audit,
        canonical_input_audit=input_audit,declared_family=ledger)
    save_json(OUT/'audits/final_validation.json',validation)
    state.update(status='complete',completed_utc=dt.datetime.now(dt.timezone.utc),
        elapsed_wall_hours=(dt.datetime.now(dt.timezone.utc)-dt.datetime.fromisoformat(state['start_utc'])).total_seconds()/3600,
        phase='Completed full-duration investigation; findings remain exploratory and inference-sensitive',
        final_validation='audits/final_validation.json')
    save_json(OUT/'session.json',state)
    command(OUT/'make_report.py','report_build_final.log')
    command(OUT/'render_report_review.py','report_render_final.log',timeout=120)
    journal('session','Completed the requested full-duration investigation and closing checks',
        elapsed_wall_hours=state['elapsed_wall_hours'],required_test_checks=validation['required_test_checks'],
        primary_questions=ledger['planned_new_tests'],pooled_family=ledger['pooled_family'])
    # Final manifest excludes itself and bytecode; no source export is rewritten.
    outputs={str(p.relative_to(OUT)):digest(p) for p in sorted(OUT.rglob('*'))
        if p.is_file() and '__pycache__' not in p.parts and p.name!='final_manifest.json'}
    dependencies=[PRIOR/'continuous_targets.csv',PRIOR/'phase2/fresh_core_forecast_features.csv',
        PRIOR/'session_wide_68_tests.csv',PRIOR/'reference/alfred_UNRATE_month_end_1960_2010.zip',
        PRIOR/'reference/alfred_UNRATE_month_end_1960_2010.manifest.json',PRIOR/'external_tone_monthly.csv',
        PRIOR/'reference/US_Policy_Uncertainty_Data.xlsx',PRIOR/'primary_manifest.json',
        BASE/'macro_information/IPT_vintages_through_2010.csv.gz',BASE/'macro_information/reference/iptMvMd.xlsx',
        BASE/'descriptive/scored_claims.csv.gz',BASE/'robustness/scored_claims.csv.gz',BASE/'polarization/features.csv']
    dependencies += list((ROOT/'data/reference/proquest').glob('*'))
    dependencies += [ROOT/'src'/name for name in ['analyze_proquest.py','proquest_vintages.py','proquest_descriptive.py','proquest_panel.py','score_predictions.py']]
    save_json(OUT/'final_manifest.json',dict(created_utc=dt.datetime.now(dt.timezone.utc),
        status='complete',elapsed_wall_hours=state['elapsed_wall_hours'],source_exports_unchanged=222,
        original_source_hashes=json.loads((OUT/'audits/initial_source_hashes.json').read_text()),
        additional_dependency_final_snapshot={str(p.relative_to(ROOT)):digest(p) for p in dependencies if p.is_file()},
        derived_files=outputs,n_derived_files=len(outputs),
        limits='A completed exploratory research session is not a confirmed unique discovery. Primary significance is sensitive to block placement/covariance method; source semantics and independent validation remain unresolved.'))
    print('Completed',state['elapsed_wall_hours'],'hours;',ledger['planned_new_tests'],'new questions;',validation['required_test_checks'],'required software checks passed')

if __name__=='__main__':run()
