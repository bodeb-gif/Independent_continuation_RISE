"""Read atomic model-refit checkpoints without changing running samplers."""
from session_utils import *

ALGORITHMS=['linear','hist_gradient_boosting','extra_trees','gru']

def rank_interval(values,p,alpha=.05):
    v=np.sort(np.asarray(values,float));n=len(v)
    lo=int(st.binom.ppf(alpha/2,n,p));hi=int(st.binom.ppf(1-alpha/2,n,p))+1
    return dict(lower_rank=lo,upper_rank=hi,
        lower_value=float(v[lo-1]) if lo>=1 else None,
        upper_value=float(v[hi-1]) if hi<=n else None,
        lower_unbounded=lo==0,upper_unbounded=hi>n)

def run():
    folder=OUT/'refit_summary';folder.mkdir(exist_ok=True);rows=[];records=[];summaries=[]
    for algorithm in ALGORITHMS:
        root=OUT/'models_boundary_corrected'/algorithm
        samplers=[('main',root/'refit_multiplier')]
        if algorithm=='gru':samplers += [(p.name,p) for p in sorted((root/'refit_multiplier_shards').glob('shard_*'))]
        weight_hashes=set()
        for sampler,path in samplers:
            uniform=path/'uniform_reproduction.json'
            if not uniform.exists():
                records.append(dict(algorithm=algorithm,sampler=sampler,status='uniform_check_pending',draws=0));continue
            if json.loads(uniform.read_text())['status']!='passed':raise ValueError('Uniform check failed')
            inputs=json.loads((path/'implementation.json').read_text())
            if inputs.get('session_utils_sha256')!=digest(OUT/'session_utils.py'):raise ValueError('Changed shared inference code')
            if inputs.get('boundary_rules_sha256')!=digest(OUT/'boundary_rules.py'):raise ValueError('Changed boundaries')
            # Original and shard receipts use distinct names for the same frozen forecasts.
            expected=inputs.get('model_predictions_sha256',inputs.get('predictions_sha256'))
            if expected!=digest(root/'predictions_without_truth.csv'):raise ValueError('Changed canonical predictions')
            if sampler=='main' and inputs['code_sha256']!=digest(OUT/'refit_multiplier_corrected.py'):
                raise ValueError('Changed sampler')
            if sampler!='main' and inputs['code_sha256']!=digest(OUT/'gru_refit_shard.py'):
                raise ValueError('Changed shard')
            if sampler!='main' and inputs['canonical_sampler_sha256']!=digest(OUT/'refit_multiplier_corrected.py'):
                raise ValueError('Changed canonical sampler used by shard')
            completed=0
            for checkpoint in sorted(path.glob('draw_*.json')):
                d=json.loads(checkpoint.read_text())
                if d['draw']<0:continue
                if len(d['results'])!=8 or not np.isfinite(d['block_weights']).all() or not (np.asarray(d['block_weights'])>0).all():
                    raise ValueError('Incomplete or invalid draw')
                key=hashlib.sha256(np.asarray(d['block_weights'],dtype='<f8').tobytes()).hexdigest()
                if key in weight_hashes:raise ValueError('Duplicate multiplier weights across samplers')
                weight_hashes.add(key);completed+=1
                for r in d['results']:rows.append(dict(**r,sampler=sampler))
            status=json.loads((path/'status.json').read_text()) if (path/'status.json').exists() else {}
            records.append(dict(algorithm=algorithm,sampler=sampler,status=status.get('status','unknown'),draws=completed,
                selection_repeated=bool(inputs.get('reselect',False)),maximum_draws=inputs.get('maximum_draws',status.get('maximum_draws'))))
    f=pd.DataFrame(rows)
    if len(f):
        if f.duplicated(['algorithm','sampler','draw','task','comparison']).any():raise ValueError('Duplicated draw/test rows')
        for (algorithm,task,comparison),g in f.groupby(['algorithm','task','comparison']):
            v=g.gain.to_numpy(float);n=len(v);positive=int((v>0).sum())
            p=positive/n;lo=st.beta.ppf(.025,positive,n-positive+1) if positive else 0.
            hi=st.beta.ppf(.975,positive+1,n-positive) if positive<n else 1.
            qlow=rank_interval(v,.025);qhigh=rank_interval(v,.975)
            summaries.append(dict(algorithm=algorithm,task=task,comparison=comparison,draws=n,
                mean=v.mean(),median=np.median(v),low=np.quantile(v,.025),high=np.quantile(v,.975),
                positive_fraction=p,positive_fraction_mc_low=lo,positive_fraction_mc_high=hi,
                low_quantile_mc_lower=qlow['lower_value'],low_quantile_mc_upper=qlow['upper_value'],
                low_quantile_mc_lower_unbounded=qlow['lower_unbounded'],
                high_quantile_mc_lower=qhigh['lower_value'],high_quantile_mc_upper=qhigh['upper_value'],
                high_quantile_mc_upper_unbounded=qhigh['upper_unbounded']))
        f.to_csv(folder/'all_completed_draws.csv',index=False)
        pd.DataFrame(summaries).to_csv(folder/'ranges.csv',index=False)
    pd.DataFrame(records).to_csv(folder/'samplers.csv',index=False)
    save_json(folder/'manifest.json',dict(updated_utc=dt.datetime.now(dt.timezone.utc),
        status='snapshot; original sampler statuses retained separately',
        counts={a:len({(r['sampler'],r['draw']) for r in rows if r['algorithm']==a}) for a in ALGORITHMS},
        interpretation='Positive block-multiplier ranges are conditional reweighting diagnostics. Linear repeats inner selection; other families hold selected settings fixed. GRU always averages all3 seeds. Fractions and rank intervals quantify Monte Carlo variation, not a p-value or posterior probability that an economic effect is true. Binomial and rank precision intervals are fixed-count reference calculations; the time-budgeted runs do not supply time-uniform coverage guarantees.',
        code_sha256=digest(__file__),source_check=check_sources()))
    print(pd.DataFrame(records).to_string(index=False))

if __name__=='__main__':run()
