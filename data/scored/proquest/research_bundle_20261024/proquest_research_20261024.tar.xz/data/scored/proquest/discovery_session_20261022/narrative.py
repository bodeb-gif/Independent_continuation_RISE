"""Second fixed exploratory family: numerical claims, quoting, recovery narratives."""
from common import *
from analyze_proquest import annual_files


def add_metadata(frame,source_set):
    rows=[];hashes={}
    for path in annual_files(ROOT/'data/proquest'/source_set):
        hashes[str(path.relative_to(ROOT))]=digest(path)
        year=int(path.name.split('_')[-1].split('.')[0])
        for number,line in enumerate(path.open(),1):
            if not line.strip():continue
            r=json.loads(line)
            if r.get('no_predictions'):continue
            rows.append(dict(record_id=f'{year}:{number}',page_id_check=str(r['page_id']),
                             current_state=r.get('current_state'),quoted=r.get('is_quoted_forecaster'),
                             numeric=r.get('quote_has_number'),quote_words=r.get('quote_n_words')))
    meta=pd.DataFrame(rows)
    assert len(meta)==len(frame)
    result=frame.merge(meta,on='record_id',validate='one_to_one')
    assert result.page_id.eq(result.page_id_check).all()
    result['month']=pd.PeriodIndex(pd.to_datetime(result.date),freq='M')
    # Exact stored categories only; unexpected/missing codes are not invented.
    result['numeric']=pd.to_numeric(result.numeric,errors='coerce')
    return result.drop(columns='page_id_check'),hashes


def cells_for(frame,field,left,right,topic,recovery=False,minimum=2):
    d=frame[frame.hit.notna()&frame.basis.ne('NBER proxy')&frame.topic.eq(topic)&frame[field].isin([left,right])].copy()
    if recovery:d=d[d.current_state.eq('bad')]
    keys=['paper','month','topic','basis','horizon_basis','horizon_used','voice','confidence']
    a=d.groupby(keys+[field,'page_id']).agg(hit=('hit','mean'),claims=('hit','size')).reset_index()
    c=a.groupby(keys+[field]).agg(hit=('hit','mean'),articles=('page_id','size'),claims=('claims','sum')).reset_index()
    l=c[c[field].eq(left)].drop(columns=field);r=c[c[field].eq(right)].drop(columns=field)
    both=l.merge(r,on=keys,suffixes=('_left','_right'),validate='one_to_one')
    both=both[(both.articles_left>=minimum)&(both.articles_right>=minimum)].copy()
    both['difference']=both.hit_left-both.hit_right
    both['weight']=2*both.articles_left*both.articles_right/(both.articles_left+both.articles_right)
    both['year']=both.month.dt.year
    return both


def state_panel(frame):
    f=frame[frame.scope.eq('national')&frame.topic.eq('general_business')&frame.predicted_norm.isin(['improve','worsen','flat'])].copy()
    f['bad']=f.current_state.eq('bad').astype(float)
    f['observed_state']=f.current_state.isin(['good','bad','mixed']).astype(float)
    a=f.groupby(['month','paper','page_id'])[['bad','observed_state']].mean()
    p=a.groupby(['month','paper']).mean()
    n=p.groupby('month').mean().reindex(pd.period_range('1900-01','2010-12',freq='M'))
    rows=[]
    for origin in n.index:
        window=n.reindex(pd.period_range(origin-3,origin-1,freq='M'))
        rows.append(dict(origin=origin,bad_state_3m=window.bad.mean(),stated_state_3m=window.observed_state.mean()))
    return pd.DataFrame(rows)


def main():
    frame=pd.read_csv(BASE/'descriptive/scored_claims.csv.gz',dtype={'page_id':str})
    f,hashes=add_metadata(frame,'verified')
    f.to_csv(OUT/'claims_with_print_metadata.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    rows=[];sens=[]
    for field,left,right in [('numeric',1,0),('quoted',True,False)]:
        for topic in ['general_business','markets','prices','employment']:
            name=f'{field}_{topic}';c=cells_for(f,field,left,right,topic)
            c.to_csv(OUT/f'cells_{name}.csv',index=False)
            if c.empty:
                rows.append(dict(test=name,p_value=1.,status='no common support'));continue
            result=clustered_mean(c.difference,c.weight,c.year)
            rows.append(dict(test=name,kind='matched_narrative',left_rate=np.average(c.hit_left,weights=c.weight),right_rate=np.average(c.hit_right,weights=c.weight),**result))
            for span in [2,10]:sens.append(dict(test=name,block_years=span,**clustered_mean(c.difference,c.weight,c.year,span)))
    c=cells_for(f,'predicted_norm','improve','worsen','general_business',recovery=True)
    c.to_csv(OUT/'cells_bad_state_recovery.csv',index=False)
    result=clustered_mean(c.difference,c.weight,c.year)
    rows.append(dict(test='bad_state_recovery_vs_continuation',kind='matched_narrative',left_rate=np.average(c.hit_left,weights=c.weight),right_rate=np.average(c.hit_right,weights=c.weight),**result))
    state=state_panel(f);state.to_csv(OUT/'bad_state_panel.csv',index=False)
    signal=pd.read_csv(OUT/'lagged_topic_signals.csv');signal['origin']=pd.PeriodIndex(signal.origin,freq='M')
    signal=signal[signal.topic.eq('general_business')]
    truth=pd.read_csv(OUT/'continuous_targets.csv');truth['origin']=pd.PeriodIndex(truth.origin,freq='M')
    d=signal.merge(state,on='origin').merge(truth.drop(columns='year'),on='origin')
    d['log_articles']=np.log1p(d.articles)
    d['tested_predictor']=(d.bad_state_3m-d.bad_state_3m.mean())/d.bad_state_3m.std()
    for span in [2,5,10]:
        result,_,used=regression(d,'general_business_growth',['tested_predictor'],['net_direction','flat_share','log_articles','papers'],span)
        record=dict(test='bad_state_future_output',kind='monthly_association',block_years=span,**result[0])
        if span==5:rows.append(record)
        else:sens.append(record)
    used.to_csv(OUT/'months_bad_state_output.csv',index=False)
    assert len(rows)==10
    result=adjust(pd.DataFrame(rows),10);result.to_csv(OUT/'narrative_results.csv',index=False)
    pd.DataFrame(sens).to_csv(OUT/'narrative_block_sensitivities.csv',index=False)
    primary=pd.read_csv(OUT/'primary_results.csv').assign(batch='primary_direct')
    backtest=pd.read_csv(OUT/'backtest_tests_alpha10.csv').assign(batch='vintage_backtest')
    backtest['test']=backtest.task+'_'+backtest.model+'_vs_'+backtest.baseline
    pooled=adjust(pd.concat([primary,backtest,result.assign(batch='narrative')],ignore_index=True),44)
    pooled.to_csv(OUT/'session_wide_44_tests.csv',index=False)
    write_json('narrative_manifest.json',dict(verified_sources=hashes,source_fields_used=['current_state','is_quoted_forecaster','quote_has_number','quote_n_words'],forbidden_fields_used=[],n_tests=10,session_n_tests=44))
    print(result[['test','effect','low','high','p_value','holm_p','n','n_blocks']].sort_values('p_value').to_string(index=False),flush=True)
    print('Session-wide survivors:',flush=True)
    print(pooled[pooled.holm_p<.05][['test','effect','low','high','p_value','holm_p']].to_string(index=False),flush=True)


if __name__=='__main__':main()
