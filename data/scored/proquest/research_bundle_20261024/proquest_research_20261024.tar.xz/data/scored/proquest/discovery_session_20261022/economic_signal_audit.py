"""Fixed robustness diagnostics for the already inspected economic signals.

No new discovery hypothesis: dates, outcome windows, era exclusions, temporal
leave-outs and signal smoothing challenge the same three associations. Every
variant is retained. These intervals are pointwise and post hoc.
"""
from common import *
from robust_monthly import readable, topic_signals
from proquest_descriptive import load_reference


def window_signals(national,topic,window):
    m=national[national.topic.eq(topic)].set_index('month')
    records=[]
    for origin in pd.period_range('1900-01','2010-12',freq='M'):
        w=m.reindex(pd.period_range(origin-window,origin-1,freq='M'))
        minimum=1 if window==1 else 2 if window==3 else 4
        adequate=(w.n_articles>0).sum()>=minimum and w.n_papers.max()>=2 and w.n_articles.sum()>=5
        records.append(dict(origin=origin,topic=topic,year=origin.year,articles=w.n_articles.sum(),papers=w.n_papers.mean(),
                            net_direction=w.net_direction.mean() if adequate else np.nan,flat_share=w.flat_share.mean() if adequate else np.nan))
    return pd.DataFrame(records)


def main():
    saved=pd.read_csv(OUT/'lagged_topic_signals.csv');saved['origin']=pd.PeriodIndex(saved.origin,freq='M')
    truth=pd.read_csv(OUT/'continuous_targets.csv');truth['origin']=pd.PeriodIndex(truth.origin,freq='M')
    national=national_panel();series,_=load_reference();rows=[];binrows=[];blocks=[]
    raw=pd.read_csv(BASE/'robustness/scored_claims.csv.gz',dtype={'page_id':str});raw=readable(raw[raw.source_set.eq('raw')])
    verified=readable(pd.read_csv(BASE/'descriptive/scored_claims.csv.gz',dtype={'page_id':str}))
    plans=[('employment','employment_growth','employment_to_unemployment'),
           ('general_business','general_business_growth','business_to_output'),
           ('markets','general_business_growth','markets_to_output')]
    for topic,outcome,test in plans:
        base=saved[saved.topic.eq(topic)].copy()
        variants=[('three_month_primary',base),('one_month_signal',window_signals(national,topic,1)),('six_month_signal',window_signals(national,topic,6))]
        if topic=='markets':
            variants += [('raw_sensitivity',topic_signals(raw,topic)),('stated_horizon',topic_signals(verified[verified.horizon_basis.eq('stated')],topic))]
            variants += [('omit_'+p,topic_signals(verified[verified.paper.ne(p)],topic)) for p in sorted(verified.paper.unique())]
        for name,signal in variants:
            d=signal.merge(truth.drop(columns='year'),on='origin',validate='one_to_one')
            d['log_articles']=np.log1p(d.articles)
            d['tested_predictor']=(d.net_direction-d.net_direction.mean())/d.net_direction.std()
            rr,_,_=regression(d,outcome,['tested_predictor'],['log_articles','papers','flat_share'])
            rows.append(dict(test=test,variant=name,**rr[0]))
            if name!='three_month_primary':continue
            d['recession']=d.origin.map(lambda o:series['recession'].get(o,np.nan))
            subgroups=[('expansion_print',d.recession.eq(0)),('recession_print',d.recession.eq(1)),
                       ('exclude_1929_1939',~d.year.between(1929,1939)),('exclude_1941_1945',~d.year.between(1941,1945)),
                       ('exclude_1973_1975',~d.year.between(1973,1975)),('exclude_1980_1982',~d.year.between(1980,1982)),
                       ('exclude_2007_2009',~d.year.between(2007,2009))]
            for name,mask in subgroups:
                rr,_,_=regression(d[mask],outcome,['tested_predictor'],['log_articles','papers','flat_share'])
                rows.append(dict(test=test,variant=name,**rr[0]))
            for start in sorted((d[d[outcome].notna()&d.tested_predictor.notna()].year//5*5).unique()):
                rr,_,_=regression(d[d.year//5*5!=start],outcome,['tested_predictor'],['log_articles','papers','flat_share'])
                blocks.append(dict(test=test,omitted_block=start,**rr[0]))
            for offset in range(6):
                ordinal=d.origin.map(lambda x:x.ordinal)
                sub=d[ordinal%6==offset]
                rr,_,_=regression(sub,outcome,['tested_predictor'],['log_articles','papers','flat_share'])
                rows.append(dict(test=test,variant=f'nonoverlap_6m_offset_{offset}',**rr[0]))
            # Quantiles are descriptive full-sample bins, not learned thresholds
            # used to make historical model predictions.
            common=d.dropna(subset=['net_direction',outcome]).copy()
            common['bin']=pd.qcut(common.net_direction,4,labels=False,duplicates='drop')
            for b,g in common.groupby('bin'):
                rec=dict(test=test,quartile=int(b)+1,n_months=len(g),mean_net=g.net_direction.mean(),
                         min_net=g.net_direction.min(),max_net=g.net_direction.max(),mean_outcome=g[outcome].mean(),
                         median_outcome=g[outcome].median(),outcome_q25=g[outcome].quantile(.25),outcome_q75=g[outcome].quantile(.75))
                if topic=='employment':
                    rec['unemployment_rise_gt05_share']=(g.employment_growth<-.5-1e-10).mean()
                    rec['unemployment_fall_gt05_share']=(g.employment_growth>.5+1e-10).mean()
                else:rec['production_decline_gt2_share']=(g.general_business_growth<100*np.log(.98)).mean()
                binrows.append(rec)
    pd.DataFrame(rows).to_csv(OUT/'economic_signal_robustness.csv',index=False)
    pd.DataFrame(blocks).to_csv(OUT/'economic_signal_leave_blocks_out.csv',index=False)
    pd.DataFrame(binrows).to_csv(OUT/'economic_signal_quartiles.csv',index=False)
    print(pd.DataFrame(rows)[['test','variant','effect','low','high','p_value','n']].to_string(index=False))
    print(pd.DataFrame(binrows).to_string(index=False))


if __name__=='__main__':main()
