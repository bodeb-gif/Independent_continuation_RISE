"""Fixed-model audit replacing quarter-stale unemployment with prior as-of data."""
from vintage_data import *
from common import clustered_mean,adjust
from backtest import frame_for_fitting,archives,labels_for_refit,ridge_predict,MODELS

MODELNAMES=['macro','macro_jobs','macro_business','macro_both']


def main():
    fresh=AlfredUnemployment();old=archives();original=frame_for_fitting()
    monthly=fresh.features(original.origin)
    fields=['unemployment_level','unemployment_change_3m','unemployment_change_12m','unemployment_age_months']
    updated=original.drop(columns=fields).merge(monthly[['origin']+fields+['UNRATE_asof','UNRATE_latest_observation']],on='origin',validate='one_to_one')
    assert np.isfinite(updated[fields]).all().all()
    assert original.origin.tolist()==updated.origin.tolist()
    assert (pd.to_datetime(updated.UNRATE_asof)<updated.origin.dt.to_timestamp()).all()
    updated.to_csv(OUT/'fresh_core_forecast_features.csv',index=False)
    rows=[];audit=[];parameters=[];label_frames=[]
    for task in ['unemployment','production']:
        conditions=[('old_features_old_labels',original,old['RUC'] if task=='unemployment' else old['IPT']),
                    ('fresh_features_old_labels',updated,old['RUC'] if task=='unemployment' else old['IPT'])]
        if task=='unemployment':conditions += [('old_features_fresh_labels',original,fresh),('fresh_features_fresh_labels',updated,fresh)]
        for condition,frame,archive in conditions:
            print(task,condition,flush=True)
            for year in range(1977,2011):
                refit=pd.Period(f'{year}-01','M');labels=labels_for_refit(frame,refit,archive,task)
                train=frame.merge(labels[['origin','training_target']],on='origin',validate='one_to_one').dropna(subset=['training_target']).sort_values('origin')
                test=frame[frame.origin.dt.year.eq(year)].copy()
                assert len(train)>=120 and len(test)==12
                assert (train.origin+8<refit).all()
                for name in MODELNAMES:
                    test[name],p=ridge_predict(train,test,MODELS[name],10.)
                    parameters.append(p.assign(task=task,condition=condition,refit_year=year))
                test['recent_mean']=train.training_target.tail(120).mean();test['zero_change']=0.
                rows.append(test[['origin']+MODELNAMES+['recent_mean','zero_change']].assign(task=task,condition=condition))
                audit.append(dict(task=task,condition=condition,refit_year=year,n_training=len(train),last_training_origin=train.origin.max(),
                                  label_vintage=labels.label_vintage.iloc[0],label_available_by=labels.label_available_by.iloc[0],
                                  latest_input_unemployment_age=test.unemployment_age_months.max()))
                if condition in ['old_features_old_labels','old_features_fresh_labels']:
                    label_frames.append(labels.assign(task=task,condition=condition))
    predicted=pd.concat(rows,ignore_index=True)
    # Reproduce the original experiments before interpreting changed inputs.
    original_predictions=pd.read_csv(SESSION/'backtest_predictions_alpha10.csv');original_predictions['origin']=pd.PeriodIndex(original_predictions.origin,freq='M')
    reproduction=predicted[predicted.condition.eq('old_features_old_labels')].merge(original_predictions,on=['task','origin'],validate='one_to_one',suffixes=('_new','_saved'))
    error=max(np.abs(reproduction[m+'_new']-reproduction[m+'_saved']).max() for m in MODELNAMES)
    if error>1e-9:raise ValueError('Old arm reproduction failed: '+str(error))
    truth=pd.read_csv(SESSION/'continuous_targets.csv');truth['origin']=pd.PeriodIndex(truth.origin,freq='M');truth=truth.set_index('origin')
    for task,col in [('unemployment','employment_growth'),('production','general_business_growth')]:
        mask=predicted.task.eq(task);predicted.loc[mask,'truth']=predicted.loc[mask,'origin'].map(truth[col])
    assert predicted.truth.notna().all()
    predicted.to_csv(OUT/'fresh_vintage_predictions.csv',index=False)
    pd.DataFrame(audit).to_csv(OUT/'fresh_vintage_refit_audit.csv',index=False)
    pd.concat(parameters).to_csv(OUT/'fresh_vintage_parameters.csv',index=False)
    pd.concat(label_frames).to_csv(OUT/'fresh_vintage_training_labels.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    metrics=[];tests=[];sensitivity=[];blocks=[]
    for (task,condition),g in predicted.groupby(['task','condition']):
        for model in MODELNAMES+['recent_mean','zero_change']:
            e=g[model]-g.truth
            metrics.append(dict(task=task,condition=condition,model=model,n=len(g),mse=np.square(e).mean(),rmse=np.sqrt(np.square(e).mean()),mae=abs(e).mean()))
    for task in ['unemployment','production']:
        condition='fresh_features_fresh_labels' if task=='unemployment' else 'fresh_features_old_labels'
        g=predicted[predicted.task.eq(task)&predicted.condition.eq(condition)].copy()
        for model in ['macro_jobs','macro_business','macro_both']:
            gain=(g.macro-g.truth)**2-(g[model]-g.truth)**2
            name=f'fresh_{task}_{model}_vs_macro'
            for span in [2,5,10]:
                result=clustered_mean(gain,np.ones(len(gain)),g.origin.dt.year,span,anchor=1977)
                r=dict(test=name,batch='fresh_vintage',task=task,model=model,baseline='macro',block_years=span,**result)
                if span==5:tests.append(r)
                else:sensitivity.append(r)
            for block,b in g.groupby((g.origin.dt.year-1977)//5):
                blocks.append(dict(test=name,block=int(block),n=len(b),gain=((b.macro-b.truth)**2-(b[model]-b.truth)**2).mean()))
            mask=~g.origin.dt.year.between(2007,2009)
            sensitivity.append(dict(test=name,variant='exclude_2007_2009',**clustered_mean(gain[mask],np.ones(mask.sum()),g.loc[mask,'origin'].dt.year,5,anchor=1977)))
        older=predicted[predicted.task.eq(task)&predicted.condition.eq('old_features_old_labels')][['origin','macro']].rename(columns={'macro':'old_macro'})
        g=g.merge(older,on='origin',validate='one_to_one')
        gain=(g.old_macro-g.truth)**2-(g.macro-g.truth)**2
        tests.append(dict(test=f'fresh_{task}_macro_vs_original_macro',batch='fresh_vintage',task=task,model='fresh_macro',baseline='old_macro',block_years=5,**clustered_mean(gain,np.ones(len(gain)),g.origin.dt.year,5,anchor=1977)))
    assert len(tests)==8
    result=adjust(pd.DataFrame(tests),8);result.to_csv(OUT/'fresh_vintage_tests.csv',index=False)
    pd.DataFrame(metrics).to_csv(OUT/'fresh_vintage_metrics.csv',index=False)
    pd.DataFrame(sensitivity).to_csv(OUT/'fresh_vintage_sensitivities.csv',index=False)
    pd.DataFrame(blocks).to_csv(OUT/'fresh_vintage_blocks.csv',index=False)
    base=OUT/'phase1_conservative_54_tests.csv'
    session=adjust(pd.concat([pd.read_csv(base),result],ignore_index=True),62)
    session.to_csv(SESSION/'session_wide_62_tests.csv',index=False)
    manifest=dict(old_prediction_reproduction_max_error=error,n_tests=8,cumulative_tests=62,
                  code_sha256={str(p.relative_to(ROOT)):digest(p) for p in [Path(__file__),OUT/'vintage_data.py',OUT/'fresh_vintage_specification.json']})
    (OUT/'fresh_vintage_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(pd.DataFrame(metrics).to_string(index=False));print(result[['test','effect','low','high','p_value','holm_p','n_blocks']].to_string(index=False))


if __name__=='__main__':main()
