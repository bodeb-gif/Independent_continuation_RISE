"""Real-activity/price expectation combinations, without structural shock claims."""
from associations import *

def joint_monthly(claims):
    c=claims[claims.topic.isin(['general_business','prices'])].copy()
    c['value']=c.sign.map({'positive':1.,'negative':-1.,'flat':0.})
    a=c.groupby(['month','paper','page_id','topic']).value.mean().unstack('topic')
    a=a.dropna(subset=['general_business','prices'])
    a['product']=a.general_business*a.prices
    p=a.groupby(['month','paper']).agg(business_mean=('general_business','mean'),
        price_mean=('prices','mean'),product_mean=('product','mean'),n_articles=('product','size'))
    p=p[p.n_articles>=2].copy()
    p['within_covariance']=p.product_mean-p.business_mean*p.price_mean
    m=p.groupby('month').agg(joint_covariance=('within_covariance','mean'),
        joint_business=('business_mean','mean'),joint_prices=('price_mean','mean'),
        joint_papers=('n_articles','size'),joint_articles=('n_articles','sum'))
    rows=[]
    for origin in pd.period_range('1900-01','2010-12',freq='M'):
        window=m.reindex(pd.period_range(origin-3,origin-1,freq='M'))
        enough=(window.joint_articles>0).sum()>=2 and window.joint_papers.max()>=2 and window.joint_articles.sum()>=5
        row=dict(origin=origin,joint_articles=window.joint_articles.sum(),joint_papers=window.joint_papers.mean())
        for col in ['joint_covariance','joint_business','joint_prices']:
            row[col]=window[col].mean() if enough else np.nan
        rows.append(row)
    return pd.DataFrame(rows)

def make_panel(source='verified'):
    f=pd.read_csv(OUT/'cache'/f'features_{source}.csv.gz');f['origin']=pd.PeriodIndex(f.origin,freq='M')
    d=f.pivot(index='origin',columns='topic',values=['net_direction','log_articles','n_papers'])
    d.columns=[f'{t}__{c}' for c,t in d.columns];d=d.reset_index()
    for topic in TOPICS:d[topic+'__net_squared']=d[topic+'__net_direction']**2
    for topic in ['general_business','employment','markets']:
        d[topic+'__price_product']=d[topic+'__net_direction']*d['prices__net_direction']
    claims=pd.read_csv(OUT/'cache'/f'print_claims_{source}.csv.gz',dtype={'page_id':str})
    claims['month']=pd.PeriodIndex(claims.month,freq='M')
    d=d.merge(joint_monthly(claims),on='origin',validate='one_to_one')
    d['joint_log_articles']=np.log1p(d.joint_articles)
    truth=pd.read_csv(PRIOR/'continuous_targets.csv');truth['origin']=pd.PeriodIndex(truth.origin,freq='M')
    d=d.merge(truth,on='origin',validate='one_to_one')
    macro=pd.read_csv(PRIOR/'phase2/fresh_core_forecast_features.csv');macro['origin']=pd.PeriodIndex(macro.origin,freq='M')
    from proquest_vintages import CORE_FEATURES
    d=d.merge(macro[['origin']+list(CORE_FEATURES)],on='origin',how='left',validate='one_to_one')
    return d

def run():
    controls=[f'{t}__{c}' for t in TOPICS for c in ['net_direction','net_squared','log_articles','n_papers']]
    features=[t+'__price_product' for t in ['general_business','employment','markets']]+['joint_covariance']
    outcomes=['general_business_growth','employment_growth','prices_growth'];rows=[];sensitivity=[];samples=[]
    for source in ['verified','raw']:
        data=make_panel(source);data.to_csv(OUT/'cache'/f'joint_expectation_panel_{source}.csv.gz',index=False,
            compression={'method':'gzip','mtime':0})
        for feature in features:
            columns=controls+(['joint_business','joint_prices','joint_log_articles','joint_papers'] if feature=='joint_covariance' else [])
            for outcome in outcomes:
                d=data.copy()
                if outcome=='general_business_growth':d=d[d.origin>=pd.Period('1919-02','M')]
                test=f'joint_{feature}_{outcome}'
                r,fit,used=estimate(d,feature,outcome,columns,wild=True)
                row=dict(test=test,batch='joint_expectations',feature=feature,outcome=outcome,source_set=source,block_years=5,**r)
                if source=='verified':rows.append(row);samples.append(used.assign(test=test))
                else:sensitivity.append(dict(variant='raw',**row))
                if source=='verified' and fit is not None:
                    for span in [2,10]:
                        rr,_,_=estimate(d,feature,outcome,columns,span=span,wild=False)
                        sensitivity.append(dict(test=test,variant=f'blocks_{span}',block_years=span,**rr))
                    for variant,mask in [('exclude_2007_2009',~d.year.between(2007,2009)),
                                         ('pre_1980',d.year<1980),('1980_onward',d.year>=1980)]:
                        rr,_,_=estimate(d[mask],feature,outcome,columns,wild=False)
                        sensitivity.append(dict(test=test,variant=variant,block_years=5,**rr))
                    from proquest_vintages import CORE_FEATURES
                    rr,_,_=estimate(d,feature,outcome,columns+list(CORE_FEATURES),wild=False)
                    sensitivity.append(dict(test=test,variant='vintage_macro_controls',block_years=5,**rr))
                print(source,test,r['effect'],r['p_value'],r['n'],flush=True)
                pd.DataFrame(rows).to_csv(OUT/'joint_tests_partial.csv',index=False)
    result=adjust(pd.DataFrame(rows),79);assert len(result)==12
    result.to_csv(OUT/'joint_tests.csv',index=False)
    pd.DataFrame(sensitivity).to_csv(OUT/'joint_sensitivities.csv',index=False)
    pd.concat(samples,ignore_index=True).to_csv(OUT/'audits/joint_analysis_rows.csv.gz',index=False,
        compression={'method':'gzip','mtime':0})
    save_json(OUT/'audits/joint_manifest.json',dict(status='complete',n_tests=12,planned_round_tests=79,
        code_sha256=digest(__file__),source_count=check_sources()))
    journal('joint_expectations','Completed all 12 real-activity/price combination questions')
    print(result.sort_values('p_value')[['test','effect','low','high','p_value','holm_p','n','n_blocks']].to_string(index=False))

if __name__=='__main__':run()
