"""Run the complete 24-test family, including null results and support tables."""
from common import *
from proquest_followups import load_claims
from proquest_descriptive import load_reference


def matched_cells(scored, field, left, right, topic=None, minimum=2):
    f=scored[scored[field].isin([left,right]) & scored.hit.notna() & scored.basis.ne('NBER proxy')].copy()
    if topic is not None:
        f=f[f.topic.eq(topic)]
    keys=['paper','month','topic','basis','horizon_basis','horizon_used']
    keys+=['voice'] if field=='confidence' else ['confidence']
    article=f.groupby(keys+[field,'page_id'],observed=True).agg(hit=('hit','mean'),n_claims=('hit','size')).reset_index()
    cell=article.groupby(keys+[field],observed=True).agg(hit=('hit','mean'),articles=('page_id','size'),claims=('n_claims','sum')).reset_index()
    l=cell[cell[field].eq(left)].drop(columns=field)
    r=cell[cell[field].eq(right)].drop(columns=field)
    both=l.merge(r,on=keys,suffixes=('_left','_right'),validate='one_to_one')
    both=both[(both.articles_left>=minimum)&(both.articles_right>=minimum)].copy()
    both['difference']=both.hit_left-both.hit_right
    both['weight']=2*both.articles_left*both.articles_right/(both.articles_left+both.articles_right)
    both['year']=both.month.dt.year
    return both


def claim_results(scored):
    rows=[];sensitivity=[]
    plans=[('confidence','assertive','hedged',t,f'confidence_{t}') for t in ['general_business','markets','prices','employment']]
    plans += [('voice','official','expert',None,'official_vs_expert'),('voice','expert','journalist',None,'expert_vs_journalist')]
    for field,left,right,topic,name in plans:
        cells=matched_cells(scored,field,left,right,topic)
        cells.to_csv(OUT/f'cells_{name}.csv',index=False)
        if len(cells):
            for span in [2,5,10]:
                result=clustered_mean(cells.difference,cells.weight,cells.year,span)
                sensitivity.append(dict(test=name,block_years=span,**result))
                if span==5:
                    rows.append(dict(test=name,kind='matched_claims',unit='proportion correct',
                                     left=left,right=right,topic=topic or 'all',
                                     left_rate=np.average(cells.hit_left,weights=cells.weight),
                                     right_rate=np.average(cells.hit_right,weights=cells.weight),
                                     left_articles_in_cells=cells.articles_left.sum(),right_articles_in_cells=cells.articles_right.sum(),
                                     **result))
        else:
            rows.append(dict(test=name,kind='matched_claims',p_value=1.,status='no common support'))
    pd.DataFrame(sensitivity).to_csv(OUT/'claim_block_sensitivities.csv',index=False)
    return rows


def base_controls(frame):
    cols=['net_direction','net_squared','flat_share','log_articles','papers']
    return [c for c in cols if c in frame]


def monthly_tests(signal,truth,claims):
    rows=[];sens=[]
    def estimate(data,outcome,predictor,controls,name,unit):
        data=data.copy()
        scale=data[predictor].std()
        data['tested_predictor']=(data[predictor]-data[predictor].mean())/scale
        for span in [2,5,10]:
            rr,fit,used=regression(data,outcome,['tested_predictor'],controls,span)
            result=dict(test=name,kind='monthly_association',unit=unit,raw_predictor=predictor,predictor_scale=scale,block_years=span,**rr[0])
            sens.append(result)
            if span==5:
                rows.append(result)
                used.to_csv(OUT/f'months_{name}.csv',index=False)
        rr,_,_=regression(data,outcome,['tested_predictor'],controls,hac=True)
        sens.append(dict(test=name,block_years=0,uncertainty='HAC12',**rr[0]))
    frames={}
    for topic,g in signal.groupby('topic'):
        d=g.merge(truth.drop(columns='year'),on='origin',validate='one_to_one')
        d['log_articles']=np.log1p(d.articles)
        d['net_squared']=d.net_direction**2
        frames[topic]=d
    for topic in ['general_business','markets','prices','employment']:
        d=frames[topic]
        controls=['log_articles','papers','flat_share']
        if topic=='markets':controls+=['stock_past_return','stock_past_volatility']
        estimate(d,topic+'_growth','net_direction',controls,'direction_'+topic,'pp six-month change per SD prior net direction')
    for topic,predictor,name in [
        ('markets','disagreement','market_disagreement_volatility'),
        ('general_business','disagreement','business_disagreement_volatility'),
        ('markets','paper_dispersion','market_dispersion_volatility')]:
        estimate(frames[topic],'markets_volatility',predictor,
                 base_controls(frames[topic])+['stock_past_return','stock_past_volatility'],name,
                 'pp annualized monthly-price volatility per SD signal')
    estimate(frames['general_business'],'general_business_abs_growth','disagreement',
             base_controls(frames['general_business']),'business_disagreement_output_magnitude','pp absolute six-month IP growth per SD signal')
    for topic,outcome,name in [('general_business','markets_growth','business_direction_stock_return'),('markets','general_business_growth','market_direction_output')]:
        controls=['log_articles','papers','flat_share']
        if outcome=='markets_growth':controls+=['stock_past_return','stock_past_volatility']
        estimate(frames[topic],outcome,'net_direction',controls,name,'pp six-month change per SD signal')

    epu=load_epu()
    # The buffer is t-1; t-4 through t-2 supply three completed months.
    epu_origin={o:np.log(epu.reindex(pd.period_range(o-4,o-2,freq='M'))).mean() for o in truth.origin}
    # Reuse monthly paper/article composition, without retrospective annotations.
    f=claims[claims.hit.notna() & claims.basis.ne('NBER proxy')].copy()
    f['gap']=f.hit-f.fixed_baseline_hit
    f['hedged']=f.confidence.eq('hedged').astype(float)
    f['default']=f.horizon_basis.eq('default').astype(float)
    dummies=pd.concat([pd.get_dummies(f.topic,prefix='topic',dtype=float),pd.get_dummies(f.paper,prefix='paper',dtype=float)],axis=1)
    composition=list(pd.get_dummies(f.topic,prefix='topic').columns[1:])+list(pd.get_dummies(f.paper,prefix='paper').columns[1:])
    f=pd.concat([f,dummies],axis=1)
    valuecols=['hit','gap','hedged','default','horizon_used']+composition
    article=f.groupby(['month','page_id'],observed=True)[valuecols].mean()
    month=article.groupby('month').mean()
    month['articles']=article.groupby('month').size()
    month['papers']=f.groupby('month').paper.nunique()
    month=month[(month.articles>=5)&(month.papers>=2)].reset_index().rename(columns={'month':'origin'})
    month['year']=month.origin.dt.year
    month['epu']=month.origin.map(epu_origin)
    month['log_articles']=np.log1p(month.articles)
    controls=composition+['default','horizon_used','log_articles','papers']
    for outcome,name in [('hit','epu_accuracy'),('gap','epu_baseline_gap'),('hedged','epu_hedging')]:
        estimate(month,outcome,'epu',controls,name,'proportion per SD prior log EPU')
    pol=pd.read_csv(BASE/'polarization/features.csv')
    pol['origin']=pd.PeriodIndex(pol.origin,freq='M')
    assert (pd.to_datetime(pol.political_latest_vote)<pol.origin.dt.to_timestamp()).all()
    # EPU/politics and print-month forecast composition, not future outcomes.
    current=national_panel();current=current[current.topic.eq('general_business')].copy().rename(columns={'month':'origin','n_articles':'articles','n_papers':'papers'})
    current=current[(current.articles>=5)&(current.papers>=2)]
    current['year']=current.origin.dt.year
    current['epu']=current.origin.map(epu_origin)
    current['log_articles']=np.log1p(current.articles)
    current=current.merge(pol[['origin','political_polarization']],on='origin',validate='one_to_one')
    for predictor,outcome,name in [('epu','negative_share','epu_pessimism'),('epu','paper_dispersion','epu_dispersion'),('political_polarization','negative_share','politics_pessimism'),('political_polarization','paper_dispersion','politics_dispersion')]:
        estimate(current,outcome,predictor,['log_articles','papers','flat_share'],name,'proportion per SD prior index')
    pd.DataFrame(sens).to_csv(OUT/'monthly_block_sensitivities.csv',index=False)
    signal.to_csv(OUT/'lagged_topic_signals.csv',index=False)
    truth.to_csv(OUT/'continuous_targets.csv',index=False)
    return rows


def recovery_test():
    series,_=load_reference();rec=series['recession']
    troughs=rec.index[(rec.eq(1))&(rec.shift(-1).eq(0))]
    paper=pd.read_csv(BASE/'monthly_information/newspaper_topic_month.csv.gz')
    paper['month']=pd.PeriodIndex(paper.month,freq='M')
    paper=paper[paper.topic.eq('general_business') & paper.observed & (paper.n_articles>=2)]
    rows=[];details=[]
    for trough in troughs:
        if trough.year<1900 or (trough+6).year>2010:continue
        pre=pd.period_range(trough-5,trough,freq='M');post=pd.period_range(trough+1,trough+6,freq='M')
        pre=pre[rec.reindex(pre).eq(1).to_numpy()];post=post[rec.reindex(post).eq(0).to_numpy()]
        a=paper[paper.month.isin(pre)].groupby('paper').negative_share.agg(['mean','size'])
        b=paper[paper.month.isin(post)].groupby('paper').negative_share.agg(['mean','size'])
        both=a.merge(b,left_index=True,right_index=True,suffixes=('_before','_after'))
        both=both[(both.size_before>=3)&(both.size_after>=3)]
        if both.empty:continue
        for name,r in both.iterrows():details.append(dict(trough=str(trough),paper=name,**r.to_dict()))
        rows.append(dict(trough=str(trough),year=trough.year,n_papers=len(both),
                         before=both.mean_before.mean(),after=both.mean_after.mean(),
                         difference=(both.mean_after-both.mean_before).mean()))
    d=pd.DataFrame(rows);pd.DataFrame(details).to_csv(OUT/'recovery_paper_phases.csv',index=False)
    d.to_csv(OUT/'recovery_events.csv',index=False)
    result=clustered_mean(d.difference,np.ones(len(d)),d.year)
    return dict(test='recovery_pessimism',kind='paired_recession_events',unit='proportion negative',
                before=d.before.mean(),after=d.after.mean(),n_events=len(d),**result)


def main():
    print('Validating saved scores against all annual verified exports...',flush=True)
    claims,metadata,hashes=load_claims()
    scores=claims[claims.hit.notna()].copy()
    print('Matched confidence and voice tests...',flush=True)
    rows=claim_results(scores)
    print('Building prior-only topic signals...',flush=True)
    signal=make_signals(national_panel());truth,references=targets()
    print('Monthly economic associations...',flush=True)
    rows+=monthly_tests(signal,truth,claims)
    rows.append(recovery_test())
    assert len(rows)==24, len(rows)
    results=adjust(pd.DataFrame(rows),24)
    results.to_csv(OUT/'primary_results.csv',index=False)
    write_json('primary_manifest.json',dict(status='exploratory',n_tests=len(results),
               verified_source_hashes=hashes,references=references,
               inputs_sha256={str(p.relative_to(ROOT)):digest(p) for p in [BASE/'descriptive/scored_claims.csv.gz',BASE/'monthly_information/national_topic_month.csv.gz',BASE/'monthly_information/newspaper_topic_month.csv.gz',BASE/'polarization/features.csv',OUT/'reference/US_Policy_Uncertainty_Data.xlsx',OUT/'specification.json',OUT/'common.py',Path(__file__)]},
               package_versions={k:__import__(k).__version__ for k in ['numpy','pandas','scipy','statsmodels']}))
    print(results[['test','effect','low','high','p_value','holm_p','bh_q','n','n_blocks']].sort_values('p_value').to_string(index=False),flush=True)


if __name__=='__main__':main()
