"""Model-reweighting sensitivity ranges, explicitly separated from inference."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from session_utils import *

def run():
    ranges=pd.read_csv(OUT/'refit_summary/ranges.csv')
    algorithms=['linear','hist_gradient_boosting','extra_trees','gru']
    labels=['Linear / logistic','Boosted trees','Extra trees','GRU']
    tasks=[('production_continuous','Production growth','MSE gain'),
        ('unemployment_continuous','Unemployment improvement','MSE gain'),
        ('production_downturn','Production downturn','Brier-score gain'),
        ('unemployment_downturn','Unemployment rise','Brier-score gain')]
    original=pd.concat([pd.read_csv(OUT/'models_boundary_corrected'/algorithm/'tests.csv') for algorithm in algorithms])
    fig,axes=plt.subplots(2,4,figsize=(14,7.5))
    for row,(comparison,title) in enumerate([('net_minus_macro_coverage','Add topic nets'),('structure_minus_net','Add structural features')]):
        for column,(task,label,unit) in enumerate(tasks):
            ax=axes[row,column];counts=[]
            for position,algorithm in enumerate(algorithms):
                r=ranges[ranges.algorithm.eq(algorithm)&ranges.task.eq(task)&ranges.comparison.eq(comparison)].iloc[0]
                p=original[original.algorithm.eq(algorithm)&original.task.eq(task)&original.comparison.eq(comparison)].iloc[0]
                ax.plot([r.low,r.high],[position,position],color='#126b80',lw=2.5)
                ax.scatter(r['median'],position,color='#126b80',s=26,zorder=3)
                ax.scatter(p.effect,position+.11,color='#263641',marker='D',s=20,zorder=3)
                counts.append(int(r.draws))
            ax.axvline(0,color='#a4aeb5',ls='--',lw=1);ax.set_ylim(3.65,-.5)
            ax.set_yticks(range(4),[f'{name} (n={count})' for name,count in zip(labels,counts)] if column==0 else [])
            ax.set_title(title+'\n'+label,fontsize=10);ax.set_xlabel(unit,fontsize=9)
            ax.tick_params(axis='both',labelsize=9);ax.grid(axis='x',alpha=.15)
    fig.suptitle('Refitting changes the apparent size of model gains',fontsize=15,y=1.02)
    fig.text(.01,-.03,'Blue: median and 2.5–97.5% model-reweighting range. Black diamond: original gain. n = reweightings, not independent forecast observations.',fontsize=9)
    fig.text(.01,-.065,'Linear repeats model selection. Nonlinear main ranges hold settings fixed. These are sensitivity ranges, not corrected confidence intervals for future-cycle gains.',fontsize=9)
    fig.tight_layout()
    for suffix in ['png','svg']:fig.savefig(OUT/'figures'/('model_refit_ranges.'+suffix),dpi=170,bbox_inches='tight')
    plt.close(fig)
    save_json(OUT/'audits/refit_range_figure.json',dict(status='complete',updated_utc=dt.datetime.now(dt.timezone.utc),
        code_sha256=digest(__file__),range_data_sha256=digest(OUT/'refit_summary/ranges.csv')))

if __name__=='__main__':run()
