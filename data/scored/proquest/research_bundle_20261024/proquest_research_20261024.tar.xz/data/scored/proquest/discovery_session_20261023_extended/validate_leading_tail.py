"""Directly refit every sign pattern for the two leading primary associations.

This audit introduces no new hypothesis or favorable specification. It checks
the original-anchor computation using statsmodels fits rather than the batch
score algebra used by the research estimator.
"""
import time
import statsmodels.api as sm
from session_utils import *


def run():
    start = time.monotonic()
    ledger = pd.read_csv(OUT/'cumulative_current_tests.csv')
    plans = [
        ('structure_employment_cross_topic_gap', 'structural_analysis_rows.csv.gz',
         ['net_direction', 'net_squared', 'flat_share', 'log_articles', 'n_papers']),
        ('common_information_pca_factor', 'common_information_analysis_rows.csv.gz',
         ['flat_share', 'log_articles', 'n_papers', 'employment_residual']),
    ]
    checks = []
    for name, filename, controls in plans:
        saved = ledger[ledger.test.eq(name)].iloc[0]
        d = pd.read_csv(OUT/'audits'/filename)
        d = d[d.test.eq(name)].reset_index(drop=True)
        design = pd.concat([
            pd.Series(1., index=d.index, name='const'),
            d[['tested_predictor']+controls].astype(float),
            pd.get_dummies(d.year//10*10, prefix='decade', drop_first=True, dtype=float),
        ], axis=1)
        assert ';'.join(design.columns) == saved.controls
        x = design.to_numpy(float)
        assert np.linalg.matrix_rank(x) == x.shape[1]
        y = d.employment_growth.to_numpy(float)
        codes, groups = np.unique((d.year.to_numpy(int)-1900)//5, return_inverse=True)
        g = len(codes)
        covariance = dict(cov_type='cluster', cov_kwds={
            'groups': groups, 'use_correction': True, 'df_correction': True}, use_t=True)
        observed = sm.OLS(y, x).fit(**covariance)
        np.testing.assert_allclose(observed.params[1], saved.effect, atol=1e-10)
        np.testing.assert_allclose(observed.bse[1], saved.se, atol=1e-10)
        null = sm.OLS(y, np.delete(x, 1, axis=1)).fit()
        records = []
        for pattern in range(1 << g):
            signs = np.array([1. if pattern & (1 << j) else -1. for j in range(g)])
            star = null.fittedvalues + null.resid*signs[groups]
            fit = sm.OLS(star, x).fit(**covariance)
            records.append(dict(pattern=pattern, t_statistic=float(fit.tvalues[1]),
                extreme=bool(abs(fit.tvalues[1]) >= abs(observed.tvalues[1])-1e-10)))
            if (pattern+1) % 4096 == 0:
                print(name, pattern+1, '/', 1 << g, flush=True)
        f = pd.DataFrame(records)
        f.to_csv(OUT/'audits'/f'{name}_direct_sign_refits.csv.gz', index=False,
            compression={'method': 'gzip', 'mtime': 0})
        extreme = int(f.extreme.sum())
        p = extreme/len(f)
        np.testing.assert_equal(extreme, int(saved.wild_extreme))
        np.testing.assert_equal(p, saved.p_wild)
        np.testing.assert_allclose(max(float(observed.pvalues[1]), p), saved.p_value,
            rtol=1e-10, atol=1e-14)
        checks.append(dict(test=name, sign_patterns=len(f), extreme=extreme,
            p_wild=p, p_cluster_t=float(observed.pvalues[1]),
            effect=float(observed.params[1]), se=float(observed.bse[1]),
            extreme_patterns=f.loc[f.extreme, 'pattern'].tolist()))
    # Independently implement the step-down Holm and step-up BH arithmetic.
    # Do not call session_utils.adjust or statsmodels.multitest in this check.
    values = ledger.p_value.fillna(1).clip(0, 1).to_numpy(float)
    order = np.argsort(values, kind='stable')
    n = len(values)
    holm = np.empty(n); bh = np.empty(n)
    running = 0.
    for rank, index in enumerate(order):
        running = max(running, min(1., (n-rank)*values[index]))
        holm[index] = running
    running = 1.
    for rank in range(n-1, -1, -1):
        index = order[rank]
        running = min(running, n*values[index]/(rank+1))
        bh[index] = running
    np.testing.assert_allclose(holm, ledger.holm_p, rtol=1e-12, atol=1e-14)
    np.testing.assert_allclose(bh, ledger.bh_q, rtol=1e-12, atol=1e-14)
    result = dict(status='passed', created_utc=dt.datetime.now(dt.timezone.utc),
        elapsed_seconds=time.monotonic()-start, primary_checks=checks,
        family_adjustments_checked=n, source_hashes_unchanged=check_sources(),
        code_sha256=digest(__file__),
        limit='Independent computation verifies the original specification; it does not resolve block placement, error-model or source-semantic uncertainty.')
    save_json(OUT/'audits/leading_tail_validation.json', result)
    journal('validation', 'Directly refitted all leading primary sign patterns and independently checked family corrections',
        sign_refits=sum(c['sign_patterns'] for c in checks), family_size=n)
    print(json.dumps(result, indent=2, default=json_default))


if __name__ == '__main__':
    from threadpoolctl import threadpool_limits
    with threadpool_limits(limits=1):
        run()
