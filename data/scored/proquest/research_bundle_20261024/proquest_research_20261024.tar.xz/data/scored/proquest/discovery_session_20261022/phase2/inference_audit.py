"""Exact small-cluster restricted-wild checks for already identified effects."""
from vintage_data import *
from common import adjust
import time


def sign_batches(g,batch=10000):
    if g>23:raise ValueError('Refuse impractical exact enumeration')
    bit=np.arange(g,dtype=np.uint64)
    for start in range(0,2**g,batch):
        ids=np.arange(start,min(start+batch,2**g),dtype=np.uint64)
        yield 2*((ids[:,None]>>bit)&1).astype(float)-1


def regression_bootstrap(d,outcome,columns,span):
    x=d.copy();decade=pd.get_dummies(x.year//10*10,prefix='decade',dtype=float)
    for c in decade:x[c]=decade[c]
    x['const']=1.
    X=x[columns].to_numpy(float);y=x[outcome].to_numpy(float)
    j=columns.index('tested_predictor');keep=[i for i in range(X.shape[1]) if i!=j]
    X0=X[:,keep];b0=np.zeros(X.shape[1]);b0[keep]=np.linalg.lstsq(X0,y,rcond=None)[0]
    u0=y-X@b0
    bread=np.linalg.inv(X.T@X);beta=bread@X.T@y;u=y-X@beta
    groups=((d.year.to_numpy()-1900)//span);unique=np.unique(groups)
    g=len(unique);n,k=X.shape;factor=g/(g-1)*(n-1)/(n-k)
    S0=[];S=[];C=[]
    for group in unique:
        mask=groups==group;z=X[mask]
        S0.append(z.T@u0[mask]);S.append(z.T@u[mask]);C.append(bread[j]@(z.T@z))
    S0=np.asarray(S0);S=np.asarray(S);C=np.asarray(C)
    se=np.sqrt(factor*np.square(S@bread[j]).sum());observed=beta[j]/se
    contributions=S0@bread.T;q=S0@bread[j]
    extreme=0;total=0;hist=np.zeros(400,dtype=np.int64);edges=np.linspace(-12,12,401)
    for signs in sign_batches(g):
        delta=signs@contributions
        scores=signs*q[None,:]-delta@C.T
        star_se=np.sqrt(factor*np.square(scores).sum(axis=1))
        stat=delta[:,j]/star_se
        extreme+=np.sum(np.abs(stat)>=abs(observed)-1e-10);total+=len(stat)
        hist+=np.histogram(stat,bins=edges)[0]
    return dict(effect=beta[j],se=se,t_statistic=observed,wild_p=extreme/total,
                extreme_assignments=int(extreme),enumerated_assignments=total,n_blocks=g,n=n),hist,edges


def mean_bootstrap(cells,span):
    z=cells.assign(group=(cells.year-1900)//span,wy=cells.weight*cells.difference)
    tab=z.groupby('group')[['wy','weight']].sum();v=tab.wy.to_numpy();w=tab.weight.to_numpy()
    g=len(tab);mass=w.sum();effect=v.sum()/mass
    se=np.sqrt(g/(g-1)*np.square(v-effect*w).sum())/mass;observed=effect/se
    extreme=0;total=0;hist=np.zeros(400,dtype=np.int64);edges=np.linspace(-12,12,401)
    for signs in sign_batches(g):
        signed=signs*v;mean=signed.sum(axis=1)/mass
        score=signed-mean[:,None]*w
        star_se=np.sqrt(g/(g-1)*np.square(score).sum(axis=1))/mass
        stat=mean/star_se
        extreme+=np.sum(np.abs(stat)>=abs(observed)-1e-10);total+=len(stat)
        hist+=np.histogram(stat,bins=edges)[0]
    return dict(effect=effect,se=se,t_statistic=observed,wild_p=extreme/total,
                extreme_assignments=int(extreme),enumerated_assignments=total,n_blocks=g,n=len(cells)),hist,edges


def main():
    start=time.time();primary=pd.read_csv(SESSION/'primary_results.csv').set_index('test');results=[];histograms=[]
    plans=[('direction_employment','employment_growth'),('direction_general_business','general_business_growth'),('market_direction_output','general_business_growth')]
    for test,outcome in plans:
        d=pd.read_csv(SESSION/f'months_{test}.csv')
        cols=primary.loc[test,'controls'].split(';')
        for span in [5,10]:
            print('Enumerating',test,span,'years',flush=True)
            r,hist,edges=regression_bootstrap(d,outcome,cols,span)
            if not np.isclose(r['effect'],primary.loc[test,'effect'],atol=1e-9):raise ValueError('Coefficient reproduction failed')
            if span==5 and not np.isclose(r['se'],primary.loc[test,'se'],atol=1e-9):raise ValueError('Cluster SE reproduction failed')
            results.append(dict(test=test,block_years=span,original_primary_p=primary.loc[test,'p_value'],**r))
            histograms.extend([dict(test=test,block_years=span,low=edges[i],high=edges[i+1],count=int(count)) for i,count in enumerate(hist)])
    test='confidence_general_business';cells=pd.read_csv(SESSION/f'cells_{test}.csv')
    for span in [5,10]:
        print('Enumerating',test,span,'years',flush=True)
        r,hist,edges=mean_bootstrap(cells,span)
        assert np.isclose(r['effect'],primary.loc[test,'effect'])
        if span==5:assert np.isclose(r['se'],primary.loc[test,'se'])
        results.append(dict(test=test,block_years=span,original_primary_p=primary.loc[test,'p_value'],**r))
        histograms.extend([dict(test=test,block_years=span,low=edges[i],high=edges[i+1],count=int(count)) for i,count in enumerate(hist)])
    result=pd.DataFrame(results);result.to_csv(OUT/'phase1_wild_inference_audit.csv',index=False)
    pd.DataFrame(histograms).to_csv(OUT/'phase1_wild_t_histograms.csv',index=False)
    session=pd.read_csv(SESSION/'session_wide_54_tests.csv');session['original_p_value']=session.p_value
    p=result[result.block_years.eq(5)].set_index('test').wild_p
    mask=session.test.isin(p.index)
    session.loc[mask,'p_value']=np.maximum(session.loc[mask,'p_value'],session.loc[mask,'test'].map(p))
    session['inference_rule']='max(original cluster-t, exact restricted-wild) for four audited tests; original for others'
    session=adjust(session,54);session.to_csv(OUT/'phase1_conservative_54_tests.csv',index=False)
    manifest=dict(elapsed_seconds=time.time()-start,rule='Only weaken audited primary p-values',
                  source_code_sha256={str(p.relative_to(ROOT)):digest(p) for p in [Path(__file__),OUT/'inference_audit_specification.json']})
    (OUT/'inference_audit_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(result.to_string(index=False));print(session[session.holm_p<.05][['test','p_value','holm_p']].to_string(index=False))


if __name__=='__main__':main()
