"""Shared auditable inference for the exploratory session; no source mutations."""
from pathlib import Path
import hashlib
import itertools
import json
import sys

import numpy as np
import pandas as pd
import scipy.stats as st
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
BASE = ROOT / 'data/scored/proquest'
sys.path.insert(0, str(ROOT / 'src'))
SEED = 20261022


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(name, value):
    def convert(x):
        if isinstance(x, (np.integer, np.floating, np.bool_)):
            return x.item()
        if isinstance(x, (pd.Period, pd.Timestamp, Path)):
            return str(x)
        raise TypeError(type(x))
    (OUT / name).write_text(json.dumps(value, indent=2, default=convert) + '\n')


def clustered_mean(values, weights, years, span=5, anchor=1900, bootstrap=10000):
    """Ratio mean with calendar-cluster sandwich and cluster-t uncertainty.

    Weights held fixed; bootstrap occupied blocks jointly. Sign flips are an
    additional symmetry-dependent diagnostic, not the primary p-value.
    """
    y, w, years = map(np.asarray, (values, weights, years))
    ok = np.isfinite(y) & np.isfinite(w) & (w > 0)
    y, w, years = y[ok], w[ok], years[ok]
    if len(y) == 0:
        return dict(effect=np.nan, p_value=1., n=0, n_blocks=0)
    effect = np.average(y, weights=w)
    d = pd.DataFrame({'block': (years-anchor)//span, 'wy': w*y, 'w': w})
    blocks = d.groupby('block')[['wy', 'w']].sum()
    g = len(blocks)
    if g < 3:
        return dict(effect=effect, p_value=1., n=len(y), n_blocks=g)
    score = blocks.wy - effect*blocks.w
    se = np.sqrt(g/(g-1) * np.square(score).sum())/w.sum()
    crit = st.t.ppf(.975, g-1)
    p = 2*st.t.sf(abs(effect/se), g-1) if se else float(effect == 0)
    result = dict(effect=effect, se=se, low=effect-crit*se, high=effect+crit*se,
                  p_value=p, n=len(y), n_blocks=g, weight_sum=w.sum(),
                  positive_blocks=int((blocks.wy > 0).sum()))
    if bootstrap:
        rng = np.random.default_rng(SEED+span+anchor)
        draws = rng.integers(0, g, (bootstrap, g))
        boot = blocks.wy.to_numpy()[draws].sum(1)/blocks.w.to_numpy()[draws].sum(1)
        result['bootstrap_low'], result['bootstrap_high'] = np.quantile(boot, [.025, .975])
        v = blocks.wy.to_numpy()
        if g <= 18:
            signs = np.array(list(itertools.product([-1,1],repeat=g)), dtype=float)
            result['signflip_p'] = np.mean(np.abs(signs@v) >= abs(v.sum())-1e-12)
        else:
            signs = rng.choice([-1.,1.], (99999,g))
            result['signflip_p'] = (1+np.sum(np.abs(signs@v) >= abs(v.sum())-1e-12))/100000
    return result


def regression(frame, outcome, predictors, controls, span=5, anchor=1900, hac=False):
    cols = list(dict.fromkeys([outcome] + predictors + controls + ['year']))
    d = frame[cols].replace([np.inf,-np.inf],np.nan).dropna().copy()
    x = pd.concat([d[predictors+controls].astype(float),
                   pd.get_dummies(d.year//10*10, prefix='decade', drop_first=True, dtype=float)],axis=1)
    # Remove constant controls and exact linear redundancies by deterministic
    # incremental rank checks, always preserving requested predictors first.
    x = sm.add_constant(x,has_constant='add')
    kept = []
    rank = 0
    for col in x:
        trial=x[kept+[col]].to_numpy()
        new_rank=np.linalg.matrix_rank(trial)
        if new_rank>rank:
            kept.append(col);rank=new_rank
    x=x[kept]
    blocks=(d.year-anchor)//span
    fit=sm.OLS(d[outcome],x).fit(cov_type='HAC',cov_kwds={'maxlags':12},use_t=True) if hac else sm.OLS(d[outcome],x).fit(cov_type='cluster',cov_kwds={'groups':blocks,'use_correction':True,'df_correction':True},use_t=True)
    rows=[]
    for name in predictors:
        if name not in fit.params:
            rows.append(dict(predictor=name,effect=np.nan,p_value=1.,n=len(d),n_blocks=blocks.nunique(),status='collinear'))
            continue
        low,high=fit.conf_int().loc[name]
        rows.append(dict(predictor=name,effect=fit.params[name],se=fit.bse[name],low=low,high=high,
                         p_value=fit.pvalues[name],n=len(d),n_blocks=blocks.nunique(),r_squared=fit.rsquared,
                         outcome_sd=d[outcome].std(),predictor_sd=d[name].std(),
                         first_year=int(d.year.min()),last_year=int(d.year.max()),
                         controls=';'.join(kept),status='estimated'))
    # Keep dates in exported analysis populations for an independent audit.
    # They are metadata only and were not included in the regression design.
    if 'origin' in frame and 'origin' not in d:
        d['origin']=frame.loc[d.index,'origin']
    return rows,fit,d


def adjust(frame, family_size=None):
    n=family_size or len(frame)
    p=list(frame.p_value.fillna(1).clip(0,1)) + [1.]*(n-len(frame))
    frame=frame.copy()
    frame['holm_p']=multipletests(p, method='holm')[1][:len(frame)]
    frame['bh_q']=multipletests(p, method='fdr_bh')[1][:len(frame)]
    return frame


def load_epu():
    path=OUT/'reference/US_Policy_Uncertainty_Data.xlsx'
    raw=pd.read_excel(path,sheet_name='Main News Index')
    raw=raw.apply(pd.to_numeric,errors='coerce').dropna()
    index=pd.PeriodIndex(year=raw.Year.astype(int),month=raw.Month.astype(int),freq='M')
    s=pd.Series(raw.News_Based_Policy_Uncert_Index.to_numpy(),index=index).sort_index()
    assert s.index.is_unique and (s>0).all()
    return s


def national_panel():
    f=pd.read_csv(BASE/'monthly_information/national_topic_month.csv.gz')
    f['month']=pd.PeriodIndex(f.month,freq='M')
    return f


def make_signals(national):
    """Exact backward windows; no economic outcome eligibility in this step."""
    calendar=pd.period_range('1900-01','2010-12',freq='M')
    rows=[]
    for topic,g in national.groupby('topic'):
        m=g.set_index('month').reindex(calendar)
        for origin in calendar:
            window=m.reindex(pd.period_range(origin-3,origin-1,freq='M'))
            adequate=(window.n_articles>0).sum()>=2 and window.n_papers.max()>=2 and window.n_articles.sum()>=5
            rec=dict(origin=origin,topic=topic,year=origin.year,
                     articles=window.n_articles.sum(),papers=window.n_papers.mean(),observed_months=int((window.n_articles>0).sum()))
            for col in ['net_direction','negative_share','flat_share','disagreement','paper_dispersion']:
                rec[col]=window[col].mean() if adequate else np.nan
            rec['latest_print_month']=origin-1
            rows.append(rec)
    return pd.DataFrame(rows)


def targets():
    from proquest_descriptive import load_reference
    series,meta=load_reference()
    rows=[]
    for origin in pd.period_range('1900-01','2010-12',freq='M'):
        rec=dict(origin=origin,year=origin.year)
        for topic in ['general_business','markets','prices','employment']:
            s=series[topic]
            points=s.reindex(pd.period_range(origin-1,origin+5,freq='M'))
            if points.notna().all():
                if topic=='employment':
                    rec[topic+'_growth']=-(points.iloc[-1]-points.iloc[0])
                else:
                    returns=np.diff(np.log(points.to_numpy()))*100
                    rec[topic+'_growth']=returns.sum()
                    rec[topic+'_volatility']=np.std(returns,ddof=0)*np.sqrt(12)
                    rec[topic+'_abs_growth']=abs(returns.sum())
            # Only stock price history is used as a predictor. Macro observations
            # are outcomes, unless a separately audited vintage input is loaded.
            if topic=='markets':
                history=s.reindex(pd.period_range(origin-13,origin-1,freq='M'))
                if history.notna().all():
                    returns=np.diff(np.log(history.to_numpy()))*100
                    rec['stock_past_return']=returns.sum()
                    rec['stock_past_volatility']=np.std(returns)*np.sqrt(12)
        rows.append(rec)
    return pd.DataFrame(rows),meta
