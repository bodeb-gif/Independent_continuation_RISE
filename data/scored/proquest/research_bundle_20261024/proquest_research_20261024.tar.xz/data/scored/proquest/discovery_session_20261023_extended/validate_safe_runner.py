"""Exercise resume guards with a mocked sampler; never launch a new fit."""
import runpy
import shutil
from unittest.mock import patch
import refit_multiplier_corrected as core
import validate_saved_inputs as dependencies
from session_utils import *


def run():
    script=OUT/'safe_refit_runner.py';checks=[]
    future=(dt.datetime.now(dt.timezone.utc)+dt.timedelta(hours=1)).isoformat()
    def invoke(stop):
        args=[str(script),'--algorithm','linear','--draws','1','--reselect','--stop-utc',stop]
        with patch.object(sys,'argv',args):runpy.run_path(str(script),run_name='__main__')
    for stop in ['2020-01-01T00:00:00+00:00','2030-01-01T00:00:00']:
        with patch.object(core,'run') as sampler:
            try:invoke(stop)
            except ValueError:pass
            else:raise AssertionError('Invalid deadline accepted')
            sampler.assert_not_called()
        checks.append(dict(case=stop,status='rejected before sampler invocation'))
    with patch.object(core,'run') as sampler:
        invoke(future);sampler.assert_called_once_with('linear',1,True,future)
    checks.append(dict(case='future deadline and unchanged dependencies',
        status='arguments delegated to mocked sampler; no fitting or checkpoint writes'))
    original_digest=dependencies.digest
    changed=PRIOR/'phase2/fresh_core_forecast_features.csv'
    def altered_digest(path):
        return '0'*64 if Path(path)==changed else original_digest(path)
    with patch.object(dependencies,'digest',side_effect=altered_digest),patch.object(core,'run') as sampler:
        try:invoke(future)
        except ValueError as exc:assert 'dependency changed' in str(exc)
        else:raise AssertionError('Changed dependency accepted')
        sampler.assert_not_called()
    checks.append(dict(case='simulated changed macro-file digest',status='rejected without changing any input file or invoking the sampler'))
    actual_versions=dependencies.versions()
    with patch.object(dependencies,'versions',return_value={**actual_versions,'sklearn':'mismatched'}),patch.object(core,'run') as sampler:
        try:invoke(future)
        except ValueError as exc:assert 'versions differ' in str(exc)
        else:raise AssertionError('Changed library version accepted')
        sampler.assert_not_called()
    checks.append(dict(case='simulated changed model-library version',status='rejected before sampler invocation'))
    destination=OUT/'audits/safe_runner_guard_validation.json'
    archive=OUT/'audits/safe_runner_guard_validation_initial.json'
    if destination.exists() and not archive.exists():shutil.copyfile(destination,archive)
    result=dict(status='passed',checks=checks,code_sha256=digest(script),
        validation_code_sha256=digest(__file__),dependency_validator_sha256=digest(dependencies.__file__),
        source_check=check_sources())
    save_json(destination,result)
    journal('validation','Resume guards reject expired/naive deadlines, altered dependencies and mismatched libraries before sampler invocation')
    print(json.dumps(result,indent=2,default=json_default))


if __name__=='__main__':run()
