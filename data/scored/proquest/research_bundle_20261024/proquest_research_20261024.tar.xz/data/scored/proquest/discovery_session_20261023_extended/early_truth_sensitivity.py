"""Evaluate frozen forecasts against early-mature and revised outcomes.

Early mature means the latest source snapshot strictly before origin+9 months:
the six-month endpoint (origin+5) plus three months is strictly earlier than
that cutoff. This is deliberately not described as a first-release outcome.
"""
from session_utils import *
from proquest_vintages import read_vintage_workbook, VintageSeries
from boundary_rules import below_boundary, corrected_evaluation_truth
from model_data import *

def run():
    check_sources();folder=OUT/'early_truth_sensitivity';folder.mkdir(exist_ok=True)
    targets=HistoricalTargets()
    workbook=BASE/'macro_information/reference/iptMvMd.xlsx'
    receipt=json.loads((workbook.parent/'download_manifest.json').read_text())['IPT']
    if digest(workbook)!=receipt['sha256']:raise ValueError('Original workbook hash differs')
    ip=read_vintage_workbook(workbook,'IPT',cutoff='2012-01-01')
    original=targets.ip.matrix
    common=ip.reindex(index=original.index,columns=original.columns)
    np.testing.assert_allclose(common,original,rtol=0,atol=0,equal_nan=True)
    targets.ip=VintageSeries('IPT',ip)
    manifest=json.loads((OUT/'reference/early_truth/manifest.json').read_text())
    receipts=[]
    for item in manifest['records']:
        if item['status']!='ok':continue
        path=Path(item['file'])
        if digest(path)!=item['sha256']:raise ValueError('Supplementary snapshot changed')
        d=pd.read_csv(path,index_col=0);d.index=pd.PeriodIndex(d.index,freq='M')
        if any(c in targets.u for c in d):raise ValueError('Duplicate supplementary vintage')
        targets.u=targets.u.join(d,how='outer');receipts.append(item)
    origins=pd.period_range('1977-01','2010-12',freq='M');truth_rows=[]
    for task in TASKS:
        final=corrected_evaluation_truth(origins,task)
        for origin,latest in zip(origins,final):
            cutoff=origin+9
            if not origin+5+3<cutoff:raise ValueError('Insufficient maturity buffer')
            name,day,snapshot=targets.snapshot(cutoff,task)
            start,end=origin-1,origin+5
            a,b=snapshot.get(start,np.nan),snapshot.get(end,np.nan)
            if not np.isfinite([a,b]).all() or a<=0:raise ValueError(f'Missing endpoint {task} {origin}')
            value=100*np.log(b/a) if task.startswith('production') else -(b-a)
            continuous=value
            if task.endswith('downturn'):
                value=float(below_boundary(value,-2. if task.startswith('production') else -.5))
            truth_rows.append(dict(origin=origin,task=task,early_truth=value,final_truth=latest,
                early_continuous=continuous,early_start_value=a,early_end_value=b,target_start=start,target_end=end,
                assessment_cutoff=cutoff,vintage=name,vintage_available_by=day,
                revision=latest-value))
    truths=pd.DataFrame(truth_rows)
    truths.to_csv(folder/'outcomes_and_vintages.csv',index=False)
    frames=[]
    for algorithm in ['linear','hist_gradient_boosting','extra_trees','gru']:
        p=pd.read_csv(OUT/'models_boundary_corrected'/algorithm/'predictions_without_truth.csv')
        p.origin=pd.PeriodIndex(p.origin,freq='M')
        frames.append(p[['origin','task','algorithm','arm','prediction']])
    combo=OUT/'benchmark_diagnostics/predictions_without_truth.csv'
    if combo.exists():
        c=pd.read_csv(combo).rename(columns={'rule':'algorithm'})
        c.origin=pd.PeriodIndex(c.origin,freq='M');frames.append(c)
    pred=pd.concat(frames,ignore_index=True).merge(truths,on=['origin','task'],validate='many_to_one')
    metrics=[];gains=[];revision=[]
    for (task,algorithm,arm),g in pred.groupby(['task','algorithm','arm']):
        for vintage in ['early','final']:
            truth=g[vintage+'_truth'];loss=(g.prediction-truth)**2
            metrics.append(dict(task=task,algorithm=algorithm,arm=arm,outcome_vintage=vintage,n=len(g),
                mean_loss=loss.mean(),rmse=np.sqrt(loss.mean()),mae=abs(g.prediction-truth).mean()))
    m=pd.DataFrame(metrics);m.to_csv(folder/'metrics.csv',index=False)
    for (task,algorithm,vintage),g in m.groupby(['task','algorithm','outcome_vintage']):
        losses=g.set_index('arm').mean_loss
        for new,old,name in [('macro_coverage_net','macro_coverage','net_minus_macro_coverage'),
                             ('macro_coverage_net_structure','macro_coverage_net','structure_minus_net')]:
            gains.append(dict(task=task,algorithm=algorithm,outcome_vintage=vintage,comparison=name,
                mean_gain=losses[old]-losses[new],baseline_loss=losses[old],model_loss=losses[new]))
    pd.DataFrame(gains).to_csv(folder/'gains.csv',index=False)
    for task,g in truths.groupby('task'):
        revision.append(dict(task=task,n=len(g),mean_revision=g.revision.mean(),
            mean_absolute_revision=abs(g.revision).mean(),max_absolute_revision=abs(g.revision).max(),
            changed_outcome_months=int((abs(g.revision)>1e-10).sum()),
            early_event_rate=g.early_truth.mean() if task.endswith('downturn') else None,
            final_event_rate=g.final_truth.mean() if task.endswith('downturn') else None))
    pd.DataFrame(revision).to_csv(folder/'revisions.csv',index=False)
    save_json(folder/'completion.json',dict(status='complete',n_origins=408,n_tasks=4,
        definition='Source snapshot strictly before origin+9; target start origin-1 and end origin+5; endpoint+3<cutoff.',
        role='Outcome-vintage sensitivity of previously frozen forecasts. No additional p-value or new primary discovery.',
        limits='Early-mature is not a first-release measure. Source-specific revisions, rebasings and seasonal adjustments can differ.',
        code_sha256=digest(__file__),original_ip_workbook_sha256=digest(workbook),
        supplementary_unemployment_receipts=receipts,source_check=check_sources()))
    journal('early_truth_sensitivity','Evaluated all fixed forecasts against 408 early-mature and final monthly outcomes')
    print(pd.DataFrame(revision).to_string(index=False))
    print(pd.DataFrame(gains).to_string(index=False))

if __name__=='__main__':run()
