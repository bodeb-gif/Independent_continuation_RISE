"""Outcome-free article/paper panels and strictly backward forecast structures."""
import argparse
import json
from collections import Counter
import numpy as np
import pandas as pd
from session_utils import *
from design import STRUCTURES
from analyze_proquest import annual_files
from proquest_panel import sign_label, build_panels
from proquest_descriptive import horizon, paper_name

CALENDAR = pd.period_range('1900-01','2010-12',freq='M')
VALUE = {'positive':1.,'flat':0.,'negative':-1.}
PRINT_COLUMNS = ['record_id','page_id','date','month','paper','topic','sign',
                 'confidence','voice','horizon_used','horizon_basis']

def read_print_claims(source='verified'):
    rows=[]; counts=Counter(); hashes={}
    for path in annual_files(ROOT/f'data/proquest/{source}'):
        hashes[str(path.relative_to(ROOT))]=digest(path)
        year=int(path.name.split('_')[-1].split('.')[0])
        for line_no,line in enumerate(path.read_text().splitlines(),1):
            if not line.strip(): continue
            row=json.loads(line)
            if row.get('no_predictions'): continue
            if row.get('source')!='proquest' or row.get('schema_version')!=2:
                raise ValueError('Wrong source '+str(path))
            if source=='verified' and 'verify_reason' not in row:
                raise ValueError('Missing verification status')
            counts['all_claims']+=1
            if row.get('scope')!='national' or row.get('topic') not in TOPICS: continue
            direction=sign_label(row)
            if direction not in VALUE: continue
            date=pd.Timestamp(row['date'])
            if date.year!=year: raise ValueError('Annual date mismatch')
            months,basis,_=horizon(row)
            rows.append(dict(record_id=f'{source}:{year}:{line_no}',page_id=str(row['page_id']),
                date=str(date.date()),month=date.to_period('M'),
                paper=paper_name(row.get('publisher') or row.get('newspaper_title')),
                topic=row['topic'],sign=direction,confidence=row.get('confidence'),
                voice=row.get('voice'),horizon_used=months,horizon_basis=basis))
    frame=pd.DataFrame(rows,columns=PRINT_COLUMNS)
    counts['readable_national']=len(frame)
    if (frame.groupby('page_id')[['date','paper']].nunique()>1).any().any():
        raise ValueError('Inconsistent article identifiers')
    return frame,dict(counts),hashes

def subset_nets(claims, field):
    """Average labels within article/category, articles within paper/category.

    Contrasts use only paper-months containing both arms, so newspaper mix is
    identical. Article mix within a newspaper can differ, deliberately retained.
    """
    d=claims.copy()
    if field=='term':
        d=d[d.horizon_basis.eq('stated') & d.horizon_used.between(1,24)].copy()
        d['arm']=np.where(d.horizon_used<=6,'short','long')
        a,b='long','short'
    elif field=='confidence':
        d=d[d.confidence.isin(['assertive','hedged'])].copy()
        d['arm']=d.confidence; a,b='assertive','hedged'
    elif field=='voice':
        d=d[d.voice.isin(['expert','journalist'])].copy()
        d['arm']=d.voice; a,b='expert','journalist'
    else: raise ValueError(field)
    d['value']=d.sign.map(VALUE)
    article=d.groupby(['month','paper','topic','page_id','arm']).value.mean()
    paper=article.groupby(['month','paper','topic','arm']).agg(['mean','size'])
    nets=paper['mean'].unstack('arm').reindex(columns=[a,b])
    sizes=paper['size'].unstack('arm').reindex(columns=[a,b])
    # Both arms require two articles in the same paper/month/topic.
    common=nets.where((sizes>=2).all(axis=1)).dropna()
    gap=(common[a]-common[b]).rename(field+'_gap')
    summary=gap.groupby(['month','topic']).agg(['mean','size']).reset_index()
    summary.columns=['month','topic',field+'_gap',field+'_n_papers']
    return summary

def monthly_structures(claims):
    article,paper,national=build_panels(claims)
    # Exact equal-paper variance of +/-1/0 labels, not entropy proxies.
    observed=paper[paper.observed].copy()
    observed['mean_square']=observed.positive_share+observed.negative_share
    observed['within_variance']=observed.mean_square-observed.net_direction**2
    grouped=observed.groupby(['month','topic'])
    variance=grouped.agg(within_paper_variance=('within_variance','mean'),
        between_paper_variance=('net_direction',lambda x:x.var(ddof=0)),
        negative_breadth=('net_direction',lambda x:(x<0).mean())).reset_index()
    d=national.merge(variance,on=['month','topic'],how='left',validate='one_to_one')
    for field in ['term','confidence','voice']:
        d=d.merge(subset_nets(claims,field),on=['month','topic'],how='left',validate='one_to_one')
    d=d.rename(columns={'term_gap':'term_slope'})
    return article,paper,d

def enough(window):
    return ((window.n_articles>0).sum()>=2 and window.n_papers.max()>=2
            and window.n_articles.sum()>=5)

def origin_features(paper, monthly):
    rows=[]
    for topic in TOPICS:
        m=monthly[monthly.topic.eq(topic)].set_index('month').reindex(CALENDAR)
        p=paper[paper.topic.eq(topic)&paper.observed].copy()
        p=p.set_index(['month','paper']).sort_index()
        for origin in CALENDAR:
            window=m.reindex(pd.period_range(origin-3,origin-1,freq='M'))
            rec=dict(origin=origin,topic=topic,year=origin.year,latest_print_month=origin-1,
                n_articles=window.n_articles.sum(),n_papers=window.n_papers.mean(),
                observed_months=int((window.n_articles>0).sum()))
            for name in ['net_direction','flat_share','negative_share']+STRUCTURES:
                rec[name]=np.nan
            if enough(window):
                for col in ['net_direction','flat_share','negative_share',
                            'within_paper_variance','between_paper_variance','negative_breadth']:
                    rec[col]=window[col].mean()
                for field,col in [('term','term_slope'),('confidence','confidence_gap'),('voice','voice_gap')]:
                    supported=window[col].notna() & window[field+'_n_papers'].ge(2)
                    if supported.sum()>=2: rec[col]=window.loc[supported,col].mean()
                previous=m.reindex(pd.period_range(origin-6,origin-4,freq='M'))
                if enough(previous):
                    recent=p.loc[p.index.get_level_values('month').isin(window.index)].groupby('paper').net_direction.mean()
                    prior=p.loc[p.index.get_level_values('month').isin(previous.index)].groupby('paper').net_direction.mean()
                    common=recent.index.intersection(prior.index)
                    if len(common)>=2: rec['revision_common']=(recent.loc[common]-prior.loc[common]).mean()
            rows.append(rec)
    result=pd.DataFrame(rows)
    # Different topic directions retain their documented sign meanings. Prices
    # rising are not called optimism; cross-topic gap is a directional contrast.
    pivot=result.pivot(index='origin',columns='topic',values='net_direction')
    for topic in TOPICS:
        others=pivot.drop(columns=topic)
        cross=pivot[topic]-others.mean(axis=1).where(others.notna().sum(axis=1)>=2)
        mask=result.topic.eq(topic)
        result.loc[mask,'cross_topic_gap']=result.loc[mask,'origin'].map(cross)
    result['net_squared']=result.net_direction**2
    result['log_articles']=np.log1p(result.n_articles)
    if not (result.latest_print_month<result.origin).all(): raise ValueError('Print chronology')
    return result

def build(source='verified',suffix=None,claims=None):
    check_sources(); suffix=suffix or source
    if claims is None:
        claims,counts,hashes=read_print_claims(source)
    else:
        counts={'readable_national':len(claims)};hashes={}
    journal('features','Building strictly backward structures',source=source,variant=suffix,n_claims=len(claims))
    article,paper,monthly=monthly_structures(claims)
    result=origin_features(paper,monthly)
    path=OUT/'cache'/f'features_{suffix}.csv.gz'
    result.to_csv(path,index=False,compression={'method':'gzip','mtime':0})
    monthly.to_csv(OUT/'cache'/f'monthly_{suffix}.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    paper.to_csv(OUT/'cache'/f'paper_{suffix}.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    claims.to_csv(OUT/'cache'/f'print_claims_{suffix}.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    if suffix=='verified':
        old=pd.read_csv(BASE/'monthly_information/national_topic_month.csv.gz')
        old['month']=pd.PeriodIndex(old.month,freq='M')
        z=monthly.merge(old,on=['month','topic'],suffixes=('_new','_old'),validate='one_to_one')
        errors={c:float(np.nanmax(abs(z[c+'_new']-z[c+'_old'])))
                for c in ['net_direction','positive_share','negative_share','flat_share','paper_dispersion']}
        if max(errors.values())>1e-12: raise ValueError('Prior national panel differs')
    else: errors={}
    support=result.groupby('topic')[STRUCTURES+['net_direction']].count().reset_index()
    support.to_csv(OUT/'audits'/f'feature_support_{suffix}.csv',index=False)
    save_json(OUT/'audits'/f'feature_manifest_{suffix}.json',dict(counts=counts,
        input_hashes=hashes,code_sha256=digest(__file__),reproduction_errors=errors,
        n_origins=result.origin.nunique(),feature_path=str(path.relative_to(ROOT))))
    journal('features','Finished feature build',variant=suffix,support=support.to_dict('records'))
    print(support.to_string(index=False),flush=True)
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--source',default='verified',choices=['verified','raw'])
    args=parser.parse_args();build(args.source)
