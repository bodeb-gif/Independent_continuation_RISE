"""Standalone scientific figures; no fitting or selection of forecast models."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from associations import *

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,
    'axes.spines.right':False,'axes.titleweight':'bold','figure.facecolor':'white'})
COLORS={'net_minus_macro_coverage':'#16677a','structure_minus_net':'#c7743a'}

def save(fig,name):
    for extension in ['png','svg']:
        fig.savefig(OUT/'figures'/f'{name}.{extension}',dpi=180,bbox_inches='tight')
    plt.close(fig)

def robustness():
    primary=pd.read_csv(OUT/'structural_tests.csv').set_index('test').loc['structure_employment_cross_topic_gap']
    economic=json.loads((OUT/'audits/economic_scale.json').read_text())
    sigma=economic['other_direction_sd'];ratio=sigma/primary.feature_sd;rows=[]
    paper=pd.read_csv(OUT/'paper_timing_robustness.csv').set_index('variant')
    for key,label in [('primary_reproduced','Primary'),('omit_New York Times','Omit New York Times'),
        ('both_NYT_and_LAT_in_every_used_month','Both NYT and LA Times represented'),
        ('fixed_five_through_2001','Fixed five papers, through 2001'),
        ('year_and_month_effects','Year and calendar-month effects'),
        ('latest_print_t_minus_2_survey_aligned','Earlier news, survey-aligned cutoff')]:
        r=paper.loc[key];rows.append(dict(label=label,effect=-r.effect_per_primary_sd*ratio,
            low=-r.high_per_primary_sd*ratio,high=-r.low_per_primary_sd*ratio,n=r.n))
    cross=pd.read_csv(OUT/'cross_topic_robustness.csv')
    sources=[(cross[cross.source_set.eq('raw')&cross.variant.eq('primary')&cross.block_years.eq(5)].iloc[0],'Raw exports'),
        (cross[cross.source_set.eq('verified')&cross.variant.eq('fresh_vintage_macro')&cross.block_years.eq(5)].iloc[0],'Vintage macro controls'),
        (cross[cross.source_set.eq('verified')&cross.variant.eq('tone_and_macro')&cross.block_years.eq(5)].iloc[0],'Broad news tone + macro, 1980+')]
    survey=pd.read_csv(OUT/'survey_tests.csv').set_index('test').loc['survey_conditional_employment_cross_gap']
    sources.insert(1,(survey,'Survey current and expected conditions'))
    for r,label in sources:
        rows.append(dict(label=label,effect=-r.effect/r.feature_sd*sigma,
            low=-r.high/r.feature_sd*sigma,high=-r.low/r.feature_sd*sigma,n=r.n))
    f=pd.DataFrame(rows);fig,ax=plt.subplots(figsize=(10,6.5),layout='constrained')
    y=np.arange(len(f))[::-1]
    for i,r in enumerate(f.itertuples()):
        ax.errorbar(r.effect,y[i],xerr=[[r.effect-r.low],[r.high-r.effect]],fmt='o',
            color='#164f65' if i==0 else '#458697',capsize=3,ms=6)
    ax.set_yticks(y,[f'{r.label}  (n={int(r.n)})' for r in f.itertuples()])
    ax.axvline(0,color='#555',lw=.9);ax.grid(axis='x',alpha=.18)
    ax.set_xlabel('Associated six-month unemployment improvement (percentage points)\nper original other-topic-index SD, conditional on employment forecasts')
    ax.set_title('The cross-topic association persists; incremental novelty remains uncertain',loc='left',pad=17)
    fig.text(.01,-.04,'Pointwise 95% cluster intervals; all effects use the same original other-topic-index SD. These are robustness variants of one inspected lead, not independent discoveries.',fontsize=8,color='#555')
    save(fig,'cross_topic_robustness')

def partial_relationship():
    f=pd.read_csv(OUT/'audits/structural_analysis_rows.csv.gz')
    d=f[f.test.eq('structure_employment_cross_topic_gap')].copy()
    controls=['net_direction','net_squared','flat_share','log_articles','n_papers']
    x=select_design(d,controls);z=x.drop(columns='tested_predictor').to_numpy(float)
    y=d.employment_growth.to_numpy(float);signal=d.tested_predictor.to_numpy(float)
    yr=y-z@np.linalg.lstsq(z,y,rcond=None)[0]
    xr=-(signal-z@np.linalg.lstsq(z,signal,rcond=None)[0])
    r=pd.read_csv(OUT/'structural_tests.csv').set_index('test').loc['structure_employment_cross_topic_gap']
    economic=json.loads((OUT/'audits/economic_scale.json').read_text())
    ratio=economic['other_direction_sd']/r.feature_sd
    xr=xr/ratio
    beta=-r.effect*ratio;lo=-r.high*ratio;hi=-r.low*ratio
    fig,ax=plt.subplots(figsize=(9,5.5),layout='constrained')
    ax.scatter(xr,yr,s=13,color='#326d86',alpha=.18,linewidths=0)
    p=pd.DataFrame(dict(x=xr,y=yr));p['bin']=pd.qcut(p.x,8,duplicates='drop')
    means=p.groupby('bin',observed=True)[['x','y']].mean()
    ax.scatter(means.x,means.y,s=55,color='#b15d29',edgecolors='white',zorder=4,label='Eight descriptive bins')
    grid=np.linspace(np.quantile(xr,.01),np.quantile(xr,.99),100)
    ax.plot(grid,beta*grid,color='#184e65',lw=2,label='Conditional historical slope')
    ax.fill_between(grid,np.minimum(lo*grid,hi*grid),np.maximum(lo*grid,hi*grid),color='#adcdd6',alpha=.35)
    ax.axhline(0,color='#999',lw=.7);ax.axvline(0,color='#999',lw=.7);ax.grid(alpha=.13)
    ax.set_xlabel('Other-topic directional information after accounting for employment forecasts\n(residual, measured in original other-topic-index SD units)')
    ax.set_ylabel('Subsequent unemployment improvement after controls (pp)')
    ax.set_title('Other economic outlooks contain a labor-market signal',loc='left')
    ax.legend(frameon=False,fontsize=9)
    fig.text(.01,-.05,'694 monthly origins, 1948–2010. Controls: employment net/square, neutral share, coverage, decade effects. Full-sample bins are not forecast rules.',fontsize=8,color='#555')
    save(fig,'cross_topic_partial_relationship')

def ml_gains():
    names={'linear':'Linear','hist_gradient_boosting':'Boosted trees','extra_trees':'Extra trees','gru':'GRU'}
    tables=[]
    for algorithm in names:
        path=OUT/'models_boundary_corrected'/algorithm/'tests.csv'
        if path.exists():tables.append(pd.read_csv(path))
    if len(tables)!=4:return
    f=pd.concat(tables,ignore_index=True);fig,axes=plt.subplots(2,2,figsize=(12,9),layout='constrained')
    tasks=['production_continuous','unemployment_continuous','production_downturn','unemployment_downturn']
    titles=['Industrial production: MSE gain','Unemployment improvement: MSE gain',
        'Production decline: Brier gain','Unemployment rise: Brier gain']
    for ax,task,title in zip(axes.flat,tasks,titles):
        g=f[f.task.eq(task)].copy();labels=[]
        for ai,algorithm in enumerate(names):
            for ci,comparison in enumerate(COLORS):
                r=g[g.algorithm.eq(algorithm)&g.comparison.eq(comparison)].iloc[0]
                y=7-(2*ai+ci);labels.append((y,names[algorithm]+(' · net' if ci==0 else ' · structure')))
                ax.errorbar(r.effect,y,xerr=[[r.effect-r.low],[r.high-r.effect]],fmt='o',color=COLORS[comparison],capsize=3)
        ax.set_yticks([v[0] for v in labels],[v[1] for v in labels],fontsize=9)
        ax.axvline(0,color='#777',lw=.8);ax.grid(axis='x',alpha=.16);ax.set_title(title,loc='left')
        ax.set_xlabel('Positive favors the added newspaper feature group')
    fig.suptitle('No primary model addition survives the full testing correction',fontsize=15,fontweight='bold')
    fig.text(.01,-.025,'408 common origins, 1977–2010. Pointwise five-year-cluster 95% intervals condition on fitted forecasts. Net compares with macro+coverage; structure compares with macro+coverage+net.',fontsize=8,color='#555')
    save(fig,'ml_primary_gains')

def run():
    robustness();partial_relationship();ml_gains()
    journal('figures','Built standalone cross-topic and ML scientific figures')

if __name__=='__main__':run()
