"""Distinguish recent-condition correlations from forward economic associations."""
from common import *
from proquest_descriptive import load_reference
from proquest_vintages import CORE_FEATURES


def main():
    signal=pd.read_csv(OUT/'lagged_topic_signals.csv');signal['origin']=pd.PeriodIndex(signal.origin,freq='M')
    series,_=load_reference();rows=[];tests=[];data=[]
    for topic in ['employment','general_business']:
        s=series[topic];d=signal[signal.topic.eq(topic)].copy()
        d['log_articles']=np.log1p(d.articles)
        for shift in [-12,-6,0,6,12]:
            def target(origin):
                first,last=s.get(origin-1+shift,np.nan),s.get(origin+5+shift,np.nan)
                if not (np.isfinite(first)&np.isfinite(last)):return np.nan
                return -(last-first) if topic=='employment' else 100*np.log(last/first)
            d[f'outcome_{shift}']=d.origin.map(target)
        outcomes=[f'outcome_{shift}' for shift in [-12,-6,0,6,12]]
        d=d.dropna(subset=outcomes+['net_direction','flat_share','papers','log_articles']).copy()
        d['tested_predictor']=(d.net_direction-d.net_direction.mean())/d.net_direction.std()
        data.append(d)
        for shift in [-12,-6,0,6,12]:
            rr,fit,_=regression(d,f'outcome_{shift}',['tested_predictor'],['log_articles','papers','flat_share'])
            rec=rr[0];critical=st.t.ppf(1-.05/(2*5),rec['n_blocks']-1)
            rec['simultaneous_low']=rec['effect']-critical*rec['se']
            rec['simultaneous_high']=rec['effect']+critical*rec['se']
            rows.append(dict(topic=topic,shift_months=shift,**rec))
        d['future_minus_past']=d['outcome_0']-d['outcome_-6']
        rr,_,_=regression(d,'future_minus_past',['tested_predictor'],['log_articles','papers','flat_share'])
        tests.append(dict(test=f'{topic}_future_vs_recent_slope',batch='timing',**rr[0]))
    pd.DataFrame(rows).to_csv(OUT/'lead_lag_profiles.csv',index=False)
    pd.concat(data).to_csv(OUT/'lead_lag_analysis_data.csv',index=False)
    tests=adjust(pd.DataFrame(tests),2);tests.to_csv(OUT/'timing_tests.csv',index=False)
    session=adjust(pd.concat([pd.read_csv(OUT/'session_wide_46_tests.csv'),tests],ignore_index=True),48)
    session.to_csv(OUT/'session_wide_48_tests.csv',index=False)
    predictions=pd.read_csv(OUT/'backtest_predictions_alpha10.csv');predictions['origin']=pd.PeriodIndex(predictions.origin,freq='M')
    macro=pd.read_csv(BASE/'macro_information/macro_feature_audit.csv');macro['origin']=pd.PeriodIndex(macro.origin,freq='M')
    predictions=predictions.merge(macro[['origin','unemployment_age_months']],on='origin',validate='many_to_one')
    diag=[]
    for task,g in predictions.groupby('task'):
        for name,mask in [('fresh_quarterly_snapshot',g.origin.dt.month.isin([3,6,9,12])),('other_months',~g.origin.dt.month.isin([3,6,9,12]))]:
            z=g[mask]
            for model in ['macro_jobs','macro_business','macro_both']:
                gain=(z.macro-z.truth)**2-(z[model]-z.truth)**2
                r=clustered_mean(gain,np.ones(len(gain)),z.origin.dt.year,5,anchor=1977)
                diag.append(dict(task=task,subset=name,model=model,mean_unemployment_age=z.unemployment_age_months.mean(),**r))
    pd.DataFrame(diag).to_csv(OUT/'fresh_vintage_backtest_diagnostic.csv',index=False)
    d=signal[signal.topic.eq('employment')].merge(macro[['origin']+list(CORE_FEATURES)],on='origin',validate='one_to_one')
    d['log_articles']=np.log1p(d.articles)
    d['tested_predictor']=(d.net_direction-d.net_direction.mean())/d.net_direction.std()
    truth=pd.read_csv(OUT/'continuous_targets.csv');truth['origin']=pd.PeriodIndex(truth.origin,freq='M')
    d=d.merge(truth[['origin','employment_growth']],on='origin')
    checks=[]
    for name,mask in [('fresh_quarterly_snapshot',d.origin.dt.month.isin([3,6,9,12])),('other_months',~d.origin.dt.month.isin([3,6,9,12]))]:
        rr,_,_=regression(d[mask],'employment_growth',['tested_predictor'],['log_articles','papers','flat_share']+list(CORE_FEATURES))
        checks.append(dict(subset=name,**rr[0]))
    pd.DataFrame(checks).to_csv(OUT/'fresh_vintage_associations.csv',index=False)
    print(pd.DataFrame(rows)[['topic','shift_months','effect','low','high','simultaneous_low','simultaneous_high','p_value','n']].to_string(index=False))
    print(tests.to_string(index=False));print(pd.DataFrame(checks).to_string(index=False))


if __name__=='__main__':main()
