"""Additional descriptive checks of existing results; no model fitting."""
from pathlib import Path
import hashlib,itertools,json
import numpy as np
import pandas as pd
from statsmodels.stats.multitest import multipletests
ROOT=Path(__file__).resolve().parents[4];OUT=Path(__file__).resolve().parent;BASE=ROOT/'data/scored/proquest'
files=[BASE/'descriptive/scored_claims.csv.gz',BASE/'polarization/monthly/macro_benchmark_core/predictions.csv',OUT/'specification.json']
f=pd.read_csv(files[0],low_memory=False);f=f[f.hit.notna()].copy();assert len(f)==175855
f['w']=1/f.groupby('page_id').page_id.transform('size');assert np.isclose(f.w.sum(),f.page_id.nunique())
f['weighted_hit']=f.w*f.hit;f['weighted_baseline']=f.w*f.fixed_baseline_hit
means=[]
for length in [2,5,10]:
    totals=f.groupby((f.year-1900)//length)[['weighted_hit','weighted_baseline','w']].sum().to_numpy()
    rng=np.random.default_rng(20261022);draw=rng.integers(0,len(totals),(5000,len(totals)));s=totals[draw].sum(axis=1)
    for i,name in enumerate(['accuracy','baseline_accuracy']):
        lo,hi=np.quantile(s[:,i]/s[:,2],[.025,.975]);means.append(dict(measure=name,block_years=length,n_blocks=len(totals),estimate=totals[:,i].sum()/totals[:,2].sum(),low=lo,high=hi))
assert np.isclose(means[0]['estimate'],.40899117554304637)
p=pd.read_csv(files[1]);y=np.column_stack([p.target.eq(c).astype(float) for c in ['fall','flat','rise']]);p['year']=pd.to_datetime(p.origin).dt.year
losses={}
for arm in ['baseline','political','forecast','both']:
    probs=p[[f'macro_plus_press__{arm}__{c}' for c in ['fall','flat','rise']]].to_numpy();assert np.allclose(probs.sum(axis=1),1)
    losses[arm]=((probs-y)**2).sum(axis=1)
rows=[]
for anchor in [int(p.year.min()),1900]:
    for scope,mask in [('overall',np.ones(len(p),dtype=bool)),('exclude_2007_2009',~p.year.between(2007,2009))]:
        for arm in ['political','forecast','both']:
            diff=losses[arm][mask]-losses['baseline'][mask]
            group=pd.DataFrame({'d':diff,'block':((p.loc[mask,'year']-anchor)//5).to_numpy()}).groupby('block').d.agg(['sum','count'])
            flips=np.asarray(list(itertools.product([-1,1],repeat=len(group))))
            null=flips@group['sum'].to_numpy()/group['count'].sum();point=float(diff.mean());pv=float(np.mean(np.abs(null)>=abs(point)-1e-12))
            rows.append(dict(block_anchor=anchor,scope=scope,arm=arm,n_months=len(diff),n_blocks=len(group),baseline_brier=float(losses['baseline'][mask].mean()),augmented_brier=float(losses[arm][mask].mean()),brier_deterioration=point,exact_block_p=pv))
r=pd.DataFrame(rows)
for anchor in r.block_anchor.unique():
    for scope in r.scope.unique():
        mask=r.scope.eq(scope)&r.block_anchor.eq(anchor);r.loc[mask,'holm_p_three_arms']=multipletests(r.loc[mask,'exact_block_p'],method='holm')[1]
r.to_csv(OUT/'saved_polarization_model_checks.csv',index=False);pd.DataFrame(means).to_csv(OUT/'mean_accuracy_intervals.csv',index=False)
d={'mean_accuracy':means,'saved_polarization_model_checks':r.to_dict('records'),'scope':'Exploratory retrospective checks; conditional on fixed machine labels and fitted predictions. Three model-arm tests form a separate specified family, not a correction for all historical model experiments.','source_sha256':{str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files+[Path(__file__)]}}
(OUT/'saved_checks_summary.json').write_text(json.dumps(d,indent=2)+'\n');print(pd.DataFrame(means).to_string(index=False));print(r.to_string(index=False))
