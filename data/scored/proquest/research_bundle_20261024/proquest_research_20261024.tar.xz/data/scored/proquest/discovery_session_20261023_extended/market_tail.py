"""New stock-price-tail task; backward information and chronological selection."""
import argparse
import time
import joblib
from monthly_ml import configurations,fallback,fit_predict,GRID
from model_data import feature_frame,COVERAGE,NET,STRUCTURE
from session_utils import *
from proquest_descriptive import load_reference
from threadpoolctl import threadpool_limits

TASK='market_downturn'
FINANCIAL=[f'stock_return_{m}m' for m in [1,3,6,12]]+['stock_volatility_12m','stock_drawdown_12m']
ARMS={'financial_coverage':FINANCIAL+COVERAGE,
      'financial_coverage_net':FINANCIAL+COVERAGE+NET,
      'financial_coverage_net_structure':FINANCIAL+COVERAGE+NET+STRUCTURE}

def inputs(source='verified'):
    f,_=feature_frame(source);series,metadata=load_reference();s=series['markets']
    for m in [1,3,6,12]:
        f[f'stock_return_{m}m']=[100*np.log(s.get(o-1,np.nan)/s.get(o-1-m,np.nan)) for o in f.index]
    vol=[];drawdown=[]
    for o in f.index:
        prices=s.reindex(pd.period_range(o-13,o-1,freq='M'))
        vol.append(float(np.diff(np.log(prices)).std(ddof=0)*np.sqrt(12)*100))
        drawdown.append(float(100*(prices.iloc[-1]/prices.iloc[-12:].max()-1)))
    f['stock_volatility_12m']=vol;f['stock_drawdown_12m']=drawdown
    valid=pd.period_range('1901-01','2010-12',freq='M')
    if not np.isfinite(f.loc[valid,FINANCIAL]).all().all():raise ValueError('Missing prior price history')
    return f,valid,s,metadata['markets']

def labels(valid,cutoff,s,window=None):
    cutoff=pd.Period(cutoff,freq='M');origins=valid[valid+8<cutoff]
    if window:origins=origins[origins>=cutoff-12*window]
    y=np.array([100*np.log(s.loc[o+5]/s.loc[o-1]) < -10. for o in origins],float)
    return origins,y

def choose(algorithm,arm,frame,valid,s,outer,logs):
    known,known_y=labels(valid,outer,s);truth=pd.Series(known_y,index=known)
    folds=[]
    for lag in [6,4,2]:
        inner=outer-lag*12;train,_=labels(valid,inner,s)
        val=known[(known>=inner)&(known<=inner+23)]
        if len(train)>=120 and len(val):folds.append((inner,val))
    if len(folds)<2 or sum(len(v) for _,v in folds)<24:return fallback(algorithm),True
    configs=configurations(algorithm,TASK);scores=[]
    for ci,config in enumerate(configs):
        losses=[]
        for inner,val in folds:
            train,y=labels(valid,inner,s,config['window'])
            p,_=fit_predict(algorithm,TASK,config,frame,train,y,val,ARMS[arm],113+inner.year)
            loss=(p-truth.loc[val].to_numpy(float))**2;losses.extend(loss)
            logs.append(dict(outer=str(outer),arm=arm,candidate=ci,configuration=json.dumps(config,sort_keys=True),
                inner=str(inner),n_training=len(train),last_training=str(train.max()),
                validation_first=str(val.min()),validation_last=str(val.max()),n_validation=len(val),loss=loss.mean()))
        scores.append(float(np.mean(losses)))
    return configs[int(np.argmin(scores))],False

def run(algorithm):
    start=time.monotonic();check_sources();frame,valid,s,metadata=inputs()
    folder=OUT/'models'/('market_tail_'+algorithm);folder.mkdir(exist_ok=True)
    annual=folder/'annual';annual.mkdir(exist_ok=True)
    record={str(p.relative_to(ROOT)):digest(p) for p in [Path(__file__),OUT/'monthly_ml.py',OUT/'model_data.py',
        OUT/'specs/market_tail.json',OUT/'specs/ml_grid.json',OUT/'cache/features_verified.csv.gz']}
    if algorithm=='gru':record[str((OUT/'recurrent_ml.py').relative_to(ROOT))]=digest(OUT/'recurrent_ml.py')
    record['market_reference']=metadata['sha256']
    if (folder/'run_inputs.json').exists() and json.loads((folder/'run_inputs.json').read_text())!=record:
        raise ValueError('Changed market experiment inputs')
    save_json(folder/'run_inputs.json',record)
    predictions=[];audits=[]
    for year in range(1930,2011):
        outer=pd.Period(f'{year}-01','M');test=valid[valid.year==year]
        for arm in ARMS:
            stem=f'{year}_{arm}';pp=annual/(stem+'.csv');ap=annual/(stem+'.json')
            if pp.exists() and ap.exists():
                pred=pd.read_csv(pp);pred['origin']=pd.PeriodIndex(pred.origin,freq='M')
                predictions.append(pred);audits.append(json.loads(ap.read_text()));continue
            log=[];config,is_default=choose(algorithm,arm,frame,valid,s,outer,log)
            train,y=labels(valid,outer,s,config['window']);seeds=GRID['gru']['seeds'] if algorithm=='gru' else [113]
            values=[];bundles=[]
            for seed in seeds:
                p,b=fit_predict(algorithm,TASK,config,frame,train,y,test,ARMS[arm],seed+year,return_model=year==2010)
                values.append(p)
                if b is not None:bundles.append(b)
            pred=pd.DataFrame(dict(origin=test,algorithm=algorithm,arm=arm,prediction=np.mean(values,axis=0)))
            for seed,p in zip(seeds,values):pred[f'seed_{seed}']=p
            pred.to_csv(pp,index=False);predictions.append(pred)
            audit=dict(year=year,algorithm=algorithm,arm=arm,configuration=config,fallback=is_default,
                n_training=len(train),last_training=str(train.max()),last_training_endpoint=str((train+5).max()),
                training_event_rate=y.mean(),n_evaluation=len(test))
            save_json(ap,audit);audits.append(audit)
            if log:pd.DataFrame(log).to_csv(annual/(stem+'_inner.csv'),index=False)
            if bundles:joblib.dump(dict(audit=audit,bundles=bundles),folder/f'{arm}_2010.joblib')
        print(algorithm,year,'complete',round(time.monotonic()-start,1),'seconds',flush=True)
        journal('market_tail','Completed annual stock-tail forecasts',algorithm=algorithm,year=year)
    pred=pd.concat(predictions,ignore_index=True)
    pred.to_csv(folder/'predictions_without_truth.csv',index=False)
    pred['truth']=[float(100*np.log(s.loc[o+5]/s.loc[o-1]) < -10.) for o in pred.origin]
    pred['loss']=(pred.prediction-pred.truth)**2;pred.to_csv(folder/'predictions.csv',index=False)
    pd.DataFrame(audits).to_csv(folder/'refits.csv',index=False)
    loss=pred.pivot(index='origin',columns='arm',values='loss');tests=[];sensitivity=[]
    for newer,older,label in [('financial_coverage_net','financial_coverage','net_minus_financial_coverage'),
        ('financial_coverage_net_structure','financial_coverage_net','structure_minus_net')]:
        gain=loss[older]-loss[newer];name=f'market_tail_{algorithm}_{label}'
        r=mean_inference(gain,loss.index.year,anchor=1930)
        tests.append(dict(test=name,batch='market_tail',algorithm=algorithm,task=TASK,comparison=label,**r))
        for span in [2,10]:
            rr=mean_inference(gain,loss.index.year,span=span,anchor=1930)
            sensitivity.append(dict(test=name,variant=f'blocks_{span}',**rr))
        for name2,mask in [('exclude_2007_2009',~loss.index.year.isin([2007,2008,2009])),
            ('1930_1969',loss.index.year<1970),('1970_2010',loss.index.year>=1970)]:
            rr=mean_inference(gain[mask],loss.index.year[mask],anchor=1930)
            sensitivity.append(dict(test=name,variant=name2,**rr))
    result=adjust(pd.DataFrame(tests),94);result.to_csv(folder/'tests.csv',index=False)
    pd.DataFrame(sensitivity).to_csv(folder/'sensitivities.csv',index=False)
    metrics=pred.groupby('arm').agg(n=('loss','size'),brier=('loss','mean'),event_rate=('truth','mean'),mean_probability=('prediction','mean')).reset_index()
    metrics.to_csv(folder/'metrics.csv',index=False)
    save_json(folder/'completion.json',dict(status='complete',n_tests=2,n_months=972,algorithm=algorithm,
        elapsed_seconds=time.monotonic()-start,input_hashes=record,source_count=check_sources(),
        limitation='Retrospective broad-market proxy reconstruction; no exact historical index-vintage or trading-performance claim.'))
    print(metrics.to_string(index=False));print(result[['test','effect','low','high','p_value','holm_p','n_blocks']].to_string(index=False))
    journal('market_tail','Completed stock-tail algorithm',algorithm=algorithm,n_tests=2)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--algorithm',required=True,choices=['linear','hist_gradient_boosting','extra_trees','gru'])
    args=parser.parse_args()
    with threadpool_limits(limits=1):run(args.algorithm)
