"""Stronger chronological model-combination benchmarks, descriptive only.

This combination rule was chosen after viewing the original model results.
No new significance claim or untouched holdout is attributed to it.
"""
from boundary_rules import corrected_evaluation_truth
from model_data import *

ALGORITHMS=['linear','hist_gradient_boosting','extra_trees','gru']

def run():
    folder=OUT/'benchmark_diagnostics';folder.mkdir(exist_ok=True)
    choices=[];forecasts=[];inputs={}
    for task in TASKS:
        for year in range(1977,2011):
            for arm in ARMS:
                candidates=[];predictions={};supports=[]
                stem=f'{task}_{arm}_{year}'
                for algorithm in ALGORITHMS:
                    directory=OUT/'models_boundary_corrected'/algorithm/'annual'
                    path=directory/(stem+'.csv');auditpath=directory/(stem+'.json')
                    p=pd.read_csv(path).set_index('origin').prediction
                    predictions[algorithm]=p
                    audit=json.loads(auditpath.read_text())
                    cvpath=directory/(stem+'_inner.csv')
                    inputs[str(path.relative_to(ROOT))]=digest(path)
                    inputs[str(auditpath.relative_to(ROOT))]=digest(auditpath)
                    if cvpath.exists():
                        cv=pd.read_csv(cvpath)
                        inputs[str(cvpath.relative_to(ROOT))]=digest(cvpath)
                        support=sorted(set(zip(cv.inner,cv.validation_first,cv.validation_last,cv.n_validation)))
                        supports.append(support)
                        scores=cv.assign(total=cv.loss*cv.n_validation).groupby('candidate')[['total','n_validation']].sum()
                        scores['score']=scores.total/scores.n_validation
                        winner=scores.score.idxmin();score=float(scores.loc[winner,'score'])
                        chosen=json.loads(cv.loc[cv.candidate.eq(winner),'configuration'].iloc[0])
                        if chosen!=audit['configuration']:raise ValueError('Saved setting differs from inner winner')
                    else:
                        if not audit['fallback']:raise ValueError('Missing selection record')
                        score=np.nan
                    candidates.append(dict(algorithm=algorithm,score=score))
                if supports and not all(s==supports[0] for s in supports):
                    raise ValueError('Unequal algorithm selection support')
                finite=[x for x in candidates if np.isfinite(x['score'])]
                if finite and len(finite)!=len(ALGORITHMS):raise ValueError('Partial comparison')
                selected=min(finite,key=lambda x:(x['score'],ALGORITHMS.index(x['algorithm'])))['algorithm'] if finite else 'linear'
                matrix=pd.DataFrame(predictions)
                if len(matrix)!=12 or matrix.isna().any().any():raise ValueError('Prediction support differs')
                for rule,values in [('prior_cv_family',matrix[selected]),('fixed_equal_ensemble',matrix.mean(axis=1))]:
                    for origin,prediction in values.items():
                        forecasts.append(dict(origin=origin,task=task,arm=arm,rule=rule,prediction=prediction))
                choices.extend(dict(task=task,year=year,arm=arm,selected=selected,
                    fallback=not bool(finite),**candidate) for candidate in candidates)
    # Save the complete rule, choices and predictions before attaching truth.
    save_json(folder/'design.json',dict(created_utc=dt.datetime.now(dt.timezone.utc),
        role='Post-inspection descriptive sensitivity; no additional p-value or discovery claim.',
        rules=['Minimum prior inner-CV loss among all four model families, separately for each year/arm/task; ties use declared order; common fallback linear.',
               'Equal weight of all four model-family point forecasts, fixed before truth attachment.'],
        algorithms=ALGORITHMS,code_sha256=digest(__file__),input_hashes=inputs))
    pd.DataFrame(choices).to_csv(folder/'choices.csv',index=False)
    pred=pd.DataFrame(forecasts);pred.to_csv(folder/'predictions_without_truth.csv',index=False)
    for task in TASKS:
        mask=pred.task.eq(task)
        pred.loc[mask,'truth']=corrected_evaluation_truth(pd.PeriodIndex(pred.loc[mask,'origin'],freq='M'),task)
    pred['loss']=(pred.prediction-pred.truth)**2
    pred.to_csv(folder/'predictions.csv',index=False)
    metrics=[];blocks=[]
    for (task,rule),g in pred.groupby(['task','rule']):
        loss=g.pivot(index='origin',columns='arm',values='loss')
        for arm,sub in g.groupby('arm'):
            metrics.append(dict(task=task,rule=rule,arm=arm,n=len(sub),mean_loss=sub.loss.mean(),
                rmse=np.sqrt(sub.loss.mean()),mae=abs(sub.prediction-sub.truth).mean()))
        for new,old,name in [('macro_coverage_net','macro_coverage','net_minus_macro_coverage'),
                             ('macro_coverage_net_structure','macro_coverage_net','structure_minus_net')]:
            gain=loss[old]-loss[new];years=pd.PeriodIndex(gain.index,freq='M').year
            for block in np.unique((years-1977)//5):
                use=(years-1977)//5==block
                blocks.append(dict(task=task,rule=rule,comparison=name,block=int(block),n=int(use.sum()),
                    mean_gain=gain[use].mean()))
    pd.DataFrame(metrics).to_csv(folder/'metrics.csv',index=False)
    pd.DataFrame(blocks).to_csv(folder/'block_gains.csv',index=False)
    save_json(folder/'completion.json',dict(status='complete',n_predictions=len(pred),source_check=check_sources(),
        limits='Descriptive diagnostics selected after the original historical results were viewed; no new inferential rejection is claimed.'))
    journal('benchmark_diagnostics','Completed prior-CV family choice and fixed equal ensemble, without new significance tests')
    print(pd.DataFrame(metrics).to_string(index=False))

if __name__=='__main__':run()
