"""Historical macro archives for second-phase experiments; no current fallback."""
from pathlib import Path
import sys
import re
import json
from zipfile import ZipFile
import io
import numpy as np
import pandas as pd

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from common import ROOT, BASE, OUT as SESSION, digest
from proquest_vintages import xlsx_rows

OUT=Path(__file__).resolve().parent


class AlfredUnemployment:
    """Exact requested as-of day before each origin, with provider CSV header."""
    def __init__(self,require_complete=True):
        self.folder=SESSION/'reference/alfred_unrate_monthly'
        bulk=SESSION/'reference/alfred_UNRATE_month_end_1960_2010.zip'
        if bulk.exists():
            self._load_bulk(bulk)
            return
        manifest=json.loads((self.folder/'manifest_full.json').read_text())
        records=manifest['records']
        if require_complete and (len(records)!=609 or any(r['status']!='ok' for r in records)):
            raise ValueError('ALFRED archive is incomplete')
        self.records={r['origin']:r for r in records if r['status']=='ok'}
        self.dates={r['requested_asof']:pd.Timestamp(r['requested_asof']) for r in self.records.values()}
        self.cache={}

    def _load_bulk(self,path):
        receipt=json.loads(path.with_suffix('.manifest.json').read_text())
        if digest(path)!=receipt['sha256']:raise ValueError('Bulk ALFRED source hash changed')
        frames=[]
        with ZipFile(path) as z:
            for member in z.namelist():
                if member.endswith('.csv'):frames.append(pd.read_csv(io.BytesIO(z.read(member)),index_col=0))
        matrix=pd.concat(frames,axis=1)
        matrix.index=pd.PeriodIndex(matrix.index,freq='M')
        if not matrix.index.is_unique or not matrix.columns.is_unique:raise ValueError('Duplicate bulk archive coordinates')
        self.records={};self.dates={};self.cache={};checks=0;maximum=0.
        origins=pd.period_range('1960-04','2010-12',freq='M')
        for origin in origins:
            day=str((origin-1).end_time.date());column='UNRATE_'+day.replace('-','')
            if column not in matrix:raise ValueError('Missing requested bulk vintage '+column)
            s=pd.to_numeric(matrix[column],errors='coerce').dropna()
            if s.empty or s.index.max()>=origin or not s.between(0,30).all():raise ValueError('Bulk archive availability/units failure')
            graph=self.folder/(column+'.csv')
            if graph.exists():
                f=pd.read_csv(graph);v=pd.Series(pd.to_numeric(f[column],errors='coerce').to_numpy(),index=pd.PeriodIndex(f.observation_date,freq='M')).dropna()
                if not s.index.equals(v.index):raise ValueError('Bulk and graph snapshot coverage differ')
                delta=float(np.abs(s-v).max());maximum=max(maximum,delta);checks+=1
                if delta>1e-12:raise ValueError('Bulk and graph vintage values differ')
            key=str(origin);self.cache[key]=s;self.dates[day]=pd.Timestamp(day)
            self.records[key]=dict(origin=key,requested_asof=day,source_kind='original provider bulk ZIP column',
                                   archive=str(path),column=column,latest_observation=str(s.index.max()),
                                   n_observations=len(s),age_months=origin.ordinal-s.index.max().ordinal)
        if len(matrix.columns)!=609:raise ValueError('Unexpected bulk vintage count')
        audit=dict(source_archive_sha256=receipt['sha256'],n_requested_dates=609,n_validated_dates=len(self.records),
                   graph_snapshots_crosschecked=checks,maximum_crosscheck_difference=maximum,
                   chronology='Every last observed month is strictly before the forecast origin; requested as-of date is the prior calendar day.')
        (OUT/'alfred_bulk_validation.json').write_text(json.dumps(audit,indent=2)+'\n')

    def snapshot(self,origin):
        origin=pd.Period(origin,'M');key=str(origin)
        if key not in self.records:raise ValueError('No exact prior as-of snapshot for '+key)
        r=self.records[key];day=r['requested_asof']
        assert pd.Timestamp(day)<origin.start_time
        if key not in self.cache:
            path=self.folder/Path(r['file']).name
            if digest(path)!=r['sha256']:raise ValueError('ALFRED source hash changed: '+str(path))
            f=pd.read_csv(path);expected='UNRATE_'+day.replace('-','')
            if list(f)!=['observation_date',expected]:raise ValueError('Wrong ALFRED vintage header')
            s=pd.Series(pd.to_numeric(f[expected],errors='coerce').to_numpy(),index=pd.PeriodIndex(f.observation_date,freq='M')).dropna()
            if not s.index.is_unique or s.index.max()>=origin:raise ValueError('ALFRED observation chronology failure')
            self.cache[key]=s
        return day,self.cache[key]

    def features(self,origins):
        records=[]
        for origin in origins:
            day,snapshot=self.snapshot(origin);latest=snapshot.index.max();last=snapshot.loc[latest]
            rec=dict(origin=origin,unemployment_level=last,unemployment_age_months=origin.ordinal-latest.ordinal,
                     UNRATE_asof=day,UNRATE_latest_observation=latest)
            for months in [1,3,6,12]:
                rec[f'unemployment_change_{months}m']=last-snapshot.get(latest-months,np.nan)
            changes=snapshot.reindex(pd.period_range(latest-12,latest,freq='M')).diff().dropna()
            rec['unemployment_volatility_12m']=changes.std(ddof=0) if len(changes)==12 else np.nan
            records.append(rec)
        return pd.DataFrame(records)


class RealOutputArchive:
    """Quarterly GNP/GDP observations in monthly midmonth historical vintages."""
    def __init__(self):
        path=SESSION/'reference/routputMvQd.xlsx'
        rows=iter(xlsx_rows(path));header=next(rows)
        assert header.get('A')=='DATE'
        columns={};self.dates={}
        for col,name in header.items():
            if col=='A':continue
            match=re.fullmatch(r'ROUTPUT(\d{2})M(\d{1,2})',name or '')
            if not match:raise ValueError('Unrecognized GDP vintage '+str(name))
            yy,month=map(int,match.groups());year=1900+yy if yy>=65 else 2000+yy
            day=pd.Timestamp(year,month,15)
            if day<pd.Timestamp('2010-12-01'):
                columns[col]=name;self.dates[name]=day
        observations=[];values=[]
        for row in rows:
            if not row.get('A'):continue
            quarter=pd.Period(row['A'].replace(':',''),freq='Q')
            if quarter>pd.Period('2010Q4',freq='Q'):continue
            observations.append(quarter)
            values.append([float(row[c]) if row.get(c) not in {None,'','#N/A','NA'} else np.nan for c in columns])
        self.matrix=pd.DataFrame(values,index=pd.PeriodIndex(observations,freq='Q'),columns=list(columns.values()))
        assert self.matrix.index.is_unique and self.matrix.columns.is_unique
        if (self.matrix.stack()<0).any():raise ValueError('Nonpositive real output levels')
        self.source_hash=digest(path)

    def snapshot(self,origin):
        origin=pd.Period(origin,'M');available=[c for c in self.matrix if self.dates[c]<origin.start_time and self.matrix[c].notna().any()]
        if not available:return None,None
        key=max(available,key=self.dates.get);s=self.matrix[key].dropna()
        if s.index.max().asfreq('M','end')>=origin:raise ValueError('Current/future quarter in GDP snapshot')
        return key,s

    def features(self,origins):
        records=[]
        for origin in origins:
            key,snapshot=self.snapshot(origin)
            if key is None:
                records.append(dict(origin=origin));continue
            latest=snapshot.index.max();last=snapshot.loc[latest]
            rec=dict(origin=origin,real_output_vintage=key,real_output_available_by=self.dates[key],
                     real_output_latest_quarter=latest,real_output_age_months=origin.ordinal-latest.asfreq('M','end').ordinal,
                     real_output_quantity='GNP' if self.dates[key]<pd.Timestamp('1991-12-01') else 'GDP')
            for quarters in [1,2,4]:
                earlier=snapshot.get(latest-quarters,np.nan)
                rec[f'real_output_growth_{quarters}q']=100*np.log(last/earlier) if np.isfinite(earlier) and earlier>0 else np.nan
            records.append(rec)
        return pd.DataFrame(records)


def source_audit():
    u=AlfredUnemployment();gdp=RealOutputArchive()
    origins=pd.period_range('1960-04','2010-12',freq='M')
    fresh=u.features(origins);fresh.to_csv(OUT/'fresh_unemployment_features.csv',index=False)
    gp=gdp.features(pd.period_range('1965-12','2010-12',freq='M'))
    gp.to_csv(OUT/'real_output_features.csv',index=False)
    gdp.matrix.rename_axis('observation_quarter').to_csv(OUT/'real_output_vintages_through_2010.csv.gz',compression={'method':'gzip','mtime':0})
    old=pd.read_csv(BASE/'macro_information/macro_feature_audit.csv');old['origin']=pd.PeriodIndex(old.origin,freq='M')
    paired=old[['origin','unemployment_level','unemployment_change_3m','unemployment_change_12m','unemployment_age_months']].merge(fresh,on='origin',suffixes=('_quarterly','_monthly'),validate='one_to_one')
    for name in ['unemployment_level','unemployment_change_3m','unemployment_change_12m','unemployment_age_months']:
        paired[name+'_fresh_minus_old']=paired[name+'_monthly']-paired[name+'_quarterly']
    paired.to_csv(OUT/'unemployment_vintage_comparison.csv',index=False)
    manifest=dict(unrate_origins=len(fresh),unrate_first=str(fresh.origin.min()),unrate_last=str(fresh.origin.max()),
                  unrate_age_distribution={str(k):int(v) for k,v in fresh.unemployment_age_months.value_counts().sort_index().items()},
                  gdp_source_sha256=gdp.source_hash,gdp_vintages=len(gdp.matrix.columns),
                  caveat='ROUTPUT is GNP until November 1991, GDP from December 1991; midmonth snapshots may omit later same-month revisions.')
    (OUT/'vintage_data_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps(manifest,indent=2))


if __name__=='__main__':source_audit()
