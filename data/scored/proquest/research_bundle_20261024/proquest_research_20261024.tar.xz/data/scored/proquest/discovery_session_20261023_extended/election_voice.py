"""Election-calendar changes in matched official-minus-expert forecast labels."""
from associations import *

SPEC=json.loads((OUT/'specs/election_voice.json').read_text())
KEYS=['paper','month','topic','horizon_used','horizon_basis']

def metric_cells(source,metric):
    f=pd.read_csv(OUT/'cache'/f'print_claims_{source}.csv.gz',dtype={'page_id':str})
    f['month']=pd.PeriodIndex(f.month,freq='M')
    f=f[f.voice.isin(['official','expert'])&f.horizon_used.between(1,24)].copy()
    if metric=='direction_gap':f['value']=f.sign.map({'positive':1.,'negative':-1.,'flat':0.})
    elif metric=='assertiveness_gap':
        f=f[f.confidence.isin(['assertive','hedged'])].copy();f['value']=f.confidence.eq('assertive').astype(float)
    elif metric=='accuracy_gap':
        path=BASE/('descriptive/scored_claims.csv.gz' if source=='verified' else 'robustness/scored_claims.csv.gz')
        scores=pd.read_csv(path,usecols=['record_id','hit','basis']+(['source_set'] if source=='raw' else []))
        if source=='raw':scores=scores[scores.source_set.eq('raw')]
        scores['key']=scores.record_id.astype(str).str.replace(r'^(?:verified|raw):','',regex=True)
        f['key']=f.record_id.str.replace(r'^(?:verified|raw):','',regex=True)
        f=f.merge(scores[['key','hit','basis']],on='key',validate='one_to_one')
        f=f[f.hit.notna()&f.basis.ne('NBER proxy')].copy();f['value']=f.hit
    else:raise ValueError(metric)
    article=f.groupby(KEYS+['voice','page_id']).value.mean().reset_index()
    g=article.groupby(KEYS+['voice']).value.agg(['mean','size'])
    means=g['mean'].unstack('voice').reindex(columns=['official','expert'])
    sizes=g['size'].unstack('voice').reindex(columns=['official','expert'])
    good=sizes.ge(2).all(axis=1)&means.notna().all(axis=1)
    means=means[good];sizes=sizes[good]
    cells=(means.official-means.expert).rename('difference').to_frame()
    cells['weight']=2*sizes.official*sizes.expert/(sizes.official+sizes.expert)
    cells['official_mean']=means.official;cells['expert_mean']=means.expert
    cells['official_articles']=sizes.official;cells['expert_articles']=sizes.expert
    cells=cells.reset_index();cells['year']=cells.month.dt.year
    cells['calendar_month']=cells.month.dt.month
    cells['preelection']=((cells.year%4==0)&cells.calendar_month.between(5,10)).astype(float)
    return cells

def design(cells):
    d=cells.copy();x=d[['preelection']].rename(columns={'preelection':'tested_predictor'})
    for column in ['paper','year','calendar_month','horizon_used','horizon_basis']:
        x=pd.concat([x,pd.get_dummies(d[column],prefix=column,drop_first=True,dtype=float)],axis=1)
    x=sm.add_constant(x,has_constant='add');kept=[];rank=0
    for col in x:
        new=np.linalg.matrix_rank(x[kept+[col]].to_numpy(float))
        if new>rank:kept.append(col);rank=new
    return x[kept]

def estimate_cells(cells,span=5,wild=True):
    d=cells.replace([np.inf,-np.inf],np.nan).dropna(subset=['difference','weight','preelection']).copy()
    groups=(d.year.to_numpy()-1900)//span;g=len(np.unique(groups))
    if len(d)<60 or g<6 or d.preelection.nunique()<2:
        return dict(effect=np.nan,p_value=1.,n=len(d),n_blocks=g,status='insufficient_support'),None,d
    x=design(d)
    if len(d)<2*x.shape[1] or 'tested_predictor' not in x:
        return dict(effect=np.nan,p_value=1.,n=len(d),n_blocks=g,status='insufficient_rank_support'),None,d
    w=d.weight.to_numpy(float);w=w/w.mean();y=d.difference.to_numpy(float)
    fit=sm.WLS(y,x,weights=w).fit(cov_type='cluster',cov_kwds={'groups':groups,
        'use_correction':True,'df_correction':True},use_t=True)
    lo,hi=fit.conf_int().loc['tested_predictor']
    row=dict(effect=fit.params['tested_predictor'],se=fit.bse['tested_predictor'],low=lo,high=hi,
        p_value=fit.pvalues['tested_predictor'],p_cluster_t=fit.pvalues['tested_predictor'],
        n=len(d),n_blocks=g,status='estimated',n_election_cells=int(d.preelection.sum()),
        controls=';'.join(x.columns),first_month=d.month.min(),last_month=d.month.max())
    if wild:
        root=np.sqrt(w);info=restricted_wild(x.to_numpy(float)*root[:,None],y*root,groups,list(x).index('tested_predictor'))
        np.testing.assert_allclose(info['wild_se'],row['se'],rtol=1e-7,atol=1e-9)
        row.update(info);row['p_value']=max(row['p_cluster_t'],row['p_wild_conservative'])
    return row,fit,d

def validate_wls():
    rng=np.random.default_rng(SEED+666);groups=np.repeat(np.arange(6),[8,11,9,13,10,12]);n=len(groups)
    x=np.column_stack([np.ones(n),rng.normal(size=n),rng.normal(size=n)])
    y=.4*x[:,1]+.7*x[:,2]+rng.normal(size=6)[groups]+rng.normal(size=n);w=np.exp(rng.normal(size=n))
    kw=dict(cov_type='cluster',cov_kwds={'groups':groups,'use_correction':True,'df_correction':True},use_t=True)
    fit=sm.WLS(y,x,weights=w).fit(**kw);null=sm.WLS(y,x[:,[0,2]],weights=w).fit();extreme=0
    for mask in range(64):
        signs=np.array([1. if mask&(1<<j) else -1. for j in range(6)])
        star=null.fittedvalues+null.resid*signs[groups]
        f=sm.WLS(star,x,weights=w).fit(**kw)
        extreme+=int(abs(f.tvalues[1])>=abs(fit.tvalues[1])-1e-10)
    root=np.sqrt(w);check=restricted_wild(x*root[:,None],y*root,groups,1)
    np.testing.assert_allclose(check['wild_se'],fit.bse[1],rtol=1e-10)
    assert check['p_wild']==extreme/64
    save_json(OUT/'audits/election_wls_validation.json',dict(status='passed',
        check='Whitened restricted-wild WLS matches64 independent statsmodels WLS refits with unequal cluster sizes and weights.'))

def run():
    validate_wls();rows=[];sensitivity=[];samples=[]
    for source in ['verified','raw']:
        for metric in SPEC['metrics']:
            cells=metric_cells(source,metric)
            cells.to_csv(OUT/'cache'/f'election_cells_{source}_{metric}.csv.gz',index=False,
                compression={'method':'gzip','mtime':0})
            for topic in SPEC['topics']:
                d=cells[cells.topic.eq(topic)].copy();test=f'election_{topic}_{metric}'
                r,fit,used=estimate_cells(d)
                row=dict(test=test,batch='election_voice',topic=topic,metric=metric,block_years=5,**r)
                if source=='verified':rows.append(row);samples.append(used.assign(test=test))
                else:sensitivity.append(dict(variant='raw',**row))
                if source=='verified' and fit is not None:
                    for span in [2,10]:
                        rr,_,_=estimate_cells(d,span=span,wild=False)
                        sensitivity.append(dict(test=test,variant=f'blocks_{span}',**rr))
                    for label,mask in [('exclude_2007_2009',~d.year.between(2007,2009)),
                        ('exclude_1929_1939',~d.year.between(1929,1939)),
                        ('stated_horizons',d.horizon_basis.eq('stated'))]:
                        rr,_,_=estimate_cells(d[mask],wild=False)
                        sensitivity.append(dict(test=test,variant=label,**rr))
                    for low,high in [(4,10),(9,10)]:
                        sub=d.copy();sub['preelection']=((sub.year%4==0)&sub.calendar_month.between(low,high)).astype(float)
                        rr,_,_=estimate_cells(sub,wild=False)
                        sensitivity.append(dict(test=test,variant=f'campaign_months_{low}_{high}',**rr))
                print(source,test,r['effect'],r['p_value'],r['n'],flush=True)
                pd.DataFrame(rows).to_csv(OUT/'election_tests_partial.csv',index=False)
    result=adjust(pd.DataFrame(rows),109);assert len(result)==9
    result.to_csv(OUT/'election_tests.csv',index=False)
    pd.DataFrame(sensitivity).to_csv(OUT/'election_sensitivities.csv',index=False)
    pd.concat(samples,ignore_index=True).to_csv(OUT/'audits/election_analysis_rows.csv.gz',index=False,
        compression={'method':'gzip','mtime':0})
    save_json(OUT/'audits/election_manifest.json',dict(status='complete',n_tests=9,code_sha256=digest(__file__),
        source_count=check_sources(),interpretation='Calendar association among machine-attributed voices; no party affiliation, incumbent identity or causal political manipulation is established.'))
    journal('election_voice','Completed all9 election-calendar attribution questions')
    print(result.sort_values('p_value')[['test','effect','low','high','p_value','holm_p','n','n_blocks']].to_string(index=False))

if __name__=='__main__':run()
