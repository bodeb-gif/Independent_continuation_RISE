"""Illustrative fixed-design size calibration under overlapping monthly errors.

This checks assumptions, not the archive's semantic validity or causality.
No calibrated variant replaces the original primary test.
"""
import argparse
import time
from scipy.signal import lfilter
from associations import *
from collect_results import planned

def binomial_interval(k,n):
    return (float(st.beta.ppf(.025,k,n-k+1)) if k else 0.,
            float(st.beta.ppf(.975,k+1,n-k)) if k<n else 1.)

def run(draws):
    started=time.monotonic();folder=OUT/'null_calibration_precision';folder.mkdir(exist_ok=True)
    family=68+len(planned())
    spec=dict(created_utc=dt.datetime.now(dt.timezone.utc),draws_per_case=draws,
        innovation_autocorrelation=[0.,.5,.9,.98],moving_sum_months=6,burn_in=1000,
        true_tested_coefficient=0.,design='Fixed observed gap design and actual calendar support; nuisance mean is the fitted restricted null.',
        methods=['CR1 cluster-t','max(CR1 cluster-t, restricted calendar wild)','CV3 delete-calendar-block t'],
        levels=[.05,.05/family],family_size=family,
        role='Higher-precision follow-up after the original10000-per-case pilot was viewed; fixed1000000-per-case budget and independent seeds. Illustrative size sensitivity under specified stationary Gaussian DGPs. No empirical proof of valid errors, no new discovery hypothesis, and no replacement p-value.',
        code_sha256=digest(__file__))
    specfile=folder/'design.json'
    if specfile.exists():
        old=json.loads(specfile.read_text());spec['created_utc']=old['created_utc']
        if spec!=old:raise ValueError('Changed calibration design')
    else:save_json(specfile,spec)
    name='structure_employment_cross_topic_gap'
    d=pd.read_csv(OUT/'audits/structural_analysis_rows.csv.gz');d=d[d.test.eq(name)].copy()
    d.origin=pd.PeriodIndex(d.origin,freq='M')
    controls=['net_direction','net_squared','flat_share','log_articles','n_papers']
    design=select_design(d,controls);x=design.to_numpy(float);j=list(design).index('tested_predictor')
    y=d.employment_growth.to_numpy(float);groups=(d.year.to_numpy(int)-1900)//5
    codes=np.unique(groups);g=len(codes);n,k=x.shape;factor=g/(g-1)*(n-1)/(n-k)
    z=np.delete(x,j,axis=1);mu=z@np.linalg.lstsq(z,y,rcond=None)[0]
    bread=np.linalg.inv(x.T@x);a=bread@x.T
    parts=[np.flatnonzero(groups==code) for code in codes]
    delete=[]
    for code in codes:
        keep=groups!=code;v=np.zeros(n);v[keep]=np.linalg.pinv(x[keep])[j]
        delete.append(v)
    delete=np.array(delete)
    calendar=pd.period_range(d.origin.min(),d.origin.max(),freq='M')
    positions=calendar.get_indexer(d.origin)
    observed=y-x@(a@y);residual_series=pd.Series(observed,index=d.origin).reindex(calendar)
    diagnostics=[]
    for lag in [1,3,6,12,24,60]:
        diagnostics.append(dict(series='observed_regression_residual',lag=lag,
            correlation=residual_series.corr(residual_series.shift(lag)),
            paired_months=int(pd.concat([residual_series,residual_series.shift(lag)],axis=1).dropna().shape[0])))
    rows=[]
    for rho in spec['innovation_autocorrelation']:
        path=folder/f'case_{int(rho*100):02}.csv'
        if path.exists():
            case=pd.read_csv(path)
            if len(case)==draws:rows.extend(case.to_dict('records'));continue
        rng=np.random.default_rng(np.random.SeedSequence([SEED,405,int(rho*1000)]));case=[]
        for draw in range(draws):
            innovations=rng.normal(size=1000+len(calendar)+5)
            state=lfilter([np.sqrt(1-rho*rho)],[1.,-rho],innovations)[1000:]
            error=np.convolve(state,np.ones(6)/np.sqrt(6),mode='valid')
            if len(error)!=len(calendar):raise ValueError('Wrong simulated calendar')
            star=mu+error[positions];beta=a@star;u=star-x@beta
            scores=np.array([x[ix].T@u[ix] for ix in parts])@bread[j]
            se=np.sqrt(factor*np.square(scores).sum());t=beta[j]/se
            p=float(2*st.t.sf(abs(t),g-1))
            v=delete@star;se3=np.sqrt((g-1)/g*np.square(v-beta[j]).sum())
            p3=float(2*st.t.sf(abs(beta[j]/se3),g-1))
            # A maximum p cannot reject if its cluster-t component does not.
            # Skipping those wild computations preserves both rejection counts.
            pw=np.nan;primary=np.nan
            if p<=.05:
                info=restricted_wild(x,star,groups,j)
                np.testing.assert_allclose(info['wild_se'],se,rtol=1e-7,atol=1e-9)
                pw=info['p_wild_conservative'];primary=max(p,pw)
            row=dict(rho=rho,draw=draw,p_cluster_t=p,p_wild_if_needed=pw,p_primary_if_needed=primary,
                p_cv3=p3,coefficient=beta[j],se=se,se_cv3=se3)
            for label,threshold in [('nominal',.05),('family',.05/family)]:
                row['reject_cluster_'+label]=p<=threshold
                row['reject_primary_'+label]=bool(np.isfinite(primary) and primary<=threshold)
                row['reject_cv3_'+label]=p3<=threshold
            case.append(row)
            if draw%1000==999:
                pd.DataFrame(case).to_csv(folder/f'case_{int(rho*100):02}_partial.csv',index=False)
                save_json(folder/'status.json',dict(status='running',rho=rho,draw=draw,
                    elapsed_seconds=time.monotonic()-started,updated_utc=dt.datetime.now(dt.timezone.utc)))
                print('rho',rho,'draw',draw,'elapsed',round(time.monotonic()-started,1),flush=True)
        pd.DataFrame(case).to_csv(path,index=False);rows.extend(case)
        journal('null_calibration','Completed specified fixed-design Gaussian error case',rho=rho,draws=draws)
    f=pd.DataFrame(rows);summary=[]
    for rho,case in f.groupby('rho'):
        for method in ['cluster','primary','cv3']:
            for label,level in [('nominal',.05),('family',.05/family)]:
                count=int(case['reject_'+method+'_'+label].sum());low,high=binomial_interval(count,len(case))
                summary.append(dict(rho=rho,method=method,level=level,draws=len(case),rejections=count,
                    rejection_rate=count/len(case),monte_carlo_low=low,monte_carlo_high=high))
    pd.DataFrame(summary).to_csv(folder/'rejection_rates.csv',index=False)
    pd.DataFrame(diagnostics).to_csv(folder/'empirical_residual_dependence.csv',index=False)
    save_json(folder/'status.json',dict(status='complete',n_draws=len(f),draws_per_case=draws,
        elapsed_seconds=time.monotonic()-started,source_check=check_sources(),
        limitation='Monte Carlo intervals describe the simulation probability under the specified DGP, not confidence that the empirical design is valid. Long-memory or nonstationary errors can violate inter-block independence.'))
    print(pd.DataFrame(summary).to_string(index=False),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--draws',type=int,default=1000000);args=parser.parse_args();run(args.draws)
