"""Small unidirectional monthly GRU, with training-only preprocessing."""
import warnings
import torch
from torch import nn
from sklearn.preprocessing import StandardScaler
from model_data import *

torch.set_num_threads(1)
torch.set_num_interop_threads(1)
torch.use_deterministic_algorithms(True)

class MonthlyGRU(nn.Module):
    def __init__(self,n_features,hidden,dropout=.1):
        super().__init__()
        self.recurrent=nn.GRU(n_features,hidden,batch_first=True)
        self.output=nn.Sequential(nn.Dropout(dropout),nn.Linear(hidden,1))

    def forward(self,x):
        _,h=self.recurrent(x)
        return self.output(h[-1]).squeeze(1)

def sequences(frame,origins,features,lookback=12):
    end=frame.index.get_indexer(origins)
    if (end<lookback-1).any():raise ValueError('Incomplete sequence calendar')
    indices=end[:,None]-np.arange(lookback-1,-1,-1)[None,:]
    # Each origin's vector already contains only earlier print months and
    # previously released macro data; including that vector remains lawful.
    x=frame[features].to_numpy(float)[indices]
    latest=frame.index.to_numpy()[indices[:,-1]]
    if not np.array_equal(latest,np.asarray(origins)):raise ValueError('Sequence endpoint mismatch')
    return x

def prepare_sequences(train,test):
    shape=train.shape;flat=train.reshape(-1,shape[-1])
    with warnings.catch_warnings():
        warnings.simplefilter('ignore',RuntimeWarning)
        med=np.nanmedian(flat,axis=0)
    med=np.where(np.isfinite(med),med,0.)
    scaler=StandardScaler().fit(np.where(np.isnan(flat),med,flat))
    def apply(values):
        flat=values.reshape(-1,shape[-1])
        scaled=scaler.transform(np.where(np.isnan(flat),med,flat)).reshape(values.shape)
        return np.concatenate([scaled,np.isnan(values).astype(float)],axis=-1).astype('float32')
    return apply(train),apply(test),dict(median=med,scaler=scaler,lookback=shape[1])

def fit_recurrent(task,config,frame,train,y,test,features,seed=113,return_model=False):
    a=sequences(frame,train,features);b=sequences(frame,test,features)
    a,b,preprocessing=prepare_sequences(a,b)
    torch.manual_seed(seed);rng=np.random.default_rng(seed)
    model=MonthlyGRU(a.shape[-1],config['hidden'])
    optimizer=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.01)
    binary=task.endswith('downturn')
    center=0. if binary else float(y.mean());scale=1. if binary else max(float(y.std()),1e-6)
    target=(y-center)/scale
    with torch.no_grad():
        if binary:
            prior=(y.sum()+1)/(len(y)+2)
            model.output[-1].bias.fill_(float(np.log(prior/(1-prior))))
        else:model.output[-1].bias.zero_()
    x=torch.from_numpy(a);z=torch.from_numpy(b);labels=torch.from_numpy(target.astype('float32'))
    loss_function=nn.BCEWithLogitsLoss() if binary else nn.MSELoss()
    history=[]
    for epoch in range(config['epochs']):
        model.train();order=rng.permutation(len(train));total=0.
        for start in range(0,len(order),64):
            ix=order[start:start+64]
            optimizer.zero_grad(set_to_none=True)
            loss=loss_function(model(x[ix]),labels[ix])
            if not torch.isfinite(loss):raise ValueError('Nonfinite recurrent loss')
            loss.backward();nn.utils.clip_grad_norm_(model.parameters(),1.)
            optimizer.step();total+=float(loss.detach())*len(ix)
        if return_model:history.append(dict(epoch=epoch+1,train_loss=total/len(train)))
    model.eval()
    with torch.no_grad():
        values=model(z)
        p=values.sigmoid().numpy() if binary else values.numpy()*scale+center
    bundle=None
    if return_model:
        bundle=dict(state_dict={k:v.detach().cpu().numpy() for k,v in model.state_dict().items()},
            n_features=a.shape[-1],configuration=config,preprocessing=preprocessing,
            target_center=center,target_scale=scale,binary=binary,features=features,
            seed=seed,history=history,torch_version=torch.__version__)
    return p,bundle

def reload_predict(bundle,frame,test):
    model=MonthlyGRU(bundle['n_features'],bundle['configuration']['hidden'])
    model.load_state_dict({k:torch.from_numpy(v) for k,v in bundle['state_dict'].items()})
    x=sequences(frame,test,bundle['features']);shape=x.shape
    flat=x.reshape(-1,shape[-1]);params=bundle['preprocessing'];med=params['median']
    scaled=params['scaler'].transform(np.where(np.isnan(flat),med,flat)).reshape(shape)
    x=np.concatenate([scaled,np.isnan(x).astype(float)],axis=-1).astype('float32')
    model.eval()
    with torch.no_grad():
        v=model(torch.from_numpy(x))
        return v.sigmoid().numpy() if bundle['binary'] else v.numpy()*bundle['target_scale']+bundle['target_center']
