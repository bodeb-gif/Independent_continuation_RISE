"""Describe all three declared GRU seeds without selecting a favorable seed.

The discovery family stays closed. This repeats the saved configurations and
checks the exact squared-loss ensemble identity; it introduces no new p-value.
"""
import time
from refit_multiplier_corrected import *
from recurrent_ml import fit_recurrent


def run():
    start = time.monotonic()
    folder = OUT/'gru_seed_diagnostics'; folder.mkdir(exist_ok=True)
    model_folder = OUT/'models_boundary_corrected/gru'
    seeds = GRID['gru']['seeds']
    save_json(folder/'design.json', dict(created_utc=dt.datetime.now(dt.timezone.utc),
        seeds=seeds, selection='Keep every previously declared seed; reuse saved annual settings.',
        role='Descriptive initialization sensitivity and ensemble-loss accounting. No new test, p-value, model selection or discovery.',
        code_sha256=digest(__file__), canonical_predictions_sha256=digest(model_folder/'predictions_without_truth.csv')))
    frame, valid = feature_frame(); targets = HistoricalTargets()
    records = []
    for task in TASKS:
        for year in range(1977, 2011):
            cutoff = pd.Period(f'{year}-01', 'M'); test = valid[valid.year == year]
            for arm in ARMS:
                saved = json.loads((model_folder/'annual'/f'{task}_{arm}_{year}.json').read_text())
                config = saved['configuration']
                train, y, _ = eligible(frame, valid, targets, cutoff, task, config['window'])
                for seed in seeds:
                    prediction, _ = fit_recurrent(task, config, frame, train, y, test, ARMS[arm], seed+year)
                    records.extend(dict(task=task, year=year, arm=arm, origin=str(origin),
                        declared_seed=seed, fitted_seed=seed+year, prediction=float(value))
                        for origin, value in zip(test, prediction))
            save_json(folder/'status.json', dict(status='running', task=task, year=year,
                prediction_rows=len(records), elapsed_seconds=time.monotonic()-start,
                updated_utc=dt.datetime.now(dt.timezone.utc)))
        print('Completed all seeds:', task, round(time.monotonic()-start, 1), 'seconds', flush=True)
    bare = pd.DataFrame(records)
    assert len(bare) == 4*3*3*408
    assert not bare.duplicated(['task', 'arm', 'origin', 'declared_seed']).any()
    bare.to_csv(folder/'predictions_without_truth.csv', index=False)
    average = bare.groupby(['task', 'arm', 'origin']).prediction.mean()
    original = pd.read_csv(model_folder/'predictions_without_truth.csv').set_index(['task', 'arm', 'origin']).prediction
    error = float((average-original).abs().max())
    np.testing.assert_allclose(average.sort_index(), original.sort_index(), rtol=2e-5, atol=2e-5)
    # Evaluation outcomes are attached only after all forecasts are saved.
    truth_rows = []
    origins = pd.period_range('1977-01', '2010-12', freq='M')
    for task in TASKS:
        truth_rows.extend(dict(task=task, origin=str(o), truth=float(v))
            for o, v in zip(origins, evaluation_truth(origins, task)))
    scored = bare.merge(pd.DataFrame(truth_rows), on=['task', 'origin'], validate='many_to_one')
    scored['loss'] = (scored.prediction-scored.truth)**2
    scored.to_csv(folder/'predictions.csv', index=False)
    metrics = scored.groupby(['task', 'arm', 'declared_seed']).loss.mean().rename('squared_loss').reset_index()
    metrics.to_csv(folder/'seed_metrics.csv', index=False)
    gains = []
    accounting = []
    for task in TASKS:
        for seed in seeds:
            m = metrics[metrics.task.eq(task) & metrics.declared_seed.eq(seed)].set_index('arm').squared_loss
            for newer, older, label in [('macro_coverage_net', 'macro_coverage', 'net_minus_macro_coverage'),
                ('macro_coverage_net_structure', 'macro_coverage_net', 'structure_minus_net')]:
                gains.append(dict(task=task, declared_seed=seed, comparison=label, gain=float(m[older]-m[newer])))
        for arm in ARMS:
            d = scored[scored.task.eq(task) & scored.arm.eq(arm)]
            means = d.groupby('origin').agg(prediction=('prediction', 'mean'), truth=('truth', 'first'))
            ensemble_loss = float(((means.prediction-means.truth)**2).mean())
            mean_individual_loss = float(d.loss.mean())
            dispersion = float(d.groupby('origin').prediction.var(ddof=0).mean())
            identity_error = abs(mean_individual_loss-ensemble_loss-dispersion)
            assert identity_error < 1e-10
            accounting.append(dict(task=task, arm=arm, ensemble_loss=ensemble_loss,
                mean_individual_seed_loss=mean_individual_loss,
                mean_within_origin_prediction_variance=dispersion, identity_error=identity_error))
    pd.DataFrame(gains).to_csv(folder/'seed_gains.csv', index=False)
    pd.DataFrame(accounting).to_csv(folder/'ensemble_accounting.csv', index=False)
    result = dict(status='complete', updated_utc=dt.datetime.now(dt.timezone.utc),
        elapsed_seconds=time.monotonic()-start, seeds=seeds, rows=len(bare),
        canonical_average_max_absolute_error=error,
        maximum_accounting_identity_error=max(r['identity_error'] for r in accounting),
        interpretation='All three originally declared seeds are retained. Seed dispersion is descriptive, not an economic-cycle confidence interval. No new significance test or seed choice.',
        code_sha256=digest(__file__), source_check=check_sources())
    save_json(folder/'status.json', result)
    journal('gru_seed_diagnostics', 'Reconstructed all declared seed predictions and squared-loss ensemble identity',
        canonical_average_max_absolute_error=error, rows=len(bare))
    print(json.dumps(result, indent=2, default=json_default))


if __name__ == '__main__':
    with threadpool_limits(limits=1):
        run()
