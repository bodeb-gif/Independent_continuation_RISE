"""Keep natural effect units distinct from simultaneous reference precision."""
from session_utils import *
from collect_results import planned

def run():
    family=68+len(planned());economic=json.loads((OUT/'audits/economic_scale.json').read_text())
    primary=pd.read_csv(OUT/'structural_tests.csv').set_index('test').loc['structure_employment_cross_topic_gap']
    # A gap increase is an other-topic decrease conditional on own outlook.
    multiplier=-economic['effect_per_one_other_sd']/primary.effect
    rows=[]
    estimates=[('primary_cluster_t',primary.effect,primary.se,int(primary.n_blocks))]
    stress=pd.read_csv(OUT/'inference_stress.csv')
    for row in stress[stress.test.eq('structure_employment_cross_topic_gap')].itertuples(index=False):
        estimates.append((row.method,row.effect,row.se,int(row.n_blocks)))
    for method,beta,se,blocks in estimates:
        effect=-beta*multiplier;natural_se=se*multiplier
        for kind,alpha in [('pointwise_95',.05),('bonferroni_cluster_t_reference',.05/family)]:
            q=st.t.ppf(1-alpha/2,blocks-1)
            rows.append(dict(method=method,interval=kind,effect_per_other_index_sd=effect,
                se_per_other_index_sd=natural_se,low=effect-q*natural_se,high=effect+q*natural_se,
                family_size=family,n_blocks=blocks,reference_df=blocks-1,
                caveat='t-reference interval; not an inversion of the restricted-wild test; temporal and semantic assumptions remain.'))
    pd.DataFrame(rows).to_csv(OUT/'economic_precision.csv',index=False)
    save_json(OUT/'audits/economic_precision.json',dict(status='complete',family=family,
        interpretation='The point effect is economically noticeable. Simultaneous reference precision is much wider than the pointwise95percent interval and supports no tightly known minimum economic magnitude.',
        code_sha256=digest(__file__),source_check=check_sources()))
    print(pd.DataFrame(rows).to_string(index=False))

if __name__=='__main__':run()
