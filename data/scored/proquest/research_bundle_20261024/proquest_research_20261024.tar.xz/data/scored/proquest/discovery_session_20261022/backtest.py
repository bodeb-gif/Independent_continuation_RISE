"""Fixed annual forward tests with vintage training labels and macro inputs."""
from common import *
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from proquest_vintages import VintageSeries, CORE_FEATURES

MODELS={
    'macro':list(CORE_FEATURES),
    'macro_jobs':list(CORE_FEATURES)+['jobs_net'],
    'macro_business':list(CORE_FEATURES)+['business_net'],
    'macro_both':list(CORE_FEATURES)+['jobs_net','business_net'],
    'jobs_only':['jobs_net','jobs_log_articles','jobs_papers'],
}
PAIRS=[('macro_jobs','macro'),('macro_business','macro'),('macro_both','macro'),
       ('jobs_only','recent_mean'),('macro_both','recent_mean')]


def archives():
    result={}
    for name in ['RUC','IPT']:
        path=BASE/'macro_information'/f'{name}_vintages_through_2010.csv.gz'
        frame=pd.read_csv(path,index_col=0)
        frame.index=pd.PeriodIndex(frame.index,freq='M')
        result[name]=VintageSeries(name,frame)
    return result


def frame_for_fitting():
    d=pd.read_csv(BASE/'macro_information/macro_feature_audit.csv')
    d['origin']=pd.PeriodIndex(d.origin,freq='M')
    d=d[d.origin>=pd.Period('1965-12','M')].copy()
    s=pd.read_csv(OUT/'lagged_topic_signals.csv');s['origin']=pd.PeriodIndex(s.origin,freq='M')
    for topic,prefix in [('employment','jobs'),('general_business','business')]:
        g=s[s.topic.eq(topic)][['origin','net_direction','articles','papers','latest_print_month']].copy()
        g=g.rename(columns={'net_direction':prefix+'_net','articles':prefix+'_articles','papers':prefix+'_papers','latest_print_month':prefix+'_latest_print'})
        d=d.merge(g,on='origin',validate='one_to_one')
        assert (pd.PeriodIndex(d[prefix+'_latest_print'],freq='M')<pd.PeriodIndex(d.origin,freq='M')).all()
        d[prefix+'_log_articles']=np.log1p(d[prefix+'_articles'])
    for series in ['IPT','RUC']:
        ok=d[series+'_available_by'].notna()
        assert (pd.to_datetime(d.loc[ok,series+'_available_by'])<d.loc[ok,'origin'].dt.to_timestamp()).all()
    d=d[np.isfinite(d[list(CORE_FEATURES)]).all(axis=1)].copy()
    return d


def labels_for_refit(frame,refit,archive,task):
    vintage,snapshot=archive.snapshot(refit)
    if vintage is None:raise ValueError('Missing vintage')
    rows=[]
    for origin in frame.loc[frame.origin<refit,'origin']:
        start,end=origin-1,origin+5
        first,last=snapshot.get(start,np.nan),snapshot.get(end,np.nan)
        mature=end+3<refit
        good=np.isfinite(first)&np.isfinite(last)&(first>0)
        target=(-(last-first) if task=='unemployment' else 100*np.log(last/first)) if mature and good else np.nan
        rows.append(dict(origin=origin,training_target=target,refit_year=refit.year,
                         label_vintage=vintage,label_available_by=archive.dates[vintage],
                         target_start=start,target_end=end,mature=mature,endpoints_available=bool(good)))
    return pd.DataFrame(rows)


def ridge_predict(train,test,features,alpha):
    x=train[features].astype(float);z=test[features].astype(float)
    med=x.median().fillna(0)
    scaler=StandardScaler().fit(x.fillna(med))
    # Missing indicators are also scaled using training data, not evaluation.
    a=np.column_stack([scaler.transform(x.fillna(med)),x.isna().to_numpy(float)])
    b=np.column_stack([scaler.transform(z.fillna(med)),z.isna().to_numpy(float)])
    fit=Ridge(alpha=alpha).fit(a,train.training_target)
    params=pd.DataFrame(dict(feature=features,median=med.to_numpy(),mean=scaler.mean_,scale=scaler.scale_,coefficient=fit.coef_[:len(features)],missing_coefficient=fit.coef_[len(features):]))
    params['intercept']=fit.intercept_
    return fit.predict(b),params


def run(alpha=10.):
    frame=frame_for_fitting();archive=archives();predictions=[];audits=[];label_audits=[];parameters=[]
    # Final evaluation truth is deliberately not loaded until after every fit.
    assert not any(c.endswith('_growth') for c in frame)
    for task,series in [('unemployment','RUC'),('production','IPT')]:
        for year in range(1977,2011):
            refit=pd.Period(f'{year}-01','M')
            labels=labels_for_refit(frame,refit,archive[series],task)
            label_audits.append(labels.assign(task=task))
            train=frame.merge(labels[['origin','training_target']],on='origin',validate='one_to_one').dropna(subset=['training_target']).sort_values('origin')
            test=frame[frame.origin.dt.year.eq(year)].copy()
            if len(train)<120:raise ValueError((task,year,len(train)))
            assert (train.origin+8<refit).all()
            test['recent_mean']=train.training_target.tail(120).mean()
            test['zero_change']=0.
            for model,features in MODELS.items():
                test[model],params=ridge_predict(train,test,features,alpha)
                parameters.append(params.assign(task=task,model=model,refit_year=year,alpha=alpha))
            test['task']=task;test['alpha']=alpha
            predictions.append(test[['origin','task','alpha','recent_mean','zero_change']+list(MODELS)])
            audits.append(dict(task=task,refit_year=year,n_training=len(train),n_evaluation=len(test),
                               last_training_origin=train.origin.max(),label_vintage=labels.label_vintage.iloc[0],
                               label_available_by=labels.label_available_by.iloc[0],missing_jobs_training=train.jobs_net.isna().sum(),missing_jobs_test=test.jobs_net.isna().sum()))
    predicted=pd.concat(predictions,ignore_index=True)
    truth=pd.read_csv(OUT/'continuous_targets.csv');truth['origin']=pd.PeriodIndex(truth.origin,freq='M')
    for task,col in [('unemployment','employment_growth'),('production','general_business_growth')]:
        mapping=truth.set_index('origin')[col]
        mask=predicted.task.eq(task);predicted.loc[mask,'truth']=predicted.loc[mask,'origin'].map(mapping)
    assert predicted.truth.notna().all()
    suffix=f'alpha{alpha:g}'
    predicted.to_csv(OUT/f'backtest_predictions_{suffix}.csv',index=False)
    pd.DataFrame(audits).to_csv(OUT/f'backtest_refits_{suffix}.csv',index=False)
    pd.concat(label_audits).to_csv(OUT/f'backtest_training_labels_{suffix}.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    pd.concat(parameters).to_csv(OUT/f'backtest_parameters_{suffix}.csv',index=False)
    metrics=[];tests=[];blocks=[];sensitivity=[]
    for task,g in predicted.groupby('task'):
        year=g.origin.dt.year
        for model in ['recent_mean','zero_change']+list(MODELS):
            residual=g[model]-g.truth
            metrics.append(dict(task=task,alpha=alpha,model=model,n=len(g),mse=np.square(residual).mean(),rmse=np.sqrt(np.square(residual).mean()),mae=abs(residual).mean(),sign_accuracy=(np.sign(g[model])==np.sign(g.truth)).mean()))
        for model,baseline in PAIRS:
            gain=(g[baseline]-g.truth)**2-(g[model]-g.truth)**2
            for span in [2,5,10]:
                r=clustered_mean(gain,np.ones(len(g)),year,span,anchor=1977)
                row=dict(task=task,model=model,baseline=baseline,alpha=alpha,block_years=span,**r)
                sensitivity.append(row)
                if span==5:tests.append(row)
            for block,b in g.groupby((year-1977)//5):
                blocks.append(dict(task=task,model=model,baseline=baseline,block=int(block),first=b.origin.min(),last=b.origin.max(),n=len(b),gain=((b[baseline]-b.truth)**2-(b[model]-b.truth)**2).mean()))
            variants=[('exclude_2007_2009',~year.between(2007,2009)),('1977_1994',year<1995),('1995_2010',year>=1995)]
            variants += [(f'omit_block_{block}',(year-1977)//5!=block) for block in sorted(((year-1977)//5).unique())]
            for name,mask in variants:
                r=clustered_mean(gain[mask],np.ones(mask.sum()),year[mask],5,anchor=1977)
                sensitivity.append(dict(task=task,model=model,baseline=baseline,alpha=alpha,variant=name,**r))
    tests=adjust(pd.DataFrame(tests),10)
    tests.to_csv(OUT/f'backtest_tests_{suffix}.csv',index=False)
    pd.DataFrame(metrics).to_csv(OUT/f'backtest_metrics_{suffix}.csv',index=False)
    pd.DataFrame(sensitivity).to_csv(OUT/f'backtest_sensitivities_{suffix}.csv',index=False)
    pd.DataFrame(blocks).to_csv(OUT/f'backtest_blocks_{suffix}.csv',index=False)
    print(pd.DataFrame(metrics).to_string(index=False),flush=True)
    print(tests[['task','model','baseline','effect','low','high','p_value','holm_p','signflip_p']].to_string(index=False),flush=True)


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--alpha',type=float,default=10.)
    run(parser.parse_args().alpha)
