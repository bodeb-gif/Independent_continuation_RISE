"""Exploratory economic-association audit; see the adjacent fixed specification."""
from pathlib import Path
import hashlib
import json
import itertools
import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
BASE = ROOT / 'data/scored/proquest'
INPUTS = [BASE/'descriptive/scored_claims.csv.gz', BASE/'polarization/features.csv',
          BASE/'followups/warning_event_phases.csv', OUT/'specification.json']

def main():
    f = pd.read_csv(INPUTS[0], low_memory=False)
    f = f[f.hit.notna() & f.year.between(1919, 2010) & f.basis.ne('NBER proxy')].copy()
    assert f.scope.eq('national').all()
    f['origin'] = pd.to_datetime(f.date).dt.to_period('M').astype(str)
    f['gap'] = f.hit - f.fixed_baseline_hit
    f['default_share'] = f.horizon_basis.eq('default').astype(float)
    topics = pd.get_dummies(f.topic, prefix='topic', dtype=float)
    papers = pd.get_dummies(f.paper, prefix='paper', dtype=float)
    controls = list(topics.columns[1:])+list(papers.columns[1:])+['horizon_used','default_share']
    f = pd.concat([f, topics, papers], axis=1)
    cols = ['hit','fixed_baseline_hit','gap'] + controls
    article = f.groupby(['origin','page_id'], observed=True)[cols].mean()
    monthly = article.groupby('origin').mean()
    monthly['n_articles'] = article.groupby('origin').size()
    monthly['n_papers'] = f.groupby('origin').paper.nunique()
    monthly = monthly[(monthly.n_articles >= 5) & (monthly.n_papers >= 2)].reset_index()
    pol = pd.read_csv(INPUTS[1])
    frame = monthly.merge(pol, on='origin', validate='one_to_one').dropna(subset=['political_polarization','forecast_polarization']).copy()
    assert (pd.to_datetime(frame.political_latest_vote) < pd.to_datetime(frame.origin)).all()
    assert (pd.to_datetime(frame.forecast_latest_print_month) < pd.to_datetime(frame.origin)).all()
    assert np.allclose(frame.gap, frame.hit-frame.fixed_baseline_hit)
    frame['year'] = pd.to_datetime(frame.origin).dt.year
    zcols = []
    scales = {}
    for field in ['political_polarization','forecast_polarization']:
        scales[field] = float(frame[field].std())
        frame[field+'_z'] = (frame[field]-frame[field].mean())/scales[field]
        zcols.append(field+'_z')
    decade = pd.get_dummies((frame.year//10)*10, prefix='decade', drop_first=True, dtype=float)
    X = sm.add_constant(pd.concat([frame[zcols+controls],decade],axis=1)).astype(float)
    assert np.linalg.matrix_rank(X.to_numpy()) == len(X.columns)
    rows = []
    for years in [2,5,10]:
        clusters = (frame.year-1900)//years
        for outcome in ['hit','gap']:
            fit = sm.OLS(frame[outcome],X).fit(cov_type='cluster',cov_kwds={'groups':clusters,'use_correction':True,'df_correction':True},use_t=True)
            for field in zcols:
                lo,hi=fit.conf_int().loc[field]
                rows.append(dict(outcome=outcome,predictor=field,block_years=years,n_months=len(frame),n_blocks=clusters.nunique(),effect_pp=100*fit.params[field],low_pp=100*lo,high_pp=100*hi,p_value=fit.pvalues[field]))
    events=pd.read_csv(INPUTS[2]);phases=['7–12 months before','1–6 months before','0–5 months after']
    rates=events.pivot(index='onset',columns='phase',values='warning_share')
    counts=events.pivot(index='onset',columns='phase',values='n_claims')
    valid=counts[phases].ge(30).all(axis=1)
    rates=rates.loc[valid,phases];assert len(rates)==16
    delta=(rates[phases[1]]-rates[phases[0]]).rename('difference')
    block=(pd.to_datetime(delta.index).year-1900)//5
    blocks=pd.DataFrame({'delta':delta.to_numpy(),'block':block}).groupby('block').delta.agg(['sum','count'])
    null=np.asarray(list(itertools.product([-1,1],repeat=len(blocks))))@blocks['sum'].to_numpy()/blocks['count'].sum()
    point=delta.mean();p=float(np.mean(np.abs(null)>=abs(point)-1e-12))
    rng=np.random.default_rng(20261022);draw=rng.integers(0,len(blocks),size=(10000,len(blocks)))
    boot=blocks['sum'].to_numpy()[draw].sum(axis=1)/blocks['count'].to_numpy()[draw].sum(axis=1)
    lo,hi=np.quantile(boot,[.025,.975])
    warning=dict(n_events=16,n_blocks=len(blocks),far_warning_share=float(rates[phases[0]].mean()),near_warning_share=float(rates[phases[1]].mean()),effect_pp=100*point,low_pp=100*lo,high_pp=100*hi,p_value=p)
    results=pd.DataFrame(rows)
    for years in [2,5,10]:
        mask=results.block_years.eq(years)
        adj=multipletests(list(results.loc[mask,'p_value'])+[p],method='holm')[1]
        results.loc[mask,'holm_p']=adj[:-1]
        if years==5:warning['holm_p']=float(adj[-1])
    results.to_csv(OUT/'polarization_associations.csv',index=False)
    frame.to_csv(OUT/'monthly_analysis_data.csv',index=False)
    rates.assign(difference=delta).to_csv(OUT/'matched_recession_events.csv')
    summary={'status':'exploratory, fixed machine labels; not causal or confirmatory',
             'monthly_support':{'n_months':len(frame),'first':frame.origin.min(),'last':frame.origin.max(),'n_articles':int(frame.n_articles.sum()),'control_columns':list(X.columns),'predictor_sd':scales},
             'polarization_primary':results[results.block_years.eq(5)].to_dict('records'),'warning_timing':warning,
             'source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in INPUTS+[Path(__file__)]}}
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(results.to_string(index=False));print('Warning timing:',warning)

if __name__=='__main__':main()
