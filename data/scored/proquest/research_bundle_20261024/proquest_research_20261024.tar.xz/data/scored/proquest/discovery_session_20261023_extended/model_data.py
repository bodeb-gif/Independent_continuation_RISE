"""Immutable print-time model inputs and historical-vintage target availability."""
from zipfile import ZipFile
import io
from session_utils import *
from design import STRUCTURES
from proquest_vintages import CORE_FEATURES, VintageSeries

MACRO=list(CORE_FEATURES)
COVERAGE=[f'{t}__{c}' for t in TOPICS for c in ['log_articles','n_papers','observed_months']]
NET=[f'{t}__net_direction' for t in TOPICS]
STRUCTURE=[f'{t}__{c}' for t in TOPICS for c in STRUCTURES]
ARMS={'macro_coverage':MACRO+COVERAGE,
      'macro_coverage_net':MACRO+COVERAGE+NET,
      'macro_coverage_net_structure':MACRO+COVERAGE+NET+STRUCTURE}
TASKS=['production_continuous','unemployment_continuous','production_downturn','unemployment_downturn']

def feature_frame(variant='verified'):
    frame=pd.read_csv(OUT/'cache'/f'features_{variant}.csv.gz')
    frame['origin']=pd.PeriodIndex(frame.origin,freq='M')
    keep=['origin','topic']+['net_direction']+STRUCTURES+['log_articles','n_papers','observed_months']
    # A whitelist prevents accidental reuse of outcome/audit columns.
    frame=frame[keep]
    wide=frame.pivot(index='origin',columns='topic')
    wide.columns=[f'{t}__{c}' for c,t in wide.columns]
    old=pd.read_csv(PRIOR/'phase2/fresh_core_forecast_features.csv')
    old['origin']=pd.PeriodIndex(old.origin,freq='M')
    wide=wide.join(old.set_index('origin')[MACRO],how='left').sort_index()
    # The main common sample is determined entirely by published macro inputs.
    support=wide[MACRO].notna().all(axis=1)
    valid=wide.index[support & (wide.index>=pd.Period('1965-12','M'))]
    if list(valid)!=list(pd.period_range('1965-12','2010-12',freq='M')):
        raise ValueError('Unexpected common macro availability')
    banned=['hit','realized','truth','scorable','recession','window','verify','current_state']
    if any(any(word in col.lower() for word in banned) for col in wide):
        raise ValueError('Forbidden model feature name')
    if len(wide)!=1332 or not wide.index.is_unique: raise ValueError('Calendar mismatch')
    return wide,valid

class HistoricalTargets:
    def __init__(self):
        path=BASE/'macro_information/IPT_vintages_through_2010.csv.gz'
        ip=pd.read_csv(path,index_col=0);ip.index=pd.PeriodIndex(ip.index,freq='M')
        self.ip=VintageSeries('IPT',ip)
        path2=PRIOR/'reference/alfred_UNRATE_month_end_1960_2010.zip'
        receipt=json.loads(path2.with_suffix('.manifest.json').read_text())
        if digest(path2)!=receipt['sha256']: raise ValueError('Changed ALFRED archive')
        with ZipFile(path2) as z:
            members=[p for p in z.namelist() if p.endswith('.csv')]
            self.u=pd.concat([pd.read_csv(io.BytesIO(z.read(p)),index_col=0) for p in members],axis=1)
        self.u.index=pd.PeriodIndex(self.u.index,freq='M')
        if not self.u.index.is_unique or not self.u.columns.is_unique: raise ValueError('Duplicate vintage entries')
        self.cache={}
        self.input_hashes={str(p.relative_to(ROOT)):digest(p) for p in [path,path2]}

    def snapshot(self,refit,task):
        refit=pd.Period(refit,freq='M')
        if task.startswith('production'):
            name,s=self.ip.snapshot(refit)
            day=self.ip.dates[name] if name else None
        else:
            day=(refit-1).end_time.normalize()
            name='UNRATE_'+str(day.date()).replace('-','')
            if name not in self.u: raise ValueError('Missing exact target vintage '+name)
            s=pd.to_numeric(self.u[name],errors='coerce').dropna()
        if day is None or day>=refit.start_time or s.index.max()>=refit:
            raise ValueError('Invalid target vintage chronology')
        return name,day,s

    def labels(self,origins,refit,task):
        refit=pd.Period(refit,freq='M');key=(str(refit),task)
        if key not in self.cache:
            name,day,s=self.snapshot(refit,task)
            all_origins=pd.period_range('1965-12','2010-12',freq='M')
            start=pd.PeriodIndex(all_origins-1);end=pd.PeriodIndex(all_origins+5)
            a=s.reindex(start).to_numpy(float);b=s.reindex(end).to_numpy(float)
            mature=end+3<refit
            good=np.isfinite(a)&np.isfinite(b)&mature&(a>0)
            values=np.full(len(all_origins),np.nan)
            if task.startswith('production'): values[good]=100*np.log(b[good]/a[good])
            else: values[good]=-(b[good]-a[good])
            if task.endswith('downturn'):
                threshold=-2. if task.startswith('production') else -.5
                values[good]=(values[good]<threshold).astype(float)
            self.cache[key]=pd.DataFrame(dict(origin=all_origins,training_target=values,
                target_start=start,target_end=end,mature=mature,label_vintage=name,label_available_by=day))
        data=self.cache[key].set_index('origin').reindex(origins)
        data.index.name='origin'
        return data.reset_index()

def eligible(frame,valid,targets,refit,task,window=None):
    refit=pd.Period(refit,freq='M')
    labels=targets.labels(valid,refit,task).set_index('origin')
    keep=labels.training_target.notna() & (labels.index<refit)
    if window: keep &= labels.index>=refit-12*window
    train=labels.index[keep]
    if len(train) and not ((train+8)<refit).all(): raise ValueError('Unmatured target')
    return train,labels.loc[train,'training_target'].to_numpy(float),labels.loc[train]

def inner_folds(frame,valid,targets,outer,task):
    outer=pd.Period(outer,freq='M');known=targets.labels(valid,outer,task).set_index('origin')
    folds=[]
    for lag in [6,4,2]:
        inner=outer-lag*12
        train,_,_=eligible(frame,valid,targets,inner,task)
        val=valid[(valid>=inner)&(valid<=inner+23)&(valid<outer)]
        val=val[known.reindex(val).training_target.notna()]
        if len(train)>=120 and len(val):
            folds.append(dict(origin=inner,validation=val,
                y_validation=known.loc[val,'training_target'].to_numpy(float),
                validation_vintage=str(known.loc[val,'label_vintage'].iloc[0])))
    return folds if len(folds)>=2 and sum(len(f['validation']) for f in folds)>=24 else []

def evaluation_truth(origins,task):
    """Called after predictions are saved; never used by a fitting function."""
    truth=pd.read_csv(PRIOR/'continuous_targets.csv');truth['origin']=pd.PeriodIndex(truth.origin,freq='M')
    col='general_business_growth' if task.startswith('production') else 'employment_growth'
    values=truth.set_index('origin').reindex(origins)[col].to_numpy(float)
    if task.endswith('downturn'):
        values=(values<(-2. if task.startswith('production') else -.5)).astype(float)
    if not np.isfinite(values).all(): raise ValueError('Missing assessment truth')
    return values

def save_model_input_audit():
    frame,valid=feature_frame()
    frame.to_csv(OUT/'cache/model_features.csv.gz',compression={'method':'gzip','mtime':0})
    targets=HistoricalTargets();rows=[]
    for task in TASKS:
        for year in range(1977,2011):
            refit=pd.Period(f'{year}-01','M')
            origins,y,labels=eligible(frame,valid,targets,refit,task)
            rows.append(dict(task=task,refit=str(refit),n_training=len(origins),
                first_training=str(origins.min()),last_training=str(origins.max()),
                last_endpoint=str(labels.target_end.max()),
                vintage=labels.label_vintage.iloc[0],available_by=labels.label_available_by.iloc[0],
                mean_training_target=y.mean(),n_positive=int((y>0).sum())))
    pd.DataFrame(rows).to_csv(OUT/'audits/model_label_availability.csv',index=False)
    save_json(OUT/'audits/model_input_manifest.json',dict(n_months=len(frame),n_common_inputs=len(valid),
        evaluation_months=408,features=ARMS,code_sha256=digest(__file__),
        target_archive_hashes=targets.input_hashes,source_check=check_sources()))
    journal('model_inputs','Saved common model features and vintage-label timing audit')

if __name__=='__main__':save_model_input_audit()
