"""Independent GRU multiplier shards with the canonical three-seed estimator.

Separate folders avoid races with the original sampler. No original sampler,
model, target, preprocessing, source or selected setting is modified.
"""
import argparse
import time
from refit_multiplier_corrected import *

def run(shard,draws):
    started=time.monotonic();frame,valid=feature_frame();targets=HistoricalTargets()
    folder=OUT/'models_boundary_corrected/gru';out=folder/'refit_multiplier_shards'/f'shard_{shard}'
    out.mkdir(parents=True,exist_ok=True)
    implementation=dict(code_sha256=digest(__file__),canonical_sampler_sha256=digest(OUT/'refit_multiplier_corrected.py'),
        session_utils_sha256=digest(OUT/'session_utils.py'),boundary_rules_sha256=digest(OUT/'boundary_rules.py'),
        recurrent_sha256=digest(OUT/'recurrent_ml.py'),predictions_sha256=digest(folder/'predictions_without_truth.csv'),
        random_seed_sequence=[SEED,821,shard],maximum_draws=draws,
        stop_new_draws_utc='2026-10-24T12:20:00+00:00',role='Same positive-calendar-block multiplier diagnostic; original selected settings held fixed; all three neural seeds averaged.')
    receipt=out/'implementation.json'
    if receipt.exists() and json.loads(receipt.read_text())!=implementation:raise ValueError('Changed shard implementation')
    save_json(receipt,implementation)
    original=pd.read_csv(folder/'predictions_without_truth.csv');original.origin=pd.PeriodIndex(original.origin,freq='M')
    originals={(t,a):g.set_index('origin').prediction for (t,a),g in original.groupby(['task','arm'])}
    audits={}
    for p in (folder/'annual').glob('*.json'):
        d=json.loads(p.read_text());audits[(d['task'],d['arm'],d['refit_year'])]=d
    groups=(valid.year-1977)//5;codes=np.unique(groups)
    rng=np.random.default_rng(np.random.SeedSequence([SEED,821,shard]));all_rows=[]
    stop=dt.datetime.fromisoformat(implementation['stop_new_draws_utc'])
    for draw in range(-1,draws):
        if draw>=0 and dt.datetime.now(dt.timezone.utc)>=stop:break
        exp=np.ones(len(codes)) if draw==-1 else rng.exponential(1.,len(codes))
        weights=pd.Series(exp[np.searchsorted(codes,groups)],index=valid)
        path=out/f'draw_{draw:04}.json'
        if path.exists():
            if draw>=0:all_rows+=json.loads(path.read_text())['results']
            continue
        rows=[];errors=[]
        for task in TASKS:
            predictions={a:[] for a in ARMS}
            for year in range(1977,2011):
                outer=pd.Period(f'{year}-01','M');test=valid[valid.year==year]
                for arm in ARMS:
                    config=audits[(task,arm,year)]['configuration']
                    train,y,_=eligible(frame,valid,targets,outer,task,config['window'])
                    p=np.mean([predict_weighted('gru',task,config,frame,train,y,test,ARMS[arm],weights,seed+year)
                        for seed in GRID['gru']['seeds']],axis=0)
                    predictions[arm].append(pd.Series(p,index=test))
            truth=evaluation_truth(pd.period_range('1977-01','2010-12',freq='M'),task)
            losses={}
            for arm,parts in predictions.items():
                values=pd.concat(parts).sort_index();w=weights.reindex(values.index).to_numpy(float)
                if not np.isfinite(values).all():raise ValueError('Nonfinite prediction')
                losses[arm]=(values.to_numpy()-truth)**2
                if draw==-1:
                    error=float(abs(values-originals[(task,arm)]).max())
                    errors.append(dict(task=task,arm=arm,max_error=error))
                    if error>2e-5:raise ValueError('Uniform reproduction failed')
            for newer,older,label in [('macro_coverage_net','macro_coverage','net_minus_macro_coverage'),
                ('macro_coverage_net_structure','macro_coverage_net','structure_minus_net')]:
                rows.append(dict(draw=draw,shard=shard,algorithm='gru',task=task,comparison=label,
                    gain=float(np.average(losses[older]-losses[newer],weights=w))))
        save_json(path,dict(draw=draw,shard=shard,block_codes=codes,block_weights=exp,results=rows,
            elapsed_seconds=time.monotonic()-started))
        if draw==-1:
            save_json(out/'uniform_reproduction.json',dict(status='passed',errors=errors))
            journal('gru_refit_shard','All uniform forecasts reproduce canonical estimator',shard=shard)
        else:all_rows+=rows
        save_json(out/'status.json',dict(status='running',shard=shard,last_completed_draw=draw,
            completed_draws=len(all_rows)//8,maximum_draws=draws,elapsed_seconds=time.monotonic()-started,
            updated_utc=dt.datetime.now(dt.timezone.utc)))
        print('GRU shard',shard,'draw',draw,'complete',round(time.monotonic()-started,1),'seconds',flush=True)
        journal('gru_refit_shard','Completed independent three-seed model reweighting',shard=shard,draw=draw)
    pd.DataFrame(all_rows).to_csv(out/'draws.csv',index=False)
    save_json(out/'status.json',dict(status='complete' if len(all_rows)//8==draws else 'time_limited',
        shard=shard,completed_draws=len(all_rows)//8,maximum_draws=draws,
        elapsed_seconds=time.monotonic()-started,updated_utc=dt.datetime.now(dt.timezone.utc),source_count=check_sources()))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--shard',type=int,required=True);parser.add_argument('--draws',type=int,default=100)
    args=parser.parse_args()
    if args.shard not in [1,2]:raise ValueError('Undeclared shard')
    with threadpool_limits(limits=1):run(args.shard,args.draws)
