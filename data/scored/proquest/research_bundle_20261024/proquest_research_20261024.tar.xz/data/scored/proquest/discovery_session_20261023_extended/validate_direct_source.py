"""Independent dict-based reconstruction of selected topic-direction features."""
from collections import defaultdict
from session_utils import *

def direct_sign(row):
    topic=row.get('topic')
    if topic=='prices':return {'up':1.,'down':-1.,'stable':0.}.get(str(row.get('price_direction','')).lower())
    if topic=='employment':
        value={'up':-1.,'down':1.,'stable':0.}.get(str(row.get('unemployment_direction','')).lower())
        if value is not None:return value
    return {'improve':1.,'worsen':-1.,'no_change':0.}.get(str(row.get('direction','')).lower())

def direct_paper(row):
    value=str(row.get('publisher') or row.get('newspaper_title'))
    for needle,name in [('wall street journal','Wall Street Journal'),('new york times','New York Times'),
        ('los angeles times','Los Angeles Times'),('chicago','Chicago Tribune'),('washington post','Washington Post'),
        ('boston','Boston Globe'),('barron',"Barron's"),('christian science monitor','Christian Science Monitor'),('usa today','USA Today')]:
        if needle in value.lower():return name
    return value

def run():
    f=pd.read_csv(OUT/'cache/features_verified.csv.gz');f.origin=pd.PeriodIndex(f.origin,freq='M')
    calendar=pd.period_range('1900-04','2010-12',freq='M');rng=np.random.default_rng(20261024+402)
    origins=set(rng.choice(calendar,20,replace=False))
    origins.update(pd.Period(o,'M') for o in ['1900-04','1919-02','1948-02','1965-12','1977-01','1985-01','2008-10','2010-12'])
    origins=sorted(origins);months=set(m for o in origins for m in pd.period_range(o-3,o-1,freq='M'))
    article=defaultdict(list);source_rows=0;files=[]
    for year in sorted(set(m.year for m in months)):
        path=ROOT/f'data/proquest/verified/pred_proquest_economy_{year}.export.jsonl';files.append(path)
        for line in path.read_text().splitlines():
            if not line.strip():continue
            row=json.loads(line)
            if row.get('no_predictions') or row.get('scope')!='national' or row.get('topic') not in TOPICS:continue
            month=pd.Period(str(row['date'])[:7],freq='M')
            if month not in months:continue
            value=direct_sign(row)
            if value is None:continue
            article[(month,direct_paper(row),row['topic'],str(row['page_id']))].append(value);source_rows+=1
    papers=defaultdict(list)
    for (month,paper,topic,page),values in article.items():
        papers[(month,paper,topic)].append((sum(values)/len(values),sum(v==0 for v in values)/len(values)))
    monthly=defaultdict(list)
    for (month,paper,topic),values in papers.items():
        monthly[(month,topic)].append((np.mean([v[0] for v in values]),np.mean([v[1] for v in values]),len(values)))
    comparisons=[];maximum=0.
    for origin in origins:
        expected={}
        for topic in TOPICS:
            observed=[];counts=[];paper_counts=[]
            for month in pd.period_range(origin-3,origin-1,freq='M'):
                values=monthly.get((month,topic),[])
                paper_counts.append(len(values));counts.append(sum(v[2] for v in values))
                if values:observed.append((np.mean([v[0] for v in values]),np.mean([v[1] for v in values])))
            adequate=len(observed)>=2 and max(paper_counts)>=2 and sum(counts)>=5
            net=float(np.mean([v[0] for v in observed])) if adequate else np.nan
            flat=float(np.mean([v[1] for v in observed])) if adequate else np.nan
            expected[topic]=dict(net_direction=net,flat_share=flat,n_articles=sum(counts),
                n_papers=np.mean(paper_counts),log_articles=np.log1p(sum(counts)),net_squared=net*net)
        for topic in TOPICS:
            others=[v['net_direction'] for key,v in expected.items() if key!=topic and np.isfinite(v['net_direction'])]
            expected[topic]['cross_topic_gap']=expected[topic]['net_direction']-np.mean(others) if len(others)>=2 else np.nan
            saved=f[f.origin.eq(origin)&f.topic.eq(topic)].iloc[0]
            for field,value in expected[topic].items():
                np.testing.assert_allclose(value,saved[field],rtol=1e-12,atol=1e-12,equal_nan=True)
                error=abs(value-saved[field]) if np.isfinite(value) else 0.
                maximum=max(maximum,error)
                comparisons.append(dict(origin=origin,topic=topic,field=field,direct_value=value,saved_value=saved[field],absolute_error=error))
    pd.DataFrame(comparisons).to_csv(OUT/'audits/direct_source_feature_checks.csv',index=False)
    save_json(OUT/'audits/direct_source_validation.json',dict(status='passed',n_origins=len(origins),
        n_comparisons=len(comparisons),n_directly_read_claim_rows=source_rows,n_article_topic_cells=len(article),
        n_unique_articles=len(set(key[3] for key in article)),
        maximum_absolute_error=maximum,source_files={str(p.relative_to(ROOT)):digest(p) for p in files},
        independent_steps='Raw annualJSONL; explicit local direction and publisher mappings; built-in dictionary claim/article/paper averages; exact earlier3month windows. No panel-builder or feature-builder function is imported.',
        code_sha256=digest(__file__),source_check=check_sources()))
    journal('validation','Independent direct-source topic/window reconstruction passed',origins=len(origins),comparisons=len(comparisons))
    print('PASS',len(origins),'origins',len(comparisons),'field comparisons, max error',maximum)

if __name__=='__main__':run()
