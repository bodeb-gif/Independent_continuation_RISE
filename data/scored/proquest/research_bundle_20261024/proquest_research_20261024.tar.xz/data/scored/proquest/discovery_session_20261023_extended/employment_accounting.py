"""Descriptive employment-versus-labor-force accounting for the existing lead."""
import io
import subprocess
import urllib.parse
from associations import *

def fetch():
    folder=OUT/'reference/employment_accounting';folder.mkdir(exist_ok=True);series={};receipts=[]
    for sid in ['PAYEMS','CE16OV','CLF16OV']:
        path=folder/(sid+'.csv')
        url='https://fred.stlouisfed.org/graph/fredgraph.csv?'+urllib.parse.urlencode(
            dict(id=sid,cosd='1939-01-01',coed='2011-12-31'))
        if not path.exists():
            result=subprocess.run(['curl','--fail','--silent','--show-error','--location','--max-time','20',url],capture_output=True,timeout=25)
            if result.returncode:raise ValueError(result.stderr.decode(errors='replace')[:200])
            content=result.stdout
        else:content=path.read_bytes()
        f=pd.read_csv(io.BytesIO(content))
        if list(f)!=['observation_date',sid]:raise ValueError('Wrong source columns')
        v=pd.to_numeric(f[sid],errors='coerce');dates=pd.PeriodIndex(f.observation_date,freq='M')
        s=pd.Series(v.to_numpy(float),index=dates).dropna()
        if not s.index.is_unique or (s<=0).any():raise ValueError('Invalid labor levels')
        if not path.exists():path.write_bytes(content)
        series[sid]=s
        receipts.append(dict(series=sid,file=path,sha256=digest(path),download_url=url,
            source_page='https://fred.stlouisfed.org/series/'+sid,units='Thousands of persons; seasonally adjusted',
            role='Current revised outcome interpretation only, never a historical model input.'))
    save_json(folder/'manifest.json',dict(retrieved_utc=dt.datetime.now(dt.timezone.utc),receipts=receipts))
    return series

def run():
    check_sources();s=fetch();folder=OUT/'employment_accounting';folder.mkdir(exist_ok=True)
    d=pd.read_csv(OUT/'audits/structural_analysis_rows.csv.gz')
    d=d[d.test.eq('structure_employment_cross_topic_gap')].copy();d.origin=pd.PeriodIndex(d.origin,freq='M')
    x=select_design(d,['net_direction','net_squared','flat_share','log_articles','n_papers'])
    j=list(x).index('tested_predictor');matrix=x.to_numpy(float);y=d.employment_growth.to_numpy(float)
    primary=pd.read_csv(OUT/'structural_tests.csv').set_index('test').loc['structure_employment_cross_topic_gap']
    np.testing.assert_allclose(np.linalg.lstsq(matrix,y,rcond=None)[0][j],primary.effect,rtol=1e-10)
    start=pd.PeriodIndex(d.origin-1);end=pd.PeriodIndex(d.origin+5)
    endpoints={sid:(v.reindex(start).to_numpy(float),v.reindex(end).to_numpy(float)) for sid,v in s.items()}
    if not all(np.isfinite(a).all() and np.isfinite(b).all() for a,b in endpoints.values()):
        raise ValueError('Incomplete benchmark on fixed original694 origins; refuse outcome-specific sample selection')
    e0,e1=endpoints['CE16OV'];l0,l1=endpoints['CLF16OV']
    outcomes={'original_unemployment_improvement_pp':y,
        'implied_unemployment_improvement_pp':100*(e1/l1-e0/l0),
        'employment_accounting_component_pp':50*(e1-e0)*(1/l0+1/l1),
        'labor_force_accounting_component_pp':50*(e0+e1)*(1/l1-1/l0)}
    for sid,(a,b) in endpoints.items():outcomes[sid+'_growth_log_percent']=100*np.log(b/a)
    np.testing.assert_allclose(outcomes['employment_accounting_component_pp']+outcomes['labor_force_accounting_component_pp'],
        outcomes['implied_unemployment_improvement_pp'],rtol=1e-10,atol=1e-10)
    multiplier=-json.loads((OUT/'audits/economic_scale.json').read_text())['effect_per_one_other_sd']/primary.effect
    groups=(d.year.to_numpy(int)-1900)//5;rows=[];deleted=[]
    for name,values in outcomes.items():
        coefficient=np.linalg.lstsq(matrix,values,rcond=None)[0][j]
        effects=[]
        for block in np.unique(groups):
            keep=groups!=block
            effect=-np.linalg.lstsq(matrix[keep],values[keep],rcond=None)[0][j]*multiplier
            effects.append(effect);deleted.append(dict(outcome=name,deleted_block=int(block),effect_per_other_sd=effect))
        rows.append(dict(outcome=name,n=len(values),effect_per_other_sd=-coefficient*multiplier,
            minimum_leaveblock_effect=min(effects),maximum_leaveblock_effect=max(effects),
            role='Descriptive benchmark/accounting challenge; no p-value or new discovery claim.'))
    table=pd.DataFrame(rows);table.to_csv(folder/'coefficients.csv',index=False)
    pd.DataFrame(deleted).to_csv(folder/'deleted_blocks.csv',index=False)
    panel=pd.DataFrame(dict(origin=d.origin,**outcomes));panel.to_csv(folder/'outcomes.csv',index=False)
    indexed=table.set_index('outcome').effect_per_other_sd
    np.testing.assert_allclose(indexed['employment_accounting_component_pp']+indexed['labor_force_accounting_component_pp'],
        indexed['implied_unemployment_improvement_pp'],rtol=1e-9,atol=1e-10)
    deviation=outcomes['implied_unemployment_improvement_pp']-y
    save_json(folder/'completion.json',dict(status='complete',n_fixed_origins=len(d),
        mean_absolute_identity_minus_published_unemployment=np.mean(abs(deviation)),
        max_absolute_identity_minus_published_unemployment=max(abs(deviation)),
        correlation_implied_and_original=float(np.corrcoef(outcomes['implied_unemployment_improvement_pp'],y)[0,1]),
        interpretation='The symmetric decomposition allocates the ratio change to employment and labor-force level changes. It is an exact accounting identity within the downloaded level series, not an identification of causal channels. PAYEMS counts establishment jobs and CE16OV counts household employment; they are distinct concepts.',
        role='Descriptive source/benchmark interpretation only; no new significance test or replacement outcome.',
        code_sha256=digest(__file__),source_check=check_sources()))
    journal('employment_accounting','Completed fixed-sample payroll/household/labor-force benchmark accounting',origins=len(d))
    print(table.to_string(index=False))

if __name__=='__main__':run()
