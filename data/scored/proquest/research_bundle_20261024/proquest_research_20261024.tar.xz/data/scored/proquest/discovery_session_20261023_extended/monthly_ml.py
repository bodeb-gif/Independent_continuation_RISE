"""Nested forward-time ML with historical-vintage fit and selection labels."""
import argparse
import itertools
import time
import warnings
import joblib
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.ensemble import HistGradientBoostingRegressor, HistGradientBoostingClassifier
from sklearn.ensemble import ExtraTreesRegressor, ExtraTreesClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.exceptions import ConvergenceWarning
from threadpoolctl import threadpool_limits
from model_data import *

GRID=json.loads((OUT/'specs/ml_grid.json').read_text())['algorithms']

def configurations(algorithm,task):
    g=GRID[algorithm];binary=task.endswith('downturn')
    if algorithm=='linear':
        return [dict(value=v,window=w) for v,w in itertools.product(g['binary_C' if binary else 'regression_alpha'],g['window_years'])]
    if algorithm=='hist_gradient_boosting':
        return [dict(iterations=i,leaves=l,window=w) for i,l,w in itertools.product(g['max_iter'],g['max_leaf_nodes'],g['window_years'])]
    if algorithm=='extra_trees':
        return [dict(depth=d,leaf=l,window=w) for d,l,w in itertools.product(g['max_depth'],g['min_samples_leaf'],g['window_years'])]
    if algorithm=='gru':
        return [dict(hidden=h,epochs=e,window=w) for h,e,w in itertools.product(g['hidden'],g['epochs'],g['window_years'])]
    raise ValueError(algorithm)

def fallback(algorithm):
    return {'linear':dict(value=.1,window=None),
            'hist_gradient_boosting':dict(iterations=50,leaves=3,window=None),
            'extra_trees':dict(depth=2,leaf=30,window=None),
            'gru':dict(hidden=8,epochs=30,window=None)}[algorithm]

def preprocess(a,b):
    med=np.nanmedian(a,axis=0);med=np.where(np.isfinite(med),med,0.)
    scaler=StandardScaler().fit(np.where(np.isnan(a),med,a))
    def apply(v):
        return np.column_stack([scaler.transform(np.where(np.isnan(v),med,v)),np.isnan(v).astype(float)])
    return apply(a),apply(b),dict(median=med,scaler=scaler)

def fit_predict(algorithm,task,config,frame,train,y,test,features,seed=113,return_model=False):
    if algorithm=='gru':
        from recurrent_ml import fit_recurrent
        return fit_recurrent(task,config,frame,train,y,test,features,seed,return_model)
    a=frame.loc[train,features].to_numpy(float);b=frame.loc[test,features].to_numpy(float)
    with warnings.catch_warnings():
        warnings.simplefilter('ignore',RuntimeWarning)
        a,b,params=preprocess(a,b)
    binary=task.endswith('downturn')
    if binary and len(np.unique(y))<2:
        p=np.full(len(test),(y.sum()+1)/(len(y)+2))
        return p,dict(model=None,preprocessing=params,constant=p[0]) if return_model else None
    if algorithm=='linear':
        model=LogisticRegression(C=config['value'],max_iter=3000,solver='lbfgs',random_state=seed) if binary else Ridge(alpha=config['value'])
    elif algorithm=='hist_gradient_boosting':
        cls=HistGradientBoostingClassifier if binary else HistGradientBoostingRegressor
        model=cls(max_iter=config['iterations'],max_leaf_nodes=config['leaves'],
            learning_rate=.05,l2_regularization=10,min_samples_leaf=30,
            early_stopping=False,random_state=seed)
    elif algorithm=='extra_trees':
        cls=ExtraTreesClassifier if binary else ExtraTreesRegressor
        model=cls(n_estimators=300,max_depth=config['depth'],min_samples_leaf=config['leaf'],
            max_features=.8,bootstrap=False,n_jobs=1,random_state=seed)
    else: raise ValueError(algorithm)
    with warnings.catch_warnings():
        warnings.simplefilter('error',ConvergenceWarning)
        model.fit(a,y)
    p=model.predict_proba(b)[:,list(model.classes_).index(1)] if binary else model.predict(b)
    return p,dict(model=model,preprocessing=params,features=features) if return_model else None

def select(algorithm,task,arm,frame,valid,targets,outer,log):
    folds=inner_folds(frame,valid,targets,outer,task)
    if not folds:
        default=fallback(algorithm)
        if algorithm=='linear' and not task.endswith('downturn'):default=dict(value=10.,window=None)
        return default,True,0
    candidates=configurations(algorithm,task);scores=[]
    for ci,config in enumerate(candidates):
        losses=[];failure=None
        for fold in folds:
            train,y,labels=eligible(frame,valid,targets,fold['origin'],task,config['window'])
            if len(train)<120: failure='insufficient_training';break
            if not (fold['validation']+8<outer).all(): raise ValueError('Selection label not mature')
            p,_=fit_predict(algorithm,task,config,frame,train,y,fold['validation'],ARMS[arm],
                seed=113+fold['origin'].year)
            loss=(p-fold['y_validation'])**2
            if not np.isfinite(loss).all(): raise ValueError('Invalid inner predictions')
            losses.extend(loss)
            log.append(dict(algorithm=algorithm,task=task,arm=arm,outer=str(outer),candidate=ci,
                configuration=json.dumps(config,sort_keys=True),inner=str(fold['origin']),
                n_training=len(train),last_training=str(train.max()),
                label_available_by=labels.label_available_by.iloc[0],
                validation_first=str(fold['validation'].min()),validation_last=str(fold['validation'].max()),
                validation_vintage=fold['validation_vintage'],n_validation=len(loss),loss=float(loss.mean())))
        score=np.inf if failure else float(np.mean(losses))
        scores.append(score)
    winner=int(np.argmin(scores))
    if not np.isfinite(scores[winner]):raise ValueError('Every candidate failed')
    return candidates[winner],False,len(folds)

def run(algorithm,tasks=None):
    check_sources();start=time.monotonic();frame,valid=feature_frame();targets=HistoricalTargets()
    tasks=tasks or TASKS;folder=OUT/'models'/algorithm;folder.mkdir(exist_ok=True)
    checkpoint=folder/'annual';checkpoint.mkdir(exist_ok=True)
    inputs={str(p.relative_to(ROOT)):digest(p) for p in [OUT/'cache/features_verified.csv.gz',
        OUT/'specs/ml_grid.json',OUT/'specs/initial_design.json',Path(__file__),OUT/'model_data.py']}
    if algorithm=='gru':inputs[str((OUT/'recurrent_ml.py').relative_to(ROOT))]=digest(OUT/'recurrent_ml.py')
    specfile=folder/'run_inputs.json'
    if specfile.exists() and json.loads(specfile.read_text())!=inputs:
        raise ValueError('Refuse to resume with changed code or inputs')
    save_json(specfile,inputs)
    all_predictions=[];audits=[];selection=[]
    for task in tasks:
        for year in range(1977,2011):
            outer=pd.Period(f'{year}-01','M');test=valid[valid.year==year]
            if len(test)!=12:raise ValueError('Unequal evaluation support')
            for arm in ARMS:
                stem=f'{task}_{arm}_{year}'
                predpath=checkpoint/(stem+'.csv');auditpath=checkpoint/(stem+'.json')
                if predpath.exists() and auditpath.exists():
                    pred=pd.read_csv(predpath);pred['origin']=pd.PeriodIndex(pred.origin,freq='M')
                    all_predictions.append(pred);audits.append(json.loads(auditpath.read_text()));continue
                began=time.monotonic();local_log=[]
                config,is_default,nfold=select(algorithm,task,arm,frame,valid,targets,outer,local_log)
                train,y,labels=eligible(frame,valid,targets,outer,task,config['window'])
                seed_predictions=[];bundles=[]
                seeds=GRID['gru']['seeds'] if algorithm=='gru' else [113]
                for seed in seeds:
                    p,bundle=fit_predict(algorithm,task,config,frame,train,y,test,ARMS[arm],
                        seed=seed+year,return_model=(year==2010))
                    seed_predictions.append(p)
                    if bundle is not None:bundles.append(bundle)
                p=np.mean(seed_predictions,axis=0)
                if not np.isfinite(p).all():raise ValueError('Nonfinite forecast')
                if task.endswith('downturn') and not ((p>=0)&(p<=1)).all():raise ValueError('Invalid probability')
                pred=pd.DataFrame(dict(origin=test,task=task,algorithm=algorithm,arm=arm,prediction=p))
                for seed,values in zip(seeds,seed_predictions):pred[f'seed_{seed}']=values
                pred.to_csv(predpath,index=False)
                audit=dict(task=task,algorithm=algorithm,arm=arm,refit_year=year,
                    configuration=config,fallback=is_default,inner_folds=nfold,n_training=len(train),
                    first_training=str(train.min()),last_training=str(train.max()),
                    latest_label_endpoint=str(labels.target_end.max()),
                    label_vintage=str(labels.label_vintage.iloc[0]),label_available_by=str(labels.label_available_by.iloc[0]),
                    n_evaluation=len(test),elapsed_seconds=time.monotonic()-began,
                    features=ARMS[arm],seed_ensemble=seeds)
                save_json(auditpath,audit)
                if bundles:
                    joblib.dump(dict(audit=audit,bundles=bundles),folder/f'{task}_{arm}_2010.joblib')
                if local_log:
                    pd.DataFrame(local_log).to_csv(checkpoint/(stem+'_inner.csv'),index=False)
                all_predictions.append(pred);audits.append(audit)
            journal('monthly_ml','Completed annual forecasts',algorithm=algorithm,task=task,year=year,
                elapsed_seconds=time.monotonic()-start)
            print(algorithm,task,year,'complete',round(time.monotonic()-start,1),'seconds',flush=True)
    predicted=pd.concat(all_predictions,ignore_index=True)
    if len(predicted)!=len(tasks)*408*3:raise ValueError('Missing predictions')
    predicted.to_csv(folder/'predictions_without_truth.csv',index=False)
    # No revised outcome is loaded before every declared fit has finished.
    for task in tasks:
        mask=predicted.task.eq(task)
        predicted.loc[mask,'truth']=evaluation_truth(pd.PeriodIndex(predicted.loc[mask,'origin'],freq='M'),task)
    predicted['loss']=(predicted.prediction-predicted.truth)**2
    predicted.to_csv(folder/'predictions.csv',index=False)
    pd.DataFrame(audits).to_csv(folder/'refits.csv',index=False)
    tests=[];metrics=[];sensitivities=[];block_rows=[]
    for task,g in predicted.groupby('task'):
        loss=g.pivot(index='origin',columns='arm',values='loss').sort_index()
        for arm,sub in g.groupby('arm'):
            metrics.append(dict(task=task,algorithm=algorithm,arm=arm,n=len(sub),
                primary_loss=sub.loss.mean(),rmse=np.sqrt(sub.loss.mean()),
                mae=abs(sub.prediction-sub.truth).mean()))
        for newer,older,label in [('macro_coverage_net','macro_coverage','net_minus_macro_coverage'),
                ('macro_coverage_net_structure','macro_coverage_net','structure_minus_net')]:
            gain=loss[older]-loss[newer];name=f'ml_{algorithm}_{task}_{label}'
            result=mean_inference(gain,loss.index.year)
            tests.append(dict(test=name,batch='monthly_ml',algorithm=algorithm,task=task,
                comparison=label,model=newer,baseline=older,**result))
            for span in [2,10]:
                r=mean_inference(gain,loss.index.year,span=span)
                sensitivities.append(dict(test=name,variant=f'blocks_{span}',**r))
            for variant,mask in [('exclude_2007_2009',~loss.index.year.isin([2007,2008,2009])),
                                 ('1977_1994',loss.index.year<1995),('1995_2010',loss.index.year>=1995)]:
                r=mean_inference(gain[mask],loss.index.year[mask])
                sensitivities.append(dict(test=name,variant=variant,**r))
            for block in np.unique((loss.index.year-1977)//5):
                mask=(loss.index.year-1977)//5==block
                block_rows.append(dict(test=name,block=int(block),n=int(mask.sum()),gain=gain[mask].mean()))
    tests=adjust(pd.DataFrame(tests),64);tests.to_csv(folder/'tests.csv',index=False)
    pd.DataFrame(metrics).to_csv(folder/'metrics.csv',index=False)
    pd.DataFrame(sensitivities).to_csv(folder/'sensitivities.csv',index=False)
    pd.DataFrame(block_rows).to_csv(folder/'blocks.csv',index=False)
    save_json(folder/'completion.json',dict(status='complete',algorithm=algorithm,tasks=tasks,
        n_tests=len(tests),n_predictions=len(predicted),elapsed_seconds=time.monotonic()-start,
        input_hashes=inputs,library_versions={n:__import__(n).__version__ for n in ['numpy','pandas','scipy','sklearn']},
        source_check=check_sources()))
    print(pd.DataFrame(metrics).to_string(index=False),flush=True)
    print(tests[['test','effect','low','high','p_value','holm_p']].to_string(index=False),flush=True)
    journal('monthly_ml','Completed algorithm',algorithm=algorithm,n_tests=len(tests),elapsed_seconds=time.monotonic()-start)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--algorithm',required=True,choices=['linear','hist_gradient_boosting','extra_trees','gru'])
    parser.add_argument('--task',choices=TASKS);args=parser.parse_args()
    with threadpool_limits(limits=1):run(args.algorithm,[args.task] if args.task else None)
