"""Design-based annotation uncertainty for a fixed machine-matched contrast."""
from common import *
from run_primary import matched_cells

N=175843
N_REVIEW=250


def contrast(totals):
    yl,gl,yr,gr=np.asarray(totals)
    return yl/gl-yr/gr


def summary(totals,covariance):
    yl,gl,yr,gr=totals
    if gl<=0 or gr<=0:
        return dict(effect=np.nan,status='invalid eligibility denominator',totals=totals.tolist())
    gradient=np.array([1/gl,-yl/gl**2,-1/gr,yr/gr**2])
    se=np.sqrt(gradient@covariance@gradient)
    effect=contrast(totals)
    return dict(effect=effect,se=se,low=effect-1.96*se,high=effect+1.96*se,
                assertive_accuracy=yl/gl,hedged_accuracy=yr/gr,
                assertive_eligible_weight=gl,hedged_eligible_weight=gr,
                status='estimated; annotation-sampling uncertainty only')


def main():
    f=pd.read_csv(BASE/'descriptive/scored_claims.csv.gz',dtype={'page_id':str})
    f=f[f.hit.notna()].copy()
    pilot=json.loads((BASE/'source_review_pilot_v1/pack.json').read_text())['records']
    excluded={':'.join(r['audit_id'].split(':')[1:]) for r in pilot}
    assert len(excluded)==12
    f=f[~f.record_id.isin(excluded)].copy()
    assert len(f)==N
    f['month']=pd.PeriodIndex(pd.to_datetime(f.date),freq='M')
    cells=matched_cells(f,'confidence','assertive','hedged','general_business',2)
    keys=['paper','month','topic','basis','horizon_basis','horizon_used','voice']
    selected=f.merge(cells[keys+['weight','articles_left','articles_right']],on=keys,validate='many_to_one')
    selected=selected[selected.confidence.isin(['assertive','hedged'])].copy()
    counts=selected.groupby(keys+['confidence','page_id']).record_id.transform('size')
    articles=np.where(selected.confidence.eq('assertive'),selected.articles_left,selected.articles_right)
    selected['weight_claim']=selected.weight/(articles*counts*cells.weight.sum())
    assert np.allclose(selected.groupby('confidence').weight_claim.sum().to_numpy(),[1.,1.])
    machine=selected.groupby('confidence').apply(lambda g:np.sum(g.weight_claim*g.hit),include_groups=False)
    machine_totals=np.array([machine['assertive'],1.,machine['hedged'],1.])
    assert np.isclose(contrast(machine_totals),np.average(cells.difference,weights=cells.weight))
    selected[['record_id','confidence','weight_claim','hit']].to_csv(OUT/'measurement_fixed_support_weights.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    review=pd.read_csv(OUT/'historical_human_measurement.csv')
    summaries=[];bootstrap_rows=[]
    for reviewer,sample in review.groupby('reviewer'):
        assert len(sample)==N_REVIEW and sample.record_id.is_unique
        d=sample.merge(selected[['record_id','confidence','weight_claim','hit']],on='record_id',how='left',validate='one_to_one')
        d['weight_claim']=d.weight_claim.fillna(0)
        left=d.confidence.eq('assertive').astype(float)*d.weight_claim
        right=d.confidence.eq('hedged').astype(float)*d.weight_claim
        genuine=d.human_scorable.eq(1)&d.human_topic.eq('general_business')&d.human_basis.eq('INDPRO')
        hit=d.human_hit.fillna(0)*genuine
        human=np.column_stack([left*hit,left*genuine,right*hit,right*genuine])
        observed=np.column_stack([left*d.hit.fillna(0),left,right*d.hit.fillna(0),right])
        for estimator,values,offset in [('human_sample_only',human,np.zeros(4)),('design_based_correction',human-observed,machine_totals)]:
            totals=offset+N*values.mean(axis=0)
            covariance=N*N/N_REVIEW*(1-N_REVIEW/N)*np.cov(values,rowvar=False,ddof=1)
            result=summary(totals,covariance)
            result.update(reviewer=reviewer,estimator=estimator,
                          sampled_original_assertive=int((left>0).sum()),sampled_original_hedged=int((right>0).sum()),
                          sampled_human_eligible_assertive=int(((left>0)&genuine).sum()),sampled_human_eligible_hedged=int(((right>0)&genuine).sum()),
                          machine_contrast=contrast(machine_totals))
            rng=np.random.default_rng(SEED)
            boot=[];invalid=0
            for _ in range(20):
                draws=rng.integers(0,N_REVIEW,(1000,N_REVIEW))
                bt=offset+N*values[draws].mean(axis=1)
                good=(bt[:,1]>0)&(bt[:,3]>0)
                invalid+=(~good).sum()
                delta=bt[good,0]/bt[good,1]-bt[good,2]/bt[good,3]
                boot.extend(delta.tolist())
            result['bootstrap_low'],result['bootstrap_high']=np.quantile(boot,[.025,.975])
            result['invalid_bootstrap_denominator_share']=invalid/20000
            result['bootstrap_outside_minus1_plus1_share']=np.mean(np.abs(boot)>1)
            summaries.append(result)
            bootstrap_rows.extend([dict(reviewer=reviewer,estimator=estimator,draw=i,effect=x) for i,x in enumerate(boot)])
    pd.DataFrame(summaries).to_csv(OUT/'measurement_corrected_confidence.csv',index=False)
    pd.DataFrame(bootstrap_rows).to_csv(OUT/'measurement_bootstrap.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    write_json('measurement_manifest.json',dict(N=N,n_review=N_REVIEW,n_pilot_excluded=12,n_fixed_cells=len(cells),
               machine_contrast=contrast(machine_totals),estimand='human-corrected accuracy among fixed original machine groups/support, not true-confidence groups',
               uncertainty='Annotation-sample variation only; does not combine temporal and reviewer uncertainty.',
               code_sha256=digest(Path(__file__))))
    print(pd.DataFrame(summaries).to_string(index=False),flush=True)


if __name__=='__main__':main()
