"""Fetch nine public as-of unemployment snapshots, with bounded requests."""
import io
import subprocess
import time
import urllib.parse
from session_utils import *

def run():
    out=OUT/'reference/early_truth';out.mkdir(exist_ok=True);records=[];failures=0
    for cutoff in pd.period_range('2011-01','2011-09',freq='M'):
        day=str((cutoff-1).end_time.date());name='UNRATE_'+day.replace('-','')
        path=out/(name+'.csv')
        url='https://alfred.stlouisfed.org/graph/alfredgraph.csv?'+urllib.parse.urlencode(
            dict(id='UNRATE',vintage_date=day,cosd='1948-01-01',coed=day))
        try:
            if path.exists():content=path.read_bytes();cached=True
            else:
                result=subprocess.run(['curl','--fail','--silent','--show-error','--location','--max-time','20',url],capture_output=True,timeout=25)
                if result.returncode:raise ValueError(result.stderr.decode(errors='replace')[:200])
                content=result.stdout;cached=False
            f=pd.read_csv(io.BytesIO(content))
            if list(f)!=['observation_date',name]:raise ValueError('Wrong vintage header')
            values=pd.to_numeric(f[name],errors='coerce');date=pd.PeriodIndex(f.observation_date,freq='M')
            observed=date[values.notna()]
            if not len(observed) or observed.max()>=cutoff or not values.dropna().between(0,30).all():
                raise ValueError('Vintage chronology/units failure')
            if not cached:path.write_bytes(content)
            records.append(dict(cutoff=cutoff,asof=day,url=url,file=path,sha256=digest(path),
                latest_observation=observed.max(),cached=cached,status='ok'))
            failures=0;print(cutoff,'saved',flush=True)
        except Exception as exc:
            failures+=1;records.append(dict(cutoff=cutoff,url=url,status='failed',error=str(exc)))
            print(cutoff,'failed',str(exc),flush=True)
        save_json(out/'manifest.json',dict(updated_utc=dt.datetime.now(dt.timezone.utc),
            role='Outcome sensitivity only; these later snapshots never enter historical model inputs.',records=records))
        if failures>=3:break
        time.sleep(1)
    journal('early_truth','Finished bounded supplementary vintage retrieval',completed=len(records),
        successful=sum(r['status']=='ok' for r in records))

if __name__=='__main__':run()
