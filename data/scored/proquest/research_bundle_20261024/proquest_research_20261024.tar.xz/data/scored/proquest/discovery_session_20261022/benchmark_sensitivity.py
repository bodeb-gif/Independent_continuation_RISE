"""Challenge outcome mappings without promoting an alternative target."""
from common import *
from run_primary import matched_cells
from proquest_descriptive import load_reference


def confidence_targets():
    f=pd.read_csv(BASE/'descriptive/scored_claims.csv.gz',dtype={'page_id':str})
    f['month']=pd.PeriodIndex(pd.to_datetime(f.date),freq='M')
    rows=[]
    regimes=pd.read_csv(BASE/'benchmark_interpretation_v2/matched_labels.csv.gz')
    regimes=regimes[regimes.source_set.eq('verified') & regimes.topic.eq('general_business')]
    keys=['record_id','original','duration_scaled','sign_only']
    full=f.merge(regimes[keys],on='record_id',validate='one_to_one')
    for cohort,data in [('all_horizons',full),('machine_stated',full[full.horizon_basis.eq('stated')])]:
        for regime in ['original','duration_scaled','sign_only']:
            d=data.copy();d['hit']=d.predicted_norm.eq(d[regime]).astype(float)
            c=matched_cells(d,'confidence','assertive','hedged','general_business')
            result=clustered_mean(c.difference,c.weight,c.year)
            rows.append(dict(cohort=cohort,target=regime,left_accuracy=np.average(c.hit_left,weights=c.weight),right_accuracy=np.average(c.hit_right,weights=c.weight),**result))
    paired=pd.read_csv(BASE/'alternative_targets_v1/paired_labels_and_eligibility.csv.gz')
    paired=paired[paired.source_set.eq('verified') & paired.topic.eq('general_business') & paired.eligible]
    labels=['frozen_original_band','frozen_sign','quarterly_ip_sign','alternative_sign']
    data=f.merge(paired[['record_id']+labels],on='record_id',validate='one_to_one')
    for target in labels:
        d=data.copy();d['hit']=d.predicted_norm.eq(d[target]).astype(float)
        c=matched_cells(d,'confidence','assertive','hedged','general_business')
        result=clustered_mean(c.difference,c.weight,c.year)
        rows.append(dict(cohort='paired_quarter_aligned',target=target,left_accuracy=np.average(c.hit_left,weights=c.weight),right_accuracy=np.average(c.hit_right,weights=c.weight),**result))
    pd.DataFrame(rows).to_csv(OUT/'confidence_benchmark_sensitivity.csv',index=False)
    return rows


def economic_targets():
    series,_=load_reference()
    raw=pd.read_csv(BASE/'alternative_target_inputs_v1/GDPC1.csv')
    gdp=pd.Series(pd.to_numeric(raw.iloc[:,1]).to_numpy(),index=pd.PeriodIndex(raw.iloc[:,0],freq='Q'))
    assert gdp.index.is_unique
    signal=pd.read_csv(OUT/'lagged_topic_signals.csv');signal['origin']=pd.PeriodIndex(signal.origin,freq='M')
    target=[]
    for origin in pd.period_range('1900-01','2010-12',freq='M'):
        if origin.month not in [1,4,7,10]:continue
        start=(origin-1).asfreq('Q');end=(origin+5).asfreq('Q')
        assert end.ordinal-start.ordinal==2
        row=dict(origin=origin)
        first,last=gdp.get(start,np.nan),gdp.get(end,np.nan)
        row['gdp_growth']=100*np.log(last/first) if np.isfinite(first) and np.isfinite(last) else np.nan
        for topic,name in [('general_business','ip_quarter_growth'),('employment','unemployment_quarter_improvement')]:
            s=series[topic]
            early=s.reindex(pd.period_range(start.asfreq('M','start'),start.asfreq('M','end'),freq='M'))
            late=s.reindex(pd.period_range(end.asfreq('M','start'),end.asfreq('M','end'),freq='M'))
            if early.notna().all() and late.notna().all():
                row[name]=-(late.mean()-early.mean()) if topic=='employment' else 100*np.log(late.mean()/early.mean())
        target.append(row)
    target=pd.DataFrame(target);rows=[]
    for topic in ['general_business','markets','employment']:
        d=signal[signal.topic.eq(topic)].copy()
        d['tested_predictor']=(d.net_direction-d.net_direction.mean())/d.net_direction.std()
        d['log_articles']=np.log1p(d.articles)
        d=d.merge(target,on='origin',validate='one_to_one')
        outcomes=['unemployment_quarter_improvement'] if topic=='employment' else ['gdp_growth','ip_quarter_growth']
        if topic!='employment':d=d.dropna(subset=outcomes)
        for outcome in outcomes:
            rr,_,_=regression(d,outcome,['tested_predictor'],['log_articles','papers','flat_share'])
            rows.append(dict(topic=topic,outcome=outcome,**rr[0]))
    pd.DataFrame(rows).to_csv(OUT/'economic_benchmark_sensitivity.csv',index=False)
    target.to_csv(OUT/'quarterly_outcome_sensitivity.csv',index=False)
    return rows


if __name__=='__main__':
    print(pd.DataFrame(confidence_targets()).to_string(index=False))
    print(pd.DataFrame(economic_targets()).to_string(index=False))
    write_json('benchmark_sensitivity_manifest.json',dict(status='Post hoc robustness, no benchmark promotion',
        input_sha256={str(p.relative_to(ROOT)):digest(p) for p in [BASE/'alternative_target_inputs_v1/GDPC1.csv',BASE/'alternative_targets_v1/paired_labels_and_eligibility.csv.gz',BASE/'benchmark_interpretation_v2/matched_labels.csv.gz',Path(__file__)]}))
