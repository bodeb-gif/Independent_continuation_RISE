"""Horizon, topic-composition and same-article challenges to the existing lead.

These are measurement sensitivities of one inspected relationship, not new
primary hypotheses or a substitute for human verification of claim semantics.
"""
from paper_timing_robustness import *

CONTROLS=['net_direction','net_squared','flat_share','log_articles','n_papers']

def article_matched(claims,kind):
    c=claims.copy();c['value']=c.sign.map({'positive':1.,'negative':-1.,'flat':0.})
    c['neutral']=c.sign.eq('flat').astype(float)
    a=c.groupby(['month','paper','page_id','topic']).agg(net=('value','mean'),flat=('neutral','mean')).reset_index()
    wide=a.pivot(index=['month','paper','page_id'],columns='topic',values='net').reindex(columns=TOPICS)
    other=wide.drop(columns='employment')
    if kind=='two_other_topics':
        use=wide.employment.notna()&other.notna().sum(axis=1).ge(2)
        summary=other.mean(axis=1)
    elif kind=='business_pair':
        use=wide.employment.notna()&wide.general_business.notna()
        summary=wide.general_business
    elif kind=='all_three_other_topics':
        use=wide.notna().all(axis=1);summary=other.mean(axis=1)
    else:raise ValueError(kind)
    jobsflat=a[a.topic.eq('employment')].set_index(['month','paper','page_id']).flat
    articles=wide.loc[use,['employment']].rename(columns={'employment':'net_direction'})
    articles['other_topic_mean']=summary[use];articles['flat_share']=jobsflat.reindex(articles.index)
    articles=articles.reset_index()
    p=articles.groupby(['month','paper']).agg(net_direction=('net_direction','mean'),
        other_topic_mean=('other_topic_mean','mean'),flat_share=('flat_share','mean'),n_articles=('page_id','size'))
    monthly=p.groupby('month').agg(net_direction=('net_direction','mean'),
        other_topic_mean=('other_topic_mean','mean'),flat_share=('flat_share','mean'),
        n_articles=('n_articles','sum'),n_papers=('n_articles','size'))
    calendar=pd.period_range('1900-01','2010-12',freq='M');monthly=monthly.reindex(calendar)
    monthly[['n_articles','n_papers']]=monthly[['n_articles','n_papers']].fillna(0)
    enough=(monthly.n_articles.gt(0).rolling(3,min_periods=1).sum().shift(1)>=2)&(
        monthly.n_papers.rolling(3,min_periods=1).max().shift(1)>=2)&(
        monthly.n_articles.rolling(3,min_periods=1).sum().shift(1)>=5)
    f=pd.DataFrame(index=calendar)
    for col in ['net_direction','other_topic_mean','flat_share']:
        f[col]=monthly[col].rolling(3,min_periods=2).mean().shift(1).where(enough)
    f['n_articles']=monthly.n_articles.rolling(3,min_periods=1).sum().shift(1).fillna(0)
    f['n_papers']=monthly.n_papers.rolling(3,min_periods=1).mean().shift(1)
    f['log_articles']=np.log1p(f.n_articles);f['net_squared']=f.net_direction**2
    f['cross_topic_gap']=f.net_direction-f.other_topic_mean
    f['topic']='employment';f.index.name='origin';f=f.reset_index();f['year']=f.origin.dt.year
    articles.to_csv(OUT/'audits'/f'same_article_{kind}.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    return f,dict(kind=kind,n_articles=len(articles),n_paper_months=len(p),n_months=int(monthly.net_direction.notna().sum()))

def run():
    claims=pd.read_csv(OUT/'cache/print_claims_verified.csv.gz',dtype={'page_id':str})
    claims['month']=pd.PeriodIndex(claims.month,freq='M')
    original=basic_features(claims);base=analysis_frame(original)
    primary,_,_=estimate(base,'cross_topic_gap','employment_growth',CONTROLS,wild=False)
    sigma=primary['feature_sd'];rows=[];samples=[];cohorts=[]
    def retain(name,d,controls=CONTROLS):
        r,_,used=estimate(d,'cross_topic_gap','employment_growth',controls,wild=True)
        if r.get('status')=='estimated':
            for key in ['effect','low','high']:r[key+'_per_primary_sd']=r[key]/r['feature_sd']*sigma
        rows.append(dict(variant=name,**r));samples.append(used.assign(variant=name))
        print(name,r['status'],r['effect'],r['p_value'],r['n'],flush=True)
    retain('primary_reproduced',base)
    subsets=[('stated_horizons_1_to_24',claims.horizon_basis.eq('stated')&claims.horizon_used.between(1,24)),
             ('stated_horizons_4_to_8',claims.horizon_basis.eq('stated')&claims.horizon_used.between(4,8)),
             ('stated_horizons_1_to_6',claims.horizon_basis.eq('stated')&claims.horizon_used.between(1,6)),
             ('stated_horizons_7_to_24',claims.horizon_basis.eq('stated')&claims.horizon_used.between(7,24))]
    for name,mask in subsets:
        retain(name,analysis_frame(basic_features(claims[mask])))
    # Export availability and composition from earlier print fields only.
    f=pd.read_csv(OUT/'cache/features_verified.csv.gz');f['origin']=pd.PeriodIndex(f.origin,freq='M')
    controls=CONTROLS.copy();d=base.copy()
    for topic in ['general_business','markets','prices']:
        t=f[f.topic.eq(topic)].set_index('origin')
        for field in ['net_direction','flat_share','log_articles','n_papers','observed_months']:
            name=topic+'__'+field
            if field=='net_direction':
                d[name+'_observed']=d.origin.map(t[field].notna().astype(float));controls.append(name+'_observed')
            else:
                # Missing neutral shares are represented explicitly, never zero sentiment.
                values=d.origin.map(t[field]);d[name]=values.fillna(0.)
                controls.append(name)
    retain('other_topic_availability_and_composition',d,controls)
    for kind in ['two_other_topics','business_pair','all_three_other_topics']:
        f,cohort=article_matched(claims,kind);cohorts.append(cohort)
        retain('same_article_'+kind,analysis_frame(f))
    pd.DataFrame(rows).to_csv(OUT/'measurement_challenges.csv',index=False)
    pd.DataFrame(cohorts).to_csv(OUT/'measurement_challenge_cohorts.csv',index=False)
    pd.concat(samples,ignore_index=True).to_csv(OUT/'audits/measurement_challenge_analysis_rows.csv.gz',index=False,
        compression={'method':'gzip','mtime':0})
    save_json(OUT/'audits/measurement_challenges.json',dict(status='complete',primary_feature_sd=sigma,
        role='Measurement sensitivities of the existing cross-topic association. No new primary p-value or independent discovery.',
        limits='Stated horizons remain machine labels. Same-article restrictions address composition, not truthfulness of the extraction. Coverage and selection can change the estimand.',
        code_sha256=digest(__file__),source_count=check_sources()))
    journal('measurement_challenges','Completed horizon, topic-coverage and same-article robustness variants')

if __name__=='__main__':run()
