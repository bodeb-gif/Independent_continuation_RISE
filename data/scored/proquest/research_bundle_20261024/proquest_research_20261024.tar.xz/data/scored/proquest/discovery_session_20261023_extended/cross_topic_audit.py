"""Challenge the employment cross-topic lead without replacing its primary test."""
from associations import *

def wide_features(variant='verified'):
    f=pd.read_csv(OUT/'cache'/f'features_{variant}.csv.gz')
    f['origin']=pd.PeriodIndex(f.origin,freq='M')
    w=f.pivot(index='origin',columns='topic',values='net_direction')
    d=inputs(variant);d=d[d.topic.eq('employment')].copy()
    for t in TOPICS:d[t+'_net']=d.origin.map(w[t])
    d['all_other_mean']=d[['general_business_net','markets_net','prices_net']].mean(axis=1).where(
        d[['general_business_net','markets_net','prices_net']].notna().all(axis=1))
    d['activity_other_mean']=d[['general_business_net','markets_net']].mean(axis=1).where(
        d[['general_business_net','markets_net']].notna().all(axis=1))
    d['fixed_all_gap']=d.net_direction-d.all_other_mean
    d['activity_gap']=d.net_direction-d.activity_other_mean
    return d

def run():
    controls=['net_direction','net_squared','flat_share','log_articles','n_papers']
    from proquest_vintages import CORE_FEATURES
    rows=[];frames=[]
    for variant in ['verified','raw']:
        d=wide_features(variant)
        variants=[('primary',d,'cross_topic_gap',controls),
            ('fixed_three_other_topics',d,'fixed_all_gap',controls),
            ('exclude_prices_from_other',d,'activity_gap',controls),
            ('fresh_vintage_macro',d,'cross_topic_gap',controls+list(CORE_FEATURES))]
        for label,sub,feature,columns in variants:
            for span in [2,5,10]:
                r,_,used=estimate(sub,feature,'employment_growth',columns,span=span,wild=(span in [5,10]))
                rows.append(dict(source_set=variant,variant=label,feature=feature,block_years=span,**r))
                if span==5:frames.append(used.assign(source_set=variant,variant=label))
        if variant=='verified':
            for offset in range(6):
                sub=d[d.origin.map(lambda o:o.ordinal%6==offset)]
                r,_,_=estimate(sub,'cross_topic_gap','employment_growth',controls,wild=True)
                rows.append(dict(source_set=variant,variant=f'nonoverlapping_offset_{offset}',block_years=5,**r))
            for year_group in sorted(((d.year-1900)//5).unique()):
                sub=d[(d.year-1900)//5!=year_group]
                r,_,_=estimate(sub,'cross_topic_gap','employment_growth',controls,wild=False)
                rows.append(dict(source_set=variant,variant=f'omit_block_{year_group}',block_years=5,**r))
            tone=pd.read_csv(PRIOR/'external_tone_monthly.csv');tone.columns=['month','sentiment']
            tone['month']=pd.PeriodIndex(tone.month,freq='M');s=tone.set_index('month').sentiment
            def prior_tone(o):
                v=s.reindex(pd.period_range(o-3,o-1,freq='M'))
                return v.mean() if v.notna().all() else np.nan
            d['prior_tone']=d.origin.map(prior_tone)
            for label,columns in [('tone_only',controls+['prior_tone']),
                ('tone_and_macro',controls+['prior_tone']+list(CORE_FEATURES))]:
                r,_,used=estimate(d,'cross_topic_gap','employment_growth',columns,wild=True)
                rows.append(dict(source_set=variant,variant=label,block_years=5,**r))
                frames.append(used.assign(source_set=variant,variant=label))
            # Conditional decomposition is interpretation of the same lead.
            # These coefficients are retained as diagnostics, not new primary
            # discoveries, and cannot be used to replace its p-value.
            for t in ['general_business','markets','prices']:
                other=[q+'_net' for q in ['general_business','markets','prices'] if q!=t]
                r,_,used=estimate(d,t+'_net','employment_growth',controls+other,wild=True)
                rows.append(dict(source_set=variant,variant='conditional_component_'+t,block_years=5,**r))
                frames.append(used.assign(source_set=variant,variant='conditional_component_'+t))
        pd.DataFrame(rows).to_csv(OUT/'cross_topic_robustness_partial.csv',index=False)
    result=pd.DataFrame(rows);result.to_csv(OUT/'cross_topic_robustness.csv',index=False)
    pd.concat(frames,ignore_index=True).to_csv(OUT/'audits/cross_topic_analysis_rows.csv.gz',index=False,
        compression={'method':'gzip','mtime':0})
    save_json(OUT/'audits/cross_topic_manifest.json',dict(status='completed',
        role='Post-screen robustness and interpretation of the existing primary question, no new primary targets or promoted component p-values.',
        primary_interpretation='Conditional on the employment net level, employment minus mean-other-topic direction is an equivalent parameterization of the other-topic mean with reversed sign. It does not by itself establish irrational disagreement or a causal transmission.',
        code_sha256=digest(__file__),source_count=check_sources()))
    journal('cross_topic_audit','Finished coverage, source, timing, tone and macro challenges')
    print(result[result.block_years.eq(5)][['source_set','variant','effect','low','high','p_value','n','n_blocks']].to_string(index=False))

if __name__=='__main__':run()
