"""Descriptive reliability of the frozen binary forecasts; no iid intervals."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from session_utils import *

def run():
    f=pd.read_csv(OUT/'simple_benchmarks/reliability.csv')
    fig,axes=plt.subplots(2,2,figsize=(10,9),sharex=True,sharey=True)
    methods=[('linear','Logistic regression','#126b80'),('hist_gradient_boosting','Boosted trees','#c97b32'),
        ('extra_trees','Extra trees','#6a8f4e'),('gru','GRU','#815f9e')]
    for row,(task,label) in enumerate([('production_downturn','Production downturn'),('unemployment_downturn','Unemployment rise')]):
        for column,(arm,description) in enumerate([('macro_coverage','Macro and coverage'),('macro_coverage_net_structure','Macro, coverage and all news features')]):
            ax=axes[row,column];ax.plot([0,1],[0,1],ls='--',color='#adb7be',lw=1)
            for algorithm,name,color in methods:
                d=f[f.task.eq(task)&f.arm.eq(arm)&f.algorithm.eq(algorithm)&f.n.gt(0)].sort_values('bin')
                ax.plot(d.mean_probability,d.event_rate,color=color,lw=1,alpha=.8,label=name)
                for point in d.itertuples(index=False):
                    ax.scatter(point.mean_probability,point.event_rate,s=18+2*np.sqrt(point.n),
                        facecolor=color if point.n>=10 else 'white',edgecolor=color,zorder=3)
            ax.set_title(label+'\n'+description,fontsize=11);ax.set_xlim(-.03,1.03);ax.set_ylim(-.03,1.03)
            ax.set_xlabel('Mean predicted probability in fixed bin');ax.set_ylabel('Observed event frequency')
    axes[0,0].legend(frameon=False,fontsize=8,loc='upper left')
    fig.suptitle('Descriptive reliability of frozen forecasts',fontsize=15,y=1.01)
    fig.text(.01,-.025,'1977–2010 overlapping monthly origins. Empty bins omitted; open markers have fewer than 10 origins. No iid confidence bars or new significance test.',fontsize=9)
    fig.tight_layout()
    for suffix in ['png','svg']:
        fig.savefig(OUT/'figures'/('probability_reliability.'+suffix),dpi=170,bbox_inches='tight')
    plt.close(fig)
    save_json(OUT/'audits/probability_figure.json',dict(status='complete',code_sha256=digest(__file__),
        data_sha256=digest(OUT/'simple_benchmarks/reliability.csv')))

if __name__=='__main__':run()
