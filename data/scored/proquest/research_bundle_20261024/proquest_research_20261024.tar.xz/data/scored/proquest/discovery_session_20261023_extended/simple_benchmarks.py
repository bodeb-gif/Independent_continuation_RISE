"""Print-time training climatology and descriptive binary reliability checks."""
from boundary_rules import CorrectedHistoricalTargets, corrected_evaluation_truth
from model_data import *

def run():
    folder=OUT/'simple_benchmarks';folder.mkdir(exist_ok=True)
    frame,valid=feature_frame();targets=CorrectedHistoricalTargets();rows=[];audits=[]
    for task in TASKS:
        for year in range(1977,2011):
            cutoff=pd.Period(f'{year}-01','M');train,y,labels=eligible(frame,valid,targets,cutoff,task)
            if len(train)<120:raise ValueError('Unexpected climatology training support')
            prediction=(y.sum()+1)/(len(y)+2) if task.endswith('downturn') else y.mean()
            for origin in valid[valid.year==year]:
                rows.append(dict(origin=origin,task=task,model='historical_vintage_climatology',prediction=prediction))
            audits.append(dict(task=task,year=year,n_training=len(train),last_training_origin=train.max(),
                latest_target_endpoint=labels.target_end.max(),vintage=labels.label_vintage.iloc[0],
                available_by=labels.label_available_by.iloc[0],prediction=prediction))
    pred=pd.DataFrame(rows);pred.to_csv(folder/'predictions_without_truth.csv',index=False)
    pd.DataFrame(audits).to_csv(folder/'timing_audit.csv',index=False)
    # Predictions and timing are frozen before assessment truth is attached.
    for task in TASKS:
        use=pred.task.eq(task)
        pred.loc[use,'truth']=corrected_evaluation_truth(pd.PeriodIndex(pred.loc[use,'origin'],freq='M'),task)
    pred['loss']=(pred.prediction-pred.truth)**2;pred.to_csv(folder/'predictions.csv',index=False)
    metrics=pred.groupby(['task','model']).agg(n=('loss','size'),mean_loss=('loss','mean'),mean_prediction=('prediction','mean'),mean_outcome=('truth','mean')).reset_index()
    metrics.to_csv(folder/'metrics.csv',index=False)
    reliability=[];comparison=[]
    for algorithm in ['linear','hist_gradient_boosting','extra_trees','gru']:
        d=pd.read_csv(OUT/'models_boundary_corrected'/algorithm/'predictions.csv')
        for (task,arm),g in d.groupby(['task','arm']):
            climate=metrics[metrics.task.eq(task)].mean_loss.iloc[0]
            comparison.append(dict(task=task,algorithm=algorithm,arm=arm,model_loss=g.loss.mean(),
                climatology_loss=climate,descriptive_gain_over_climatology=climate-g.loss.mean()))
            if not task.endswith('downturn'):continue
            bins=np.minimum((g.prediction.to_numpy(float)*10).astype(int),9)
            for b in range(10):
                sub=g[bins==b]
                reliability.append(dict(task=task,algorithm=algorithm,arm=arm,bin=b,
                    probability_lower=b/10,probability_upper=(b+1)/10,n=len(sub),
                    mean_probability=sub.prediction.mean() if len(sub) else np.nan,
                    event_rate=sub.truth.mean() if len(sub) else np.nan,
                    note='Descriptive overlapping monthly observations; no iid binomial confidence interval.'))
    pd.DataFrame(comparison).to_csv(folder/'model_comparison.csv',index=False)
    pd.DataFrame(reliability).to_csv(folder/'reliability.csv',index=False)
    save_json(folder/'completion.json',dict(status='complete',
        design='Annual expanding historical-vintage training mean; Beta1,1 smoothed frequency for binary tasks. Same mature-label eligibility as the main models. Fixed0.1 probability bins for descriptive reliability.',
        role='Benchmark interpretation after the main results; no new p-value, selected winning model or independent discovery.',
        code_sha256=digest(__file__),source_check=check_sources()))
    journal('simple_benchmarks','Added historical-vintage climatology and descriptive probability reliability checks')
    print(metrics.to_string(index=False))
    print(pd.DataFrame(comparison).to_string(index=False))

if __name__=='__main__':run()
