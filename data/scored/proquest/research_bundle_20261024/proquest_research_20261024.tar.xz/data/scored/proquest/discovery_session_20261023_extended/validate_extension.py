"""Independent numerical and timing checks for the extension's methods."""
import time
import statsmodels.api as sm
from associations import restricted_wild, select_design
from model_data import *

def main():
    start=time.monotonic();checks=[];rng=np.random.default_rng(771)
    # Unequal-sized clusters, nonzero controls, and a restricted null. Explicit
    # refits do not reuse any bootstrap score algebra from the implementation.
    groups=np.repeat(np.arange(6),[8,13,7,15,10,11]);n=len(groups)
    X=np.column_stack([np.ones(n),rng.normal(size=n),rng.normal(size=n)])
    y=.3*X[:,1]+1.2*X[:,2]+rng.normal(size=6)[groups]+rng.normal(size=n)
    observed=sm.OLS(y,X).fit(cov_type='cluster',cov_kwds={'groups':groups,
        'use_correction':True,'df_correction':True},use_t=True)
    null=sm.OLS(y,X[:,[0,2]]).fit();count=0
    for i in range(64):
        signs=np.array([1. if i&(1<<j) else -1. for j in range(6)])
        star=null.fittedvalues+null.resid*signs[groups]
        fit=sm.OLS(star,X).fit(cov_type='cluster',cov_kwds={'groups':groups,
            'use_correction':True,'df_correction':True},use_t=True)
        count+=int(abs(fit.tvalues[1])>=abs(observed.tvalues[1])-1e-10)
    result=restricted_wild(X,y,groups,1)
    np.testing.assert_allclose(result['wild_se'],observed.bse[1],rtol=1e-10)
    np.testing.assert_allclose(result['p_wild'],count/64,rtol=0,atol=0)
    checks.append('Restricted-wild regression matches 64 independent statsmodels cluster refits exactly.')
    # Mean inference is independently checked by OLS and direct studentization.
    m=mean_inference(y,1977+groups,span=1)
    intercept=sm.OLS(y,np.ones((n,1))).fit(cov_type='cluster',cov_kwds={
        'groups':groups,'use_correction':True,'df_correction':True},use_t=True)
    np.testing.assert_allclose(m['se'],intercept.bse[0],rtol=1e-10)
    star_t=[]
    for i in range(64):
        signs=np.array([1. if i&(1<<j) else -1. for j in range(6)])
        fit=sm.OLS(y*signs[groups],np.ones((n,1))).fit(cov_type='cluster',cov_kwds={
            'groups':groups,'use_correction':True,'df_correction':True},use_t=True)
        star_t.append(fit.tvalues[0])
    np.testing.assert_allclose(m['p_wild'],np.mean(abs(np.asarray(star_t))>=abs(intercept.tvalues[0])-1e-10),atol=0)
    checks.append('Mean confidence interval and wild p match independent intercept-only refits.')
    frame,valid=feature_frame();targets=HistoricalTargets()
    for task in TASKS:
        for year in range(1977,2011):
            refit=pd.Period(f'{year}-01','M');train,y,labels=eligible(frame,valid,targets,refit,task)
            assert len(train)>=120 and (train+8<refit).all()
            assert (pd.to_datetime(labels.label_available_by)<refit.start_time).all()
            for fold in inner_folds(frame,valid,targets,refit,task):
                earlier,_,old=eligible(frame,valid,targets,fold['origin'],task)
                assert (earlier+8<fold['origin']).all()
                assert (pd.to_datetime(old.label_available_by)<fold['origin'].start_time).all()
                assert (fold['validation']>=fold['origin']).all()
                assert (fold['validation']+8<refit).all()
    checks.append('All 136 outer task/refits and every inner fold satisfy label maturity and actual vintage availability.')
    # Independently reproduce exact-as-of unemployment labels at one refit.
    origin=pd.Period('1983-01','M');train,y,labels=eligible(frame,valid,targets,origin,'unemployment_continuous')
    name,day,s=targets.snapshot(origin,'unemployment_continuous')
    expected=np.array([-(s.loc[t+5]-s.loc[t-1]) for t in train])
    np.testing.assert_array_equal(y,expected)
    checks.append('Historical unemployment training targets equal direct prior-as-of endpoint differences.')
    # Check linear backtest truth is attached only after raw predictions exist.
    p=OUT/'models/linear/predictions_without_truth.csv'
    if p.exists():
        bare=pd.read_csv(p);scored=pd.read_csv(p.with_name('predictions.csv'))
        assert 'truth' not in bare and 'loss' not in bare
        pd.testing.assert_frame_equal(bare,scored[bare.columns])
        assert len(bare)==4*408*3
        for _,g in scored.groupby(['task','arm']):
            assert len(g)==408 and g.origin.nunique()==408
        checks.append('All 4,896 linear forecasts precede truth attachment and share all 408 monthly dates.')
    checks.append(f'All {check_sources()} frozen original source/instruction hashes remain unchanged.')
    save_json(OUT/'audits/validation_initial.json',dict(status='passed',checks=checks,
        n_checks=len(checks),elapsed_seconds=time.monotonic()-start))
    for check in checks:print('PASS',check)

if __name__=='__main__':main()
